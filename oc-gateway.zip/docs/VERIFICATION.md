# Hosting gateway verification — 2026-10-11

This report distinguishes **actual CLI/HTTP execution** from unit/simulated tests and from unverified device/provider/hosting behavior. The Android companion's full report is `docs/VERIFICATION.md` in the combined source project.

## Actually executed

### 1. Genuine command-based installation and startup

- Registry metadata confirmed `opencode-ai@1.18.35` exists and includes platform-specific optional packages.
- A real npm installation into a private scratch runtime succeeded: **3 packages installed**. Actual `opencode --version` output: **1.18.35**.
- Then the actual `node gateway/start.js` entry point was started with a **fresh managed runtime**, using SERVER_PORT=4400, OPENCODE_PORT=4401 and private scratch DATA_DIR/WORKSPACE_DIR. The bootstrap itself executed npm, using its cache, not an installation API or a fake CLI.

Actual ordered log excerpts:

```text
Gateway listening on 0.0.0.0:4400; waiting for command-based OpenCode installation / readiness
[BOOTSTRAP] Executing npm install opencode-ai@1.18.35 --prefix runtime (1/3)
[npm] added 3 packages in 6s
[BOOTSTRAP] Installation and opencode --version verified: v1.18.35
[OpenCode] Executing opencode serve --hostname 127.0.0.1 (not exposed to the internet)
OpenCode is ready (v1.18.35) on PRIVATE loopback port 4401
OC GATEWAY v1.0.0 — ready for OC Pilot
```

Only **after** these readiness steps was a real 300-second, single-use LINK CODE printed. Test codes are deliberately not reproduced as deployment instructions. The temporary background gateway was stopped cleanly after verification.

### 2. Node tests

Executed on Node **v22.22.3** / npm **10.9.8**:

```sh
npm test --prefix gateway
# node --test test/*.test.js
```

Actual final output, exit 0: **102 tests passed, 0 failed, 0 skipped**, across 15 test files (7 describe suites plus standalone tests). These include original auth/pairing/project/artifact/transport/redaction coverage, plus panel-port precedence, pinned install arguments, actual child-command timeout/cancel/UTF-8/bounds, install retry/reuse/concurrency/cancel, early health/deferred code, strict JSON byte splits, fail-closed key/state, cgroup memory, GitHub disconnect races and scoped proxy/cursor/Last-Event-ID handling.

**Important distinction:** OpenCode/GitHub transport simulation exists only in test helpers. These tests are not claimed as live AI/model or GitHub-account execution. Runtime startup never substitutes the fake helper for OpenCode.

### 3. Genuine OpenCode integration: 27 checks

Actually executed against the genuine installed npm CLI, no fake upstream:

```sh
node gateway/scripts/real-smoke.js \
  --runtime .work/real-host/managed-runtime \
  --record-dir .work/real-host/responses \
  --apk ocpilot-debug.apk
```

Actual successful output:

```text
REAL CLI INTEGRATION PASS: 27 checks. No AI prompt or GitHub account was used.
```

Checks: CLI/version and private readiness; public v1 health; unauthorized gateway rejection; private OpenCode Basic-auth rejection; actual LINK CODE redemption/single-use; real status/device/tool metadata; Arabic empty-project creation and rename; real global providers; project-directory-injected session creation/list/metadata; missing-key idle status; 400-row history endpoint; pending permissions and diff endpoints; actual unbuffered `server.connected` SSE; boolean abort; hashing/downloading the actual delivered APK; authenticated full/Range bytes; traversal rejection; hash-only device storage; full gateway/OpenCode restart preserving token/project/session; rotation invalidating old token and closing SSE; revocation closing SSE and rejecting future requests.

Each smoke run stops its services and removes its temporary private state. It does not need or collect the user's keys.

### 4. Android wire compatibility / actual OpenAPI

- Real classic OpenAPI 3.1 fetched from **OpenCode v1.18.35**, commit `53d1eabb61e21162157817bf677da0a4ad3332e3`; blob `e66d140505585ab0bab62640360eb08f249f35c0` (1,061,286 bytes).
- **9 captured response shapes**, including the actual SSE payload, plus **40 existing schema-derived OpenCode fixtures** passed validation: **49/49**. The provider capture is intentionally sanitized: optional `key` removed, `options` emptied while retaining its required object. No fake response is labeled a live capture.
- The shipped Android Java `Models` decoders were executed on **9 captured actual gateway/OpenCode payloads** (on JVM, not Android UI): strict v1 health, status, Arabic project, session/list, **10 real model IDs**, empty history/diff and actual APK artifact kind/SHA. No provider options/keys survive model serialization.
- Shared contract document copied verbatim from the app project; root `docs/CONTRACT.md` was not changed.

### 5. Companion APK

- Java/resource compilation: **135 class files**; D8 conversion, assembly, signing and verification succeeded.
- Actual Android JVM tests: **76 passed** (six suites, including 3 new health-contract tests). Structural checker: **23/23**; **279 matching bilingual strings**.
- APK: `ocpilot-debug.apk`, **181490 bytes**, package `com.ocpilot.app`, 1.0.0, Android 9+, target/compile 34.
- SHA-256: `07fbf5ef4c256efc7d653a005b1d9dfdf2672a8915aba47d7bac271b14997a14`.
- API28–34 signature: `verified=true, V3=true, errors=[], warnings=[]`.
- Same certificate as the last 2026-10-11 APK: cert SHA-256 `fc64384a05d68cf6ac76cd38b9d6a21ffc90fd3d85f838e8168592177b4be1c3`.
- APK CRC, DEX, uncompressed/aligned resources and absence of native payloads checked. Signing key remains private/temporary and is not in the source/hosting ZIPs.

## Static review / packaging

Reviewed startup ordering, actual executable/argument spawning (shell=false), config precedence, persistent paths, cancellation/retries/process-group teardown, health-generation races, secret redaction, bounded buffers, JSON limits/UTF-8, auth errors, server-owned canonical scope, SSE cleanup/backpressure, credential-disconnect races, TLS fail-closed and private-file/archive exclusions. `node --check` and the Android forbidden-source guard passed. Archives contain source/docs/tests only, never `.env`, data/workspace/runtime, npm packages, master/signing keys or sandbox build tools.

The hosting ZIP was actually extracted into a separate directory: **102/102 Node tests and 27/27 genuine CLI checks passed again on its extracted code**, including the delivered APK. The combined source ZIP's extracted Android project passed **23/23 structural checks**. Both archives were checked for all ZIP CRCs, safe paths, no symlinks, exact entry sets and byte-for-byte correspondence with the current sources. The final documentation-only refresh preserves the tested code.

## Not verified

- **The user's real Waifly/Pterodactyl instance**: no account/allocated public address supplied. Its firewall/port mapping, outbound access, RAM/disk limits and egg behavior must be checked after upload.
- **AI prompt/model access/tool execution/builds**: no model/provider account used; smoke intentionally submits no prompt. A free-model listing is not proof of usable inference or quota. Provider/OAuth login and live GitHub-account operations were not tested.
- **Physical Android/emulator**: APK installation, visual layout/RTL, Keystore hardware, permissions, foreground/background/lifecycle, installer/provider/MediaStore and long-task behavior were not executed on a device.
- **Exact Gradle/AGP/CI build**: sandbox lacks gradle/full SDK/JDK. The exact command is unavailable (exit127); standalone compilation is not Gradle/CI verification. Workflow was not dispatched, and no new changes were committed/pushed in this delivery turn.
- Long-running jobs cannot be guaranteed across host OOM, force-stop, manual restarts or deployments. `restart-opencode` explicitly interrupts active work.

See [DEPLOY.md](../DEPLOY.md) for the concrete upload/start/address/code/provider/toolchain steps and update/backup precautions.
