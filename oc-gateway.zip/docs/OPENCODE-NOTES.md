# OpenCode API & Runtime Verification Notes

This document records the exact findings, behaviors, flags, and specifications confirmed directly from the `opencode-ai` package (v1.18.35), its OpenAPI 3.1 specification, CLI flags, runtime binary inspection, and live server execution.

---

## 1. Verified CLI Commands and Flags

Running `opencode serve --help` against the installed package confirms the following flags:

```
opencode serve

starts a headless opencode server

Options:
  -h, --help         show help                                                             [boolean]
  -v, --version      show version number                                                   [boolean]
      --print-logs   print logs to stderr                                                  [boolean]
      --log-level    log level                  [string] [choices: "DEBUG", "INFO", "WARN", "ERROR"]
      --pure         run without external plugins                                          [boolean]
      --port         port to listen on                                         [number] [default: 0]
      --hostname     hostname to listen on                           [string] [default: "127.0.0.1"]
      --mdns         enable mDNS service discovery (defaults hostname to 0.0.0.0)
                                                                          [boolean] [default: false]
      --mdns-domain  custom domain name for mDNS service (default: opencode.local)
                                                                [string] [default: "opencode.local"]
      --cors         additional domains to allow for CORS                      [array] [default: []]
```

### Verified Gateway Command
The gateway supervisor launches the child with:
```bash
runtime/node_modules/.bin/opencode serve --hostname 127.0.0.1 --port <OPENCODE_PORT>
```

---

## 2. Server Authentication & Username

### Findings from Binary & Runtime Probing
1. When `OPENCODE_SERVER_PASSWORD` is set, OpenCode enforces HTTP Basic Authentication across all endpoints.
2. In `opencode-ai` (1.18.35), the basic auth username defaults to `opencode`. If `OPENCODE_SERVER_USERNAME` is provided, it is defined in `ServerAuthConfig`, but the upstream server strictly accepts `opencode:<password>`.
3. If unauthorized, requests receive `HTTP/1.1 401 Unauthorized` with `www-authenticate: Basic realm="Secure Area"`.
4. The gateway generates a secure 32-byte base64url password saved at `data/opencode-password` (mode 0600) on first boot. The password is never sent to clients and is only used over the local loopback interface `127.0.0.1`.

---

## 3. Verified Endpoints & Health Check

### Health Check Endpoint
- **Path**: `GET /global/health`
- **Authentication**: Requires Basic Auth (`Authorization: Basic <base64>`)
- **Status Code**: `200 OK`
- **Response Shape**:
  ```json
  {
    "healthy": true,
    "version": "1.18.35"
  }
  ```
- **Gateway Supervisor Action**: Polled every 500ms up to 90s upon startup. Sets `running=true` and extracts the OpenCode version string.

### OpenAPI Specification
- **Path**: `GET /doc`
- **Authentication**: Requires Basic Auth
- **Specification**: OpenAPI 3.1.0 document (468 KB).
- **Major Endpoints Verified in OpenAPI 3.1 Spec**:
  - `GET /global/health` — Server health status
  - `GET /global/event` — Global event stream (SSE)
  - `GET /session` — List sessions for current directory/workspace
  - `POST /session` — Create a new coding session
  - `GET /session/{sessionID}` — Get session details
  - `POST /session/{sessionID}/message` — Submit prompt/instruction to agent
  - `POST /session/{sessionID}/abort` — Abort active execution
  - `GET /event` — Project event stream (SSE)
  - `GET /file` & `GET /file/content` — File read/list operations
  - `GET /vcs` & `GET /vcs/status` & `GET /vcs/diff` — Version control status

---

## 4. Project Directory Injection & Workspace Scoping

### Findings from OpenAPI & Source Inspection
OpenCode supports project scoping via two mechanisms:
1. **Query Parameter**: Every project-scoped endpoint (`/session`, `/event`, `/file`, `/vcs`, `/command`, `/pty`, etc.) includes `directory` in query parameters:
   ```json
   "parameters": [
     { "name": "directory", "in": "query", "schema": { "type": "string" }, "required": false }
   ]
   ```
2. **HTTP Headers**: OpenCode's location middleware extracts `x-opencode-directory` (URL-decoded) or `location[directory]`.

### Gateway Implementation
When a client sends `X-Project-Id: <id>`, the gateway:
- Validates that `<id>` belongs to an existing project in `state.json`.
- Resolves the absolute path: `path.resolve(WORKSPACE_DIR, project.dirName)`.
- Replaces any client-supplied `directory` query parameter with the resolved absolute path.
- Injects header `x-opencode-directory: <encoded_path>`.
- Removes client `directory` and `location` parameters if `X-Project-Id` is omitted (for global calls).
- Updates project `lastActivityAt`.

---

## 5. Environment Variables & Telemetry

OpenCode checks the following environment variables:
- `OPENCODE_SERVER_PASSWORD`: Password for HTTP Basic auth.
- `OPENCODE_SERVER_USERNAME`: Username for HTTP Basic auth (default `opencode`).
- `OPENCODE_DISABLE_AUTOUPDATE`: Set to `1` by gateway to prevent spontaneous background binary replacements.
- `OPENCODE_DISABLE_MODELS_FETCH`: Optional model list caching toggle.
- `HOME`, `XDG_DATA_HOME`, `XDG_CONFIG_HOME`, `XDG_CACHE_HOME`, `XDG_STATE_HOME`: All routed into `data/home/...` so that provider logins, credentials, and settings persist across container restarts.

### Git Credentials for OpenCode Child Shell
When GitHub is connected, the gateway forwards:
- `GH_TOKEN` / `GITHUB_TOKEN`: Plain token for CLI tools
- `GIT_ASKPASS`: `data/git-askpass.sh` (mode 0700)
- `GIT_TERMINAL_PROMPT=0`: Disables interactive terminal prompts
- `GIT_AUTHOR_NAME` / `GIT_COMMITTER_NAME`: User login
- `GIT_AUTHOR_EMAIL` / `GIT_COMMITTER_EMAIL`: `<login>@users.noreply.github.com`

---

## 6. OpenCode Free Models (OpenCode Zen)

OpenCode includes native support for free models under the "OpenCode Zen" provider integration, which does not strictly require external paid API keys. If the user provides API keys (e.g. `OPENROUTER_API_KEY`, `ANTHROPIC_API_KEY`, `OPENAI_API_KEY`, etc.), the gateway forwards them directly to the OpenCode environment.


## Companion update — 2026-10-11 (executed, not guessed)

The deployment default is now pinned to `opencode-ai@1.18.35`. The actual registry package was installed, `opencode --version` returned `1.18.35`, and `opencode serve --help` confirmed `--hostname` / `--port`. The private server's `/global/health` returned genuine readiness before automatic pairing-code generation.

The combined project fetched classic SDK OpenAPI from commit `53d1eabb61e21162157817bf677da0a4ad3332e3`, blob `e66d140505585ab0bab62640360eb08f249f35c0` (OpenAPI3.1 / 1,061,286 bytes). Genuine provider/session/status/history/permission/diff/abort/SSE response shapes were captured in a temporary no-account test and checked against that source. Provider credential/options values were removed from stored test metadata; no guessed response was labeled a live capture. The phone's actual production decoders accepted the recorded public/model-ID shapes.

Confirmed live metadata semantics: global provider request has no project directory; scoped session create uses server-injected directory; fresh session missing from status map means idle; history is an array; pending permissions/diff are arrays; abort is boolean; first SSE type is `server.connected`. This exercised **no AI prompt, model/provider/OAuth account, pending permission decision or live GitHub account**. Those remain unverified, as do actual Android lifecycle/UI actions.

The install uses npm CLI commands. OpenCode HTTP is still used privately for session/SSE/tool/permission functions, as explicitly selected. Shared contract v1 is retained verbatim in `CONTRACT.md`.
