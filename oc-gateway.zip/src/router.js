'use strict';

const { URL } = require('url');
const logger = require('./logger');
const doctor = require('./doctor');

class Router {
  constructor(deps) {
    this.config = deps.config;
    this.stateManager = deps.stateManager;
    this.pairingManager = deps.pairingManager;
    this.authManager = deps.authManager;
    this.supervisor = deps.supervisor;
    this.proxy = deps.proxy;
    this.githubClient = deps.githubClient;
    this.projectsManager = deps.projectsManager;
    this.artifactsManager = deps.artifactsManager;
    this.startedAt = new Date().toISOString();
  }

  getClientIp(req) {
    if (this.config.TRUST_PROXY) {
      const xff = req.headers['x-forwarded-for'];
      if (xff && typeof xff === 'string') {
        const first = xff.split(',')[0].trim();
        if (first) return first;
      }
    }
    return (req.socket && req.socket.remoteAddress) || '127.0.0.1';
  }

  sendJson(res, statusCode, data, extraHeaders = {}) {
    const payload = JSON.stringify(data);
    res.writeHead(statusCode, {
      'Content-Type': 'application/json; charset=utf-8',
      'X-Content-Type-Options': 'nosniff',
      'Cache-Control': 'no-store',
      ...extraHeaders
    });
    res.end(payload);
  }

  sendError(res, statusCode, code, message, extraHeaders = {}) {
    const payload = JSON.stringify({
      error: code,
      message: logger.redact(message)
    });
    res.writeHead(statusCode, {
      'Content-Type': 'application/json; charset=utf-8',
      'X-Content-Type-Options': 'nosniff',
      'Cache-Control': 'no-store',
      ...extraHeaders
    });
    res.end(payload);
  }

  parseJsonBody(req) {
    return new Promise((resolve, reject) => {
      const chunks = []; let bytes = 0, settled = false;
      const finish = (error, value) => {
        if (settled) return; settled = true; clearTimeout(timer);
        if (error) { chunks.length = 0; req.resume(); reject(error); } else resolve(value);
      };
      const failure = (status, code, message) => Object.assign(new Error(message), { status, code });
      const timer = setTimeout(() => finish(failure(408, 'request_timeout', 'JSON request body timed out')), 15000);
      req.on('data', chunk => {
        if (settled) return;
        bytes += chunk.length;
        if (bytes > 1048576) return finish(failure(413, 'payload_too_large', 'Request body exceeds 1MB limit'));
        chunks.push(chunk);
      });
      req.once('end', () => {
        if (settled) return;
        try {
          // Decode once: Arabic/emoji split across TCP chunks must not corrupt.
          const body = new TextDecoder('utf-8', { fatal: true }).decode(Buffer.concat(chunks));
          const parsed = body.trim() ? JSON.parse(body) : {};
          if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error('Expected JSON object');
          finish(null, parsed);
        } catch (_) { finish(failure(400, 'invalid_json', 'Expected a valid UTF-8 JSON object')); }
      });
      req.once('error', error => finish(error));
      req.once('aborted', () => finish(failure(400, 'request_aborted', 'Request was aborted')));
    });
  }

  /**
   * Main request handler
   */
  async handle(req, res) {
    const startTime = Date.now();
    const parsedUrl = new URL(req.url, 'http://127.0.0.1');
    const pathname = parsedUrl.pathname;
    const method = req.method.toUpperCase();

    // Log request on completion
    res.on('finish', () => {
      const duration = Date.now() - startTime;
      logger.info(`${method} ${pathname} ${res.statusCode} ${duration}ms`);
    });

    try {
      // 1. PUBLIC: GET /health
      if (pathname === '/health') {
        if (method !== 'GET') return this.sendError(res, 405, 'method_not_allowed', 'Method not allowed');
        const ocStatus = this.supervisor.getStatus();
        const uptimeSec = Math.floor((Date.now() - Date.parse(this.startedAt)) / 1000);
        return this.sendJson(res, 200, {
          ok: true,
          gateway: '1.0.0',
          opencode: {
            running: ocStatus.running,
            version: ocStatus.version
          },
          uptimeSec
        });
      }

      // 2. PUBLIC: POST /pair/redeem
      if (pathname === '/pair/redeem') {
        if (method !== 'POST') return this.sendError(res, 405, 'method_not_allowed', 'Method not allowed');
        const body = await this.parseJsonBody(req);
        const code = body.code;
        const deviceName = body.deviceName === undefined ? 'Device' : body.deviceName;
        if (typeof deviceName !== 'string' || !deviceName.trim() || deviceName.length > 100 || /[\x00-\x1f\x7f]/.test(deviceName)) return this.sendError(res, 400, 'invalid_device_name', 'Device name must be 1-100 characters without control characters');

        if (!code || typeof code !== 'string') {
          return this.sendError(res, 401, 'invalid_code', 'Invalid or expired pairing code');
        }

        const clientIp = this.getClientIp(req);
        const redeemRes = this.pairingManager.redeem(code, clientIp);

        if (!redeemRes.success) {
          const headers = redeemRes.retryAfter ? { 'Retry-After': String(redeemRes.retryAfter) } : {};
          return this.sendError(res, redeemRes.status, redeemRes.error, redeemRes.message, headers);
        }

        // Successfully redeemed: register device
        let credential;
        try {
          credential = this.authManager.registerDevice(deviceName);
        } catch (regErr) {
          return this.sendError(res, regErr.status || 500, regErr.code || 'internal_error', regErr.message);
        }

        return this.sendJson(res, 200, {
          deviceId: credential.deviceId,
          deviceToken: credential.deviceToken
        });
      }

      // 3. AUTHENTICATION REQUIRED for all subsequent endpoints
      const device = this.authManager.authenticate(req.headers.authorization);
      if (!device) {
        return this.sendError(res, 401, 'unauthorized', 'Unauthorized');
      }
      req.device = device;

      // 4. OPENCODE PASSTHROUGH: ANY /oc/*
      if (pathname === '/oc' || pathname.startsWith('/oc/')) {
        return this.proxy.handle(req, res);
      }

      // 5. GATEWAY: GET /gateway/status
      if (pathname === '/gateway/status') {
        if (method !== 'GET') return this.sendError(res, 405, 'method_not_allowed', 'Method not allowed');
        const doc = await doctor.runDoctor(this.config);
        const ocStatus = this.supervisor.getStatus();
        const ghStatus = this.githubClient.getStatus();
        const uptimeSec = Math.floor((Date.now() - Date.parse(this.startedAt)) / 1000);

        return this.sendJson(res, 200, {
          gateway: {
            version: '1.0.0',
            uptimeSec,
            startedAt: this.startedAt
          },
          opencode: {
            running: ocStatus.running,
            version: ocStatus.version,
            restarts: ocStatus.restarts,
            lastError: ocStatus.lastError
          },
          github: ghStatus,
          system: doc.system,
          tools: doc.tools,
          device: {
            id: req.device.id,
            name: req.device.name
          }
        });
      }

      // 6. GATEWAY: Devices
      if (pathname === '/gateway/devices') {
        if (method !== 'GET') return this.sendError(res, 405, 'method_not_allowed', 'Method not allowed');
        const list = this.authManager.listDevices(req.device.id);
        return this.sendJson(res, 200, list);
      }

      if (pathname === '/gateway/devices/rotate') {
        if (method !== 'POST') return this.sendError(res, 405, 'method_not_allowed', 'Method not allowed');
        const rotated = this.authManager.rotateDevice(req.device.id);
        return this.sendJson(res, 200, {
          deviceToken: rotated.deviceToken
        });
      }

      const devMatch = /^\/gateway\/devices\/([^/]+)$/.exec(pathname);
      if (devMatch) {
        const targetDeviceId = devMatch[1];
        if (method === 'DELETE') {
          try {
            this.authManager.revokeDevice(targetDeviceId);
            res.writeHead(204);
            return res.end();
          } catch (err) {
            return this.sendError(res, err.status || 500, err.code || 'internal_error', err.message);
          }
        }
        return this.sendError(res, 405, 'method_not_allowed', 'Method not allowed');
      }

      // 7. GATEWAY: GitHub
      if (pathname === '/gateway/github') {
        if (method === 'GET') {
          return this.sendJson(res, 200, this.githubClient.getStatus());
        }
        if (method === 'PUT') {
          const body = await this.parseJsonBody(req);
          try {
            const result = await this.githubClient.setToken(body.token);
            return this.sendJson(res, 200, result);
          } catch (err) {
            return this.sendError(res, err.status || 500, err.code || 'internal_error', err.message);
          }
        }
        if (method === 'DELETE') {
          await this.githubClient.removeToken();
          res.writeHead(204);
          return res.end();
        }
        return this.sendError(res, 405, 'method_not_allowed', 'Method not allowed');
      }

      if (pathname === '/gateway/github/repos') {
        if (method === 'GET') {
          const page = parsedUrl.searchParams.get('page') || '1';
          try {
            const repos = await this.githubClient.listRepos(page);
            return this.sendJson(res, 200, repos);
          } catch (err) {
            return this.sendError(res, err.status || 500, err.code || 'internal_error', err.message);
          }
        }
        if (method === 'POST') {
          const body = await this.parseJsonBody(req);
          try {
            const repo = await this.githubClient.createRepo(body);
            return this.sendJson(res, 201, repo);
          } catch (err) {
            return this.sendError(res, err.status || 500, err.code || 'internal_error', err.message);
          }
        }
        return this.sendError(res, 405, 'method_not_allowed', 'Method not allowed');
      }

      // 8. GATEWAY: Projects
      if (pathname === '/gateway/projects') {
        if (method === 'GET') {
          return this.sendJson(res, 200, this.projectsManager.list());
        }
        if (method === 'POST') {
          const body = await this.parseJsonBody(req);
          try {
            const project = await this.projectsManager.create(body);
            return this.sendJson(res, 201, project);
          } catch (err) {
            return this.sendError(res, err.status || 500, err.code || 'internal_error', err.message);
          }
        }
        return this.sendError(res, 405, 'method_not_allowed', 'Method not allowed');
      }

      // Projects subroutes: /gateway/projects/:id(/git|/artifacts|/download)
      const projSubMatch = /^\/gateway\/projects\/([^/]+)(\/(git|artifacts|download))?$/.exec(pathname);
      if (projSubMatch) {
        const projectId = projSubMatch[1];
        const subAction = projSubMatch[3];

        if (!subAction) {
          // Direct /gateway/projects/{id}
          if (method === 'PATCH') {
            const body = await this.parseJsonBody(req);
            try {
              const updated = await this.projectsManager.update(projectId, body);
              return this.sendJson(res, 200, updated);
            } catch (err) {
              return this.sendError(res, err.status || 500, err.code || 'internal_error', err.message);
            }
          }
          if (method === 'DELETE') {
            const confirm = parsedUrl.searchParams.get('confirm');
            try {
              await this.projectsManager.delete(projectId, confirm);
              res.writeHead(204);
              return res.end();
            } catch (err) {
              return this.sendError(res, err.status || 500, err.code || 'internal_error', err.message);
            }
          }
          return this.sendError(res, 405, 'method_not_allowed', 'Method not allowed');
        }

        if (subAction === 'git') {
          if (method !== 'GET') return this.sendError(res, 405, 'method_not_allowed', 'Method not allowed');
          try {
            const gitStatus = await this.projectsManager.getGitStatus(projectId);
            return this.sendJson(res, 200, gitStatus);
          } catch (err) {
            return this.sendError(res, err.status || 500, err.code || 'internal_error', err.message);
          }
        }

        if (subAction === 'artifacts') {
          if (method !== 'GET') return this.sendError(res, 405, 'method_not_allowed', 'Method not allowed');
          try {
            const artifacts = await this.artifactsManager.scanProject(projectId);
            return this.sendJson(res, 200, artifacts);
          } catch (err) {
            return this.sendError(res, err.status || 500, err.code || 'internal_error', err.message);
          }
        }

        if (subAction === 'download') {
          if (method !== 'GET') return this.sendError(res, 405, 'method_not_allowed', 'Method not allowed');
          const relPath = parsedUrl.searchParams.get('path');
          if (!relPath) {
            return this.sendError(res, 400, 'missing_path', 'Query parameter "path" is required');
          }
          return this.artifactsManager.handleDownload(projectId, relPath, req, res);
        }
      }

      // Route not found
      return this.sendError(res, 404, 'not_found', 'Route not found');
    } catch (err) {
      logger.error('Unhandled request error', err);
      if (!res.headersSent) {
        return this.sendError(res, err.status || 500, err.code || 'internal_error', err.message || 'Internal error', err.status === 413 || err.status === 408 ? { Connection: 'close' } : {});
      }
      res.end();
    }
  }
}

module.exports = Router;
