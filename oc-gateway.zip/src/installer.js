'use strict';

const fs = require('fs');
const path = require('path');
const logger = require('./logger');
const { runCommand } = require('./commands');
const { PINNED_OPENCODE_VERSION } = require('./config');

function resolveNpm() {
  const candidate = path.join(path.dirname(process.execPath), process.platform === 'win32' ? 'npm.cmd' : 'npm');
  return fs.existsSync(candidate) ? candidate : 'npm';
}

class OpenCodeInstaller {
  constructor(config, dependencies = {}) {
    this.config = config;
    this.root = config.ROOT_DIR;
    this.runtime = config.RUNTIME_DIR || path.join(this.root, 'runtime');
    this.binary = config.OPENCODE_BIN || path.join(this.runtime, 'node_modules', '.bin', 'opencode');
    this.version = config.OPENCODE_VERSION || PINNED_OPENCODE_VERSION;
    if (this.version !== 'latest' && !/^\d+\.\d+\.\d+$/.test(this.version)) throw new Error('Invalid OpenCode package version');
    this.run = dependencies.runCommand || runCommand;
    this.npm = dependencies.resolveNpm || resolveNpm;
    this.pending = null;
    this.controller = new AbortController();
    this.lastError = null;
    this.actualVersion = null;
    for (const value of Object.values(config.PROVIDER_KEYS || {})) logger.registerSecret(value);
  }

  environment() {
    const home = path.join(this.config.DATA_DIR, 'home');
    const cache = path.join(this.config.DATA_DIR, 'npm-cache');
    for (const dir of [home, cache, this.runtime]) fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
    // Do not pass gateway/device/GitHub/model credentials to npm lifecycle
    // scripts. OpenCode receives model keys separately in its supervisor.
    const env = { PATH: process.env.PATH || path.dirname(process.execPath), HOME: home,
      LANG: process.env.LANG || 'C.UTF-8', npm_config_cache: cache,
      npm_config_registry: 'https://registry.npmjs.org', npm_config_update_notifier: 'false' };
    for (const key of ['TMPDIR', 'TMP', 'TEMP', 'HTTP_PROXY', 'HTTPS_PROXY', 'NO_PROXY', 'NODE_EXTRA_CA_CERTS']) {
      if (process.env[key]) { env[key] = process.env[key]; if (/PROXY$/.test(key)) logger.registerSecret(env[key]); }
    }
    return env;
  }

  async verify() {
    if (!fs.existsSync(this.binary)) return false;
    const command = this.binary.endsWith('.js') ? process.execPath : this.binary;
    const args = this.binary.endsWith('.js') ? [this.binary, '--version'] : ['--version'];
    const result = await this.run(command, args, { cwd: this.root, env: this.environment(),
      timeoutMs: 10000, signal: this.controller.signal });
    const match = result.stdout.trim().match(/(?:^|\n)(\d+\.\d+\.\d+)(?:\r?\n|$)/);
    if (!result.ok || !match || (this.version !== 'latest' && match[1] !== this.version)) return false;
    this.actualVersion = match[1];
    return true;
  }

  ensureInstalled() {
    if (this.pending) return this.pending;
    const operation = this._ensureInstalled();
    this.pending = operation;
    operation.finally(() => { if (this.pending === operation) this.pending = null; }).catch(() => {});
    return operation;
  }

  async _ensureInstalled() {
    this.lastError = null;
    if (await this.verify()) {
      logger.info(`[BOOTSTRAP] OpenCode CLI verified: v${this.actualVersion}; reusing installed files`);
      return true;
    }
    if (this.config.OPENCODE_BIN) {
      this.lastError = 'Configured OPENCODE_BIN is missing, cannot execute, or has the wrong version';
      logger.error(`[BOOTSTRAP] ${this.lastError}`);
      return false;
    }
    if (this.version === 'latest') logger.warn('[BOOTSTRAP] latest is unpinned; OC Pilot compatibility has only been checked with 1.18.35');
    const args = ['install', '--prefix', this.runtime, '--no-audit', '--no-fund', '--omit=dev',
      '--include=optional', `opencode-ai@${this.version}`];
    const attempts = this.config.OPENCODE_INSTALL_RETRIES || 3;
    for (let attempt = 1; attempt <= attempts && !this.controller.signal.aborted; attempt++) {
      logger.info(`[BOOTSTRAP] Executing npm install opencode-ai@${this.version} --prefix runtime (${attempt}/${attempts})`);
      const result = await this.run(this.npm(), args, { cwd: this.root, env: this.environment(),
        timeoutMs: (this.config.OPENCODE_INSTALL_TIMEOUT_SEC || 600) * 1000,
        signal: this.controller.signal, onLine: line => logger.info(`[npm] ${line}`) });
      if (result.ok && await this.verify()) {
        logger.info(`[BOOTSTRAP] Installation and opencode --version verified: v${this.actualVersion}`);
        return true;
      }
      this.lastError = result.cancelled ? 'OpenCode installation cancelled' : result.timedOut ? 'OpenCode npm installation timed out' : result.error ? `OpenCode npm command failed (${result.error})` : result.ok ? 'OpenCode installation finished but CLI version verification failed' : `OpenCode npm install exited with code ${result.code}`;
      logger.warn(`[BOOTSTRAP] ${this.lastError}`);
      if (attempt < attempts && !this.controller.signal.aborted) await this._retryDelay();
    }
    if (!this.lastError) this.lastError = 'OpenCode installation cancelled';
    return false;
  }

  _retryDelay() {
    return new Promise(resolve => {
      let timer;
      const done = () => { clearTimeout(timer); this.controller.signal.removeEventListener('abort', done); resolve(); };
      timer = setTimeout(done, 3000);
      this.controller.signal.addEventListener('abort', done, { once: true });
      if (this.controller.signal.aborted) done();
    });
  }

  async stop() {
    this.controller.abort();
    if (this.pending) await this.pending.catch(() => {});
  }
}

module.exports = { OpenCodeInstaller, resolveNpm };
