'use strict';

const https = require('https');
const fs = require('fs');
const path = require('path');
const logger = require('./logger');

class GitHubClient {
  constructor(config, stateManager, supervisor, proxy) {
    this.config = config;
    this.stateManager = stateManager;
    this.supervisor = supervisor;
    this.proxy = proxy;
    this.askpassPath = path.join(config.DATA_DIR, 'git-askpass.sh');
    this._credentialEpoch = 0;
    this._restartInterval = null;
    this._stopped = false;

    this._ensureAskpassScript();
  }

  _ensureAskpassScript() {
    if (!fs.existsSync(this.config.DATA_DIR)) {
      fs.mkdirSync(this.config.DATA_DIR, { recursive: true, mode: 0o700 });
    }

    const script = `#!/bin/sh
case "$1" in
  Username*) echo "x-access-token" ;;
  *) echo "$GH_TOKEN" ;;
esac
`;
    try {
      fs.writeFileSync(this.askpassPath, script, { mode: 0o700 });
      try {
        fs.chmodSync(this.askpassPath, 0o700);
      } catch (e) {}
    } catch (err) {
      logger.error('Failed to create git-askpass.sh', err);
    }
  }

  /**
   * Helper to make GitHub API requests
   */
  _request(method, apiPath, token, body = null) {
    return new Promise((resolve, reject) => {
      const headers = {
        'Authorization': `Bearer ${token}`,
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28',
        'User-Agent': 'oc-gateway'
      };

      let bodyData = null;
      if (body) {
        bodyData = JSON.stringify(body);
        headers['Content-Type'] = 'application/json';
        headers['Content-Length'] = Buffer.byteLength(bodyData);
      }

      const req = https.request(
        {
          hostname: 'api.github.com',
          path: apiPath,
          method,
          headers,
          timeout: 10000
        },
        (res) => {
          const chunks = []; let bytes = 0;
          res.on('data', chunk => {
            bytes += chunk.length;
            if (bytes > 2 * 1024 * 1024) {
              chunks.length = 0; res.destroy();
              reject(Object.assign(new Error('GitHub response exceeds 2MB limit'), { status: 502, code: 'github_unreachable' }));
            } else chunks.push(chunk);
          });
          res.once('error', () => reject(Object.assign(new Error('GitHub response was interrupted'), { status: 502, code: 'github_unreachable' })));
          res.once('end', () => {
            const resData = Buffer.concat(chunks).toString('utf8');
            let json = null;
            try { if (resData) json = JSON.parse(resData); } catch (_) {}
            resolve({ statusCode: res.statusCode, headers: res.headers, body: json, rawBody: resData });
          });
        }
      );

      req.on('timeout', () => {
        req.destroy();
        const err = new Error('GitHub API request timed out');
        err.code = 'github_unreachable';
        err.status = 504;
        reject(err);
      });

      req.on('error', (e) => {
        const err = new Error(`GitHub API network error: ${e.message}`);
        err.code = 'github_unreachable';
        err.status = 502;
        reject(err);
      });

      if (bodyData) {
        req.write(bodyData);
      }
      req.end();
    });
  }

  stop() {
    this._stopped = true; ++this._credentialEpoch;
    if (this._restartInterval) clearInterval(this._restartInterval);
    this._restartInterval = null;
  }

  getDecryptedToken() {
    const gh = this.stateManager.github;
    if (!gh || !gh.ciphertext || !gh.iv || !gh.tag) return null;
    try {
      const token = this.stateManager.decrypt(gh.ciphertext, gh.iv, gh.tag);
      logger.registerSecret(token);
      return token;
    } catch (err) {
      logger.error('Failed to decrypt GitHub token', err);
      return null;
    }
  }

  getStatus() {
    const gh = this.stateManager.github;
    if (gh && gh.login) {
      return {
        connected: true,
        login: gh.login,
        scopes: Array.isArray(gh.scopes) ? gh.scopes : []
      };
    }
    return {
      connected: false,
      login: null,
      scopes: []
    };
  }

  _scheduleRestart() {
    if (!this.supervisor || this._stopped) return;
    if (this._restartInterval) clearInterval(this._restartInterval);
    this._restartInterval = null;

    const performRestart = () => {
      this.supervisor.restart().catch(err => {
        logger.error('Failed to restart OpenCode after GitHub config change', err);
      });
    };

    if (!this.proxy || this.proxy.getActiveStreamCount() === 0) {
      performRestart();
      return;
    }

    logger.info('SSE stream active; delaying OpenCode restart up to 60s for GitHub update');
    const start = Date.now();
    const interval = this._restartInterval = setInterval(() => {
      const streams = this.proxy.getActiveStreamCount();
      const elapsed = Date.now() - start;
      if (streams === 0 || elapsed >= 60000) {
        clearInterval(interval);
        this._restartInterval = null;
        if (!this._stopped) performRestart();
      }
    }, 1000);
  }

  /**
   * PUT /gateway/github - Validate and save token
   */
  async setToken(token) {
    if (!token || typeof token !== 'string' || token.trim().length === 0) {
      const err = new Error('Missing or empty GitHub token');
      err.status = 400;
      err.code = 'invalid_github_token';
      throw err;
    }

    const cleanToken = token.trim();
    if (!/^[A-Za-z0-9._~+/-]{8,512}={0,2}$/.test(cleanToken)) {
      throw Object.assign(new Error('Invalid GitHub token format'), { status: 400, code: 'invalid_github_token' });
    }
    const epoch = ++this._credentialEpoch;
    logger.registerSecret(cleanToken);

    let res;
    try {
      res = await this._request('GET', '/user', cleanToken);
    } catch (netErr) {
      throw netErr;
    }

    if (epoch !== this._credentialEpoch || this._stopped) throw Object.assign(new Error('GitHub settings changed while validation was in progress; submit again if needed'), { status: 409, code: 'github_operation_changed' });
    if (res.statusCode === 403) throw Object.assign(new Error('GitHub denied validation or rate-limited this request'), { status: 403, code: res.headers['x-ratelimit-remaining'] === '0' ? 'github_rate_limited' : 'github_permission_denied' });
    if (res.statusCode !== 200 || !res.body || typeof res.body.login !== 'string' || !res.body.login) {
      const err = new Error('GitHub token validation failed');
      err.status = 400;
      err.code = 'invalid_github_token';
      throw err;
    }

    // Extract scopes from X-OAuth-Scopes
    const rawScopes = res.headers['x-oauth-scopes'] || '';
    const scopes = rawScopes
      ? rawScopes.split(',').map(s => s.trim()).filter(Boolean)
      : [];

    const encrypted = this.stateManager.encrypt(cleanToken);
    this.stateManager.github = {
      ciphertext: encrypted.ciphertext,
      iv: encrypted.iv,
      tag: encrypted.tag,
      login: res.body.login,
      scopes
    };

    this.stateManager.flush();
    this._ensureAskpassScript();
    this._scheduleRestart();

    return {
      connected: true,
      login: res.body.login,
      scopes
    };
  }

  /**
   * DELETE /gateway/github - Disconnect GitHub
   */
  async removeToken() {
    ++this._credentialEpoch;
    this.stateManager.github = null;
    this.stateManager.flush();

    try {
      if (fs.existsSync(this.askpassPath)) {
        fs.unlinkSync(this.askpassPath);
      }
    } catch (e) {}

    this._scheduleRestart();
  }

  /**
   * GET /gateway/github/repos - List user repositories
   */
  async listRepos(page = 1) {
    const token = this.getDecryptedToken();
    if (!token) {
      const err = new Error('GitHub account is not connected');
      err.status = 409;
      err.code = 'github_required';
      throw err;
    }

    const pageNum = Math.max(1, Number.parseInt(page, 10) || 1);
    const apiPath = `/user/repos?per_page=30&page=${pageNum}&sort=updated&affiliation=owner,collaborator,organization_member`;

    const res = await this._request('GET', apiPath, token);

    if (res.statusCode === 401) {
      const err = new Error('GitHub token has expired or is invalid');
      err.status = 400;
      err.code = 'github_token_invalid';
      throw err;
    }

    if (res.statusCode === 403) {
      const isRate = (res.headers['x-ratelimit-remaining'] === '0') ||
        (res.body && res.body.message && res.body.message.toLowerCase().includes('rate limit'));
      const err = new Error(isRate ? 'GitHub API rate limit exceeded' : 'GitHub permission denied');
      err.status = 403;
      err.code = isRate ? 'github_rate_limited' : 'github_permission_denied';
      throw err;
    }

    if (res.statusCode !== 200 || !Array.isArray(res.body)) {
      const err = new Error('Failed to fetch GitHub repositories');
      err.status = 502;
      err.code = 'github_unreachable';
      throw err;
    }

    return res.body.map(r => ({
      fullName: r.full_name,
      private: !!r.private,
      defaultBranch: r.default_branch || 'main',
      description: r.description || null,
      updatedAt: r.updated_at
    }));
  }

  /**
   * POST /gateway/github/repos - Create a new repository
   */
  async createRepo({ name, private: isPrivate = true, description = '' }) {
    const token = this.getDecryptedToken();
    if (!token) {
      const err = new Error('GitHub account is not connected');
      err.status = 409;
      err.code = 'github_required';
      throw err;
    }

    if (!name || typeof name !== 'string' || !/^[A-Za-z0-9._-]{1,100}$/.test(name)) {
      const err = new Error('Invalid repository name; must be 1-100 alphanumeric characters, dots, underscores, or dashes');
      err.status = 400;
      err.code = 'invalid_repo_name';
      throw err;
    }

    const payload = {
      name,
      private: !!isPrivate,
      description: description || '',
      auto_init: false
    };

    const res = await this._request('POST', '/user/repos', token, payload);

    if (res.statusCode === 403) {
      const err = new Error('GitHub permission denied; token requires repo scope');
      err.status = 403;
      err.code = 'github_permission_denied';
      throw err;
    }

    if (res.statusCode === 401) {
      const err = new Error('GitHub token invalid');
      err.status = 400;
      err.code = 'github_token_invalid';
      throw err;
    }

    if (res.statusCode !== 201 || !res.body) {
      const err = new Error((res.body && res.body.message) || 'Failed to create GitHub repository');
      err.status = res.statusCode >= 400 && res.statusCode < 500 ? res.statusCode : 502;
      err.code = 'github_error';
      throw err;
    }

    return {
      fullName: res.body.full_name,
      defaultBranch: res.body.default_branch || 'main',
      cloneUrl: res.body.clone_url
    };
  }
}

module.exports = GitHubClient;
