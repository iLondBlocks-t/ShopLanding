'use strict';

const fs = require('fs');
const path = require('path');
const http = require('http');
const crypto = require('crypto');
const { spawn } = require('child_process');
const { EventEmitter } = require('events');
const { StringDecoder } = require('string_decoder');
const { killTree } = require('./commands');
const logger = require('./logger');

const BACKOFF = [1, 2, 4, 8, 15, 30];

class OpenCodeSupervisor extends EventEmitter {
  constructor(config, stateManager) {
    super();
    this.config = config;
    this.stateManager = stateManager;
    this.rootDir = config.ROOT_DIR || path.resolve(__dirname, '..');
    this.binaryPath = config.OPENCODE_BIN || path.join(config.RUNTIME_DIR || path.join(this.rootDir, 'runtime'), 'node_modules/.bin/opencode');
    this.port = config.OPENCODE_PORT || 4096;
    this.username = config.OPENCODE_SERVER_USERNAME || 'opencode';
    this.passwordFile = path.join(config.DATA_DIR, 'opencode-password');
    fs.mkdirSync(config.DATA_DIR, { recursive: true, mode: 0o700 });
    this.password = fs.existsSync(this.passwordFile) ? fs.readFileSync(this.passwordFile, 'utf8').trim() : '';
    if (!this.password) {
      this.password = crypto.randomBytes(32).toString('base64url');
      fs.writeFileSync(this.passwordFile, this.password, { mode: 0o600 });
    }
    fs.chmodSync(this.passwordFile, 0o600);
    logger.registerSecret(this.password);
    logger.registerSecret(Buffer.from(`${this.username}:${this.password}`).toString('base64'));
    for (const value of Object.values(config.PROVIDER_KEYS || {})) logger.registerSecret(value);
    this.child = null; this.running = false; this.version = null;
    this.restarts = 0; this.lastError = null; this.logRing = [];
    this._generation = 0; this._backoffIndex = 0;
    this._restartTimer = null; this._pollTimer = null; this._uptimeTimer = null; this._healthRequest = null;
    this._isStopping = false; this._restartPromise = null;
  }

  _appendLog(line) {
    if (!line) return;
    this.logRing.push(logger.redact(String(line).trim()).slice(0, 4096));
    if (this.logRing.length > 300) this.logRing.shift();
  }
  getLogs(count = 50) { return this.logRing.slice(-Math.max(1, Math.min(300, count))); }
  getBasicAuthHeader() { return 'Basic ' + Buffer.from(`${this.username}:${this.password}`).toString('base64'); }

  _buildEnv() {
    const home = path.join(this.config.DATA_DIR, 'home');
    fs.mkdirSync(home, { recursive: true, mode: 0o700 });
    const env = {
      PATH: `${path.dirname(process.execPath)}${path.delimiter}${process.env.PATH || ''}`,
      TERM: 'dumb', LANG: process.env.LANG || 'C.UTF-8', HOME: home,
      XDG_DATA_HOME: path.join(home, '.local/share'), XDG_CONFIG_HOME: path.join(home, '.config'),
      XDG_CACHE_HOME: path.join(home, '.cache'), XDG_STATE_HOME: path.join(home, '.local/state'),
      OPENCODE_SERVER_PASSWORD: this.password, OPENCODE_SERVER_USERNAME: this.username,
      OPENCODE_DISABLE_AUTOUPDATE: '1', GIT_TERMINAL_PROMPT: '0'
    };
    if (this.config.OPENCODE_DISABLE_MODELS_FETCH) env.OPENCODE_DISABLE_MODELS_FETCH = '1';
    for (const [key, value] of Object.entries(this.config.PROVIDER_KEYS || {})) if (value) env[key] = value;
    for (const key of ['HTTP_PROXY', 'HTTPS_PROXY', 'NO_PROXY', 'NODE_EXTRA_CA_CERTS', 'SSL_CERT_FILE', 'SSL_CERT_DIR']) if (process.env[key]) env[key] = process.env[key];
    const gh = this.stateManager.github;
    if (gh && gh.ciphertext && gh.iv && gh.tag) {
      try {
        const token = this.stateManager.decrypt(gh.ciphertext, gh.iv, gh.tag);
        logger.registerSecret(token);
        Object.assign(env, { GH_TOKEN: token, GITHUB_TOKEN: token, GIT_ASKPASS: path.join(this.config.DATA_DIR, 'git-askpass.sh') });
        if (gh.login) Object.assign(env, { GIT_AUTHOR_NAME: gh.login, GIT_COMMITTER_NAME: gh.login,
          GIT_AUTHOR_EMAIL: `${gh.login}@users.noreply.github.com`, GIT_COMMITTER_EMAIL: `${gh.login}@users.noreply.github.com` });
      } catch (error) { logger.error('Could not decrypt server GitHub credential', error); }
    }
    return env;
  }

  _clearTimers() {
    for (const key of ['_restartTimer', '_pollTimer', '_uptimeTimer']) { clearTimeout(this[key]); this[key] = null; }
    if (this._healthRequest) { this._healthRequest.destroy(); this._healthRequest = null; }
  }

  _pollReadiness(generation, startedAt) {
    if (this._isStopping || generation !== this._generation || !this.child) return;
    if (Date.now() - startedAt >= (this.config.OPENCODE_READY_TIMEOUT_SEC || 90) * 1000) {
      this.lastError = 'OpenCode readiness timed out; check console logs and available RAM';
      logger.error(this.lastError);
      killTree(this.child);
      return;
    }
    let finished = false;
    const retry = () => {
      if (finished) return;
      finished = true;
      if (this._isStopping || generation !== this._generation || !this.child) return;
      this._healthRequest = null;
      this._pollTimer = setTimeout(() => this._pollReadiness(generation, startedAt), 500);
    };
    const req = http.request({ hostname: '127.0.0.1', port: this.port, path: '/global/health', method: 'GET',
      headers: { Authorization: this.getBasicAuthHeader(), Accept: 'application/json' }, timeout: 2000 }, res => {
      const chunks = []; let size = 0;
      res.on('data', chunk => { size += chunk.length; if (size > 65536) req.destroy(); else chunks.push(chunk); });
      res.on('error', retry);
      res.on('end', () => {
        if (finished || generation !== this._generation || this._isStopping) return;
        let data;
        try { data = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch (_) { return retry(); }
        if (res.statusCode !== 200 || !data || data.healthy !== true || typeof data.version !== 'string') return retry();
        finished = true; this._healthRequest = null;
        this.running = true; this.version = data.version; this.lastError = null;
        this._uptimeTimer = setTimeout(() => { if (generation === this._generation) this._backoffIndex = 0; }, 120000);
        logger.info(`OpenCode is ready (v${this.version}) on PRIVATE loopback port ${this.port}`);
        this.emit('ready', this.getStatus());
      });
    });
    this._healthRequest = req;
    req.on('timeout', () => req.destroy());
    req.on('error', retry);
    req.end();
  }

  _watchOutput(stream, label) {
    const decoder = new StringDecoder('utf8'); let pending = '', omitted = false;
    const accept = text => {
      pending += text;
      let at;
      while ((at = pending.search(/[\r\n]/)) !== -1) {
        const line = pending.slice(0, at);
        this._appendLog(`[${label}] ${omitted || line.length > 4096 ? '[oversized log line omitted]' : line}`);
        omitted = false; pending = pending.slice(at + 1);
      }
      if (pending.length > 4096) { pending = ''; omitted = true; }
    };
    stream.on('data', bytes => accept(decoder.write(bytes)));
    stream.on('end', () => { accept(decoder.end()); if (pending || omitted) this._appendLog(`[${label}] ${omitted ? '[oversized log line omitted]' : pending}`); });
  }

  start() {
    if (this._isStopping || this.child) return;
    this._clearTimers();
    if (!fs.existsSync(this.binaryPath)) {
      this.running = false; this.lastError = 'OpenCode executable is missing; run install-opencode in the hosting console';
      logger.warn(this.lastError); return;
    }
    const generation = ++this._generation;
    const serveArgs = ['serve', '--hostname', '127.0.0.1', '--port', String(this.port)];
    const isNodeScript = this.binaryPath.endsWith('.js');
    logger.info('[OpenCode] Executing opencode serve --hostname 127.0.0.1 (not exposed to the internet)');
    let child;
    try {
      child = spawn(isNodeScript ? process.execPath : this.binaryPath, isNodeScript ? [this.binaryPath, ...serveArgs] : serveArgs,
        { cwd: this.config.WORKSPACE_DIR, env: this._buildEnv(), shell: false, detached: process.platform !== 'win32', stdio: ['ignore', 'pipe', 'pipe'] });
    } catch (error) { this.lastError = logger.redact(`OpenCode spawn failed: ${error.code || 'unknown'}`); return; }
    this.child = child;
    this._watchOutput(child.stdout, 'stdout'); this._watchOutput(child.stderr, 'stderr');
    child.once('error', error => {
      if (generation !== this._generation) return;
      this.running = false; this.lastError = `OpenCode process error (${error.code || 'unknown'})`;
      logger.error(this.lastError);
    });
    child.once('close', (code, signal) => {
      if (generation !== this._generation) return;
      this.child = null; this.running = false; this._clearTimers();
      if (this._isStopping) return;
      this.restarts++;
      this.lastError = `OpenCode exited: code=${code}, signal=${signal || 'none'}`;
      this._appendLog(this.lastError); logger.warn(this.lastError);
      const delay = BACKOFF[Math.min(this._backoffIndex++, BACKOFF.length - 1)];
      this._restartTimer = setTimeout(() => this.start(), delay * 1000);
    });
    this._pollReadiness(generation, Date.now());
  }

  waitUntilReady(timeoutMs = (this.config.OPENCODE_READY_TIMEOUT_SEC || 90) * 1000 + 500) {
    if (this.running) return Promise.resolve(true);
    if (this._isStopping) return Promise.resolve(false);
    return new Promise(resolve => {
      let timer;
      const done = value => { clearTimeout(timer); this.removeListener('ready', ready); this.removeListener('stopped', stopped); resolve(value); };
      const ready = () => done(true), stopped = () => done(false);
      this.once('ready', ready); this.once('stopped', stopped);
      timer = setTimeout(() => done(false), timeoutMs);
    });
  }

  async _retireChild() {
    ++this._generation; this._clearTimers(); this.running = false;
    const old = this.child; this.child = null;
    if (!old || old.exitCode !== null || old.signalCode !== null) return;
    await new Promise(resolve => {
      let force, deadline;
      const finish = () => { clearTimeout(force); clearTimeout(deadline); resolve(); };
      old.once('close', finish);
      force = setTimeout(() => killTree(old, 'SIGKILL'), 5000);
      deadline = setTimeout(finish, 6500);
      killTree(old);
    });
  }

  restart() {
    if (this._isStopping) return Promise.resolve();
    if (this._restartPromise) return this._restartPromise;
    this._restartPromise = (async () => {
      await this._retireChild();
      if (!this._isStopping) this.start();
    })().finally(() => { this._restartPromise = null; });
    return this._restartPromise;
  }

  async stop() {
    this._isStopping = true; this.emit('stopped');
    await this._retireChild();
    if (this._restartPromise) await this._restartPromise;
  }

  getStatus() { return { running: this.running, version: this.version, restarts: this.restarts, lastError: this.lastError }; }
}

module.exports = OpenCodeSupervisor;
