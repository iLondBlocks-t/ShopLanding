'use strict';

const crypto = require('crypto');

const ALPHABET = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';

class PairingManager {
  constructor(config = {}) {
    this.ttlSec = config.PAIR_CODE_TTL_SEC || 300;
    this.now = () => Date.now(); // Injectable clock

    this.activeCode = null; // { code: 'ABCD-EFGH', raw: 'ABCDEFGH', createdAt: number }
    this.ipAttempts = new Map(); // ip -> Array<timestamp>
    this.globalFailedAttempts = []; // Array<timestamp>
    this.lockoutUntil = 0;
  }

  setClock(fn) {
    this.now = fn;
  }

  /**
   * Normalize pairing code:
   * Uppercase, strip non [0-9A-Z], map O -> 0, I -> 1, L -> 1.
   */
  static normalize(input) {
    if (!input || typeof input !== 'string') return '';
    return input
      .toUpperCase()
      .replace(/[^0-9A-Z]/g, '')
      .replace(/O/g, '0')
      .replace(/[IL]/g, '1');
  }

  /**
   * Generate a fresh 8-char Crockford base32 code formatted as XXXX-XXXX.
   * Invalidates any previous code.
   */
  generateCode() {
    let raw = '';
    for (let i = 0; i < 8; i++) {
      raw += ALPHABET[crypto.randomInt(0, ALPHABET.length)];
    }
    const formatted = `${raw.slice(0, 4)}-${raw.slice(4, 8)}`;
    this.activeCode = {
      code: formatted,
      raw,
      createdAt: this.now()
    };
    return formatted;
  }

  getActiveCode() {
    if (!this.activeCode) return null;
    if (this.now() - this.activeCode.createdAt > this.ttlSec * 1000) {
      return null;
    }
    return this.activeCode.code;
  }

  /**
   * Attempt to redeem a code.
   * Returns:
   *   { success: true }
   * or
   *   { success: false, status: 401 | 429, error: string, message: string, retryAfter?: number }
   */
  redeem(inputCode, clientIp = '127.0.0.1') {
    const currentTime = this.now();

    // 1. Check global lockout
    if (this.lockoutUntil > currentTime) {
      const retryAfter = Math.max(1, Math.ceil((this.lockoutUntil - currentTime) / 1000));
      return {
        success: false,
        status: 429,
        error: 'rate_limited',
        message: 'Pairing is temporarily locked due to too many failed attempts',
        retryAfter
      };
    }

    // 2. Per-IP rate limiting: max 10 attempts per 60s
    const oneMinAgo = currentTime - 60 * 1000;
    let ipHistory = this.ipAttempts.get(clientIp) || [];
    ipHistory = ipHistory.filter(t => t > oneMinAgo);
    this.ipAttempts.set(clientIp, ipHistory);

    if (ipHistory.length >= 10) {
      const oldestInWindow = ipHistory[0];
      const retryAfter = Math.max(1, Math.ceil((oldestInWindow + 60 * 1000 - currentTime) / 1000));
      return {
        success: false,
        status: 429,
        error: 'rate_limited',
        message: 'Too many attempts from this IP, please wait',
        retryAfter
      };
    }

    ipHistory.push(currentTime);

    // 3. Constant-time code check
    const normalizedInput = PairingManager.normalize(inputCode);
    const active = this.activeCode;
    const isExpired = !active || (currentTime - active.createdAt > this.ttlSec * 1000);

    const target = active ? PairingManager.normalize(active.raw) : '00000000';
    const inputHash = crypto.createHash('sha256').update(normalizedInput).digest();
    const targetHash = crypto.createHash('sha256').update(target).digest();

    const isMatch = crypto.timingSafeEqual(inputHash, targetHash) && normalizedInput.length === 8 && !isExpired;

    if (!isMatch) {
      // Record global failure
      const fifteenMinAgo = currentTime - 15 * 60 * 1000;
      this.globalFailedAttempts = this.globalFailedAttempts.filter(t => t > fifteenMinAgo);
      this.globalFailedAttempts.push(currentTime);

      if (this.globalFailedAttempts.length >= 50) {
        this.lockoutUntil = currentTime + 15 * 60 * 1000;
        const retryAfter = 15 * 60;
        return {
          success: false,
          status: 429,
          error: 'rate_limited',
          message: 'Pairing locked due to repeated failures',
          retryAfter
        };
      }

      return {
        success: false,
        status: 401,
        error: 'invalid_code',
        message: 'Invalid or expired pairing code'
      };
    }

    // Success! Single use: invalidate immediately
    this.activeCode = null;
    return { success: true };
  }
}

module.exports = PairingManager;
