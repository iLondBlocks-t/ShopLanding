'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const logger = require('./logger');

const HOP_HEADERS = new Set(['connection', 'keep-alive', 'proxy-authenticate', 'proxy-authorization', 'te', 'trailer', 'transfer-encoding', 'upgrade', 'cookie', 'set-cookie']);
const SCOPED_HEADERS = new Set(['authorization', 'host', 'x-project-id', 'x-opencode-directory', 'x-opencode-workspace']);
const jsonError = (res, status, error, message) => {
  if (res.headersSent) return res.destroy();
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
  res.end(JSON.stringify({ error, message: logger.redact(message) }));
};

class OpenCodeProxy {
  constructor(config, stateManager, supervisor, authManager) {
    Object.assign(this, { config, stateManager, supervisor, authManager });
    this.activeStreams = new Set();
    this._onRevoke = id => this._closeDeviceStreams(id);
    if (authManager) { authManager.on('revoke', this._onRevoke); authManager.on('rotate', this._onRevoke); }
    this._validationInterval = setInterval(() => this._revalidateStreams(), 30000);
    this._validationInterval.unref();
  }
  getActiveStreamCount() { return this.activeStreams.size; }
  _endStream(stream) {
    if (stream.cleanup) stream.cleanup();
    try { stream.res.end(); } catch (_) {}
    this.activeStreams.delete(stream);
  }
  _closeDeviceStreams(id) { for (const stream of [...this.activeStreams]) if (stream.deviceId === id) this._endStream(stream); }
  _revalidateStreams() {
    for (const stream of [...this.activeStreams]) {
      const device = this.stateManager.devices.find(value => value.id === stream.deviceId);
      if (!device || device.tokenHash !== stream.tokenHash) this._endStream(stream);
    }
  }
  stop() {
    clearInterval(this._validationInterval);
    if (this.authManager) { this.authManager.removeListener('revoke', this._onRevoke); this.authManager.removeListener('rotate', this._onRevoke); }
    for (const stream of [...this.activeStreams]) this._endStream(stream);
  }

  _projectDirectory(project) {
    const workspace = fs.realpathSync(this.config.WORKSPACE_DIR);
    const candidate = path.resolve(workspace, project.dirName);
    if (!candidate.startsWith(workspace + path.sep)) throw new Error('Project path escapes workspace');
    const directory = fs.realpathSync(candidate);
    if (!directory.startsWith(workspace + path.sep)) throw new Error('Project symlink escapes workspace');
    return directory;
  }

  handle(req, res) {
    if (!this.supervisor.running) return jsonError(res, 503, 'opencode_unavailable', this.supervisor.lastError || 'OpenCode is installing, starting or unavailable');
    let url;
    try { url = new URL(req.url.slice(3), 'http://127.0.0.1'); }
    catch (_) { return jsonError(res, 400, 'invalid_request', 'Invalid OpenCode path'); }
    const projectId = req.headers['x-project-id'];
    // The client NEVER selects an upstream filesystem directory/workspace.
    url.searchParams.delete('directory'); url.searchParams.delete('location[directory]');
    let directory;
    if (projectId) {
      const project = this.stateManager.projects.find(value => value.id === projectId);
      if (!project) return jsonError(res, 404, 'project_not_found', 'Project not found');
      try { directory = this._projectDirectory(project); }
      catch (_) { return jsonError(res, 403, 'forbidden_path', 'Project directory is missing or outside the workspace'); }
      url.searchParams.set('directory', directory);
      project.lastActivityAt = new Date().toISOString(); this.stateManager.save();
    }
    const extraHop = new Set(String(req.headers.connection || '').toLowerCase().split(',').map(value => value.trim()));
    const headers = {};
    for (const [key, value] of Object.entries(req.headers)) {
      const lower = key.toLowerCase();
      if (!HOP_HEADERS.has(lower) && !SCOPED_HEADERS.has(lower) && !extraHop.has(lower)) headers[lower] = value;
    }
    headers.authorization = this.supervisor.getBasicAuthHeader();
    headers.host = `127.0.0.1:${this.supervisor.port}`;
    headers['accept-encoding'] = 'identity';
    if (directory) headers['x-opencode-directory'] = encodeURIComponent(directory);
    let clientClosed = false, bodyRejected = false;
    const upstream = http.request({ hostname: '127.0.0.1', port: this.supervisor.port,
      path: url.pathname + url.search, method: req.method, headers }, upstreamRes => {
      if (clientClosed || bodyRejected) { upstreamRes.destroy(); return; }
      // An upstream Basic-auth failure is NOT a revoked phone credential.
      if (upstreamRes.statusCode === 401) {
        upstreamRes.resume();
        return jsonError(res, 503, 'opencode_unavailable', 'Private OpenCode authentication failed; restart OpenCode from the hosting console');
      }
      const isSse = String(upstreamRes.headers['content-type'] || '').includes('text/event-stream');
      const responseHeaders = {};
      const responseHop = new Set(String(upstreamRes.headers.connection || '').toLowerCase().split(',').map(value => value.trim()));
      for (const [key, value] of Object.entries(upstreamRes.headers)) if (!HOP_HEADERS.has(key) && !responseHop.has(key)) responseHeaders[key] = value;
      let stream;
      if (isSse) {
        delete responseHeaders['content-length'];
        Object.assign(responseHeaders, { 'content-type': 'text/event-stream', 'cache-control': 'no-cache', connection: 'keep-alive', 'x-accel-buffering': 'no' });
        stream = { res, deviceId: req.device ? req.device.id : null, tokenHash: req.device ? req.device.tokenHash : null };
        let pingTimer;
        const resetPing = () => {
          clearTimeout(pingTimer);
          if (clientClosed) return;
          pingTimer = setTimeout(() => {
            if (!res.destroyed && !res.writableEnded && res.writableLength < 65536) res.write(': ping\n\n');
            resetPing();
          }, 15000);
        };
        stream.cleanup = () => { clearTimeout(pingTimer); this.activeStreams.delete(stream); upstreamRes.destroy(); upstream.destroy(); };
        this.activeStreams.add(stream);
        upstreamRes.on('data', resetPing); resetPing();
      }
      res.writeHead(upstreamRes.statusCode, responseHeaders);
      if (isSse && res.flushHeaders) res.flushHeaders();
      if (isSse && res.socket) res.socket.setNoDelay(true);
      upstreamRes.once('error', error => {
        if (!clientClosed && !bodyRejected) logger.warn('OpenCode response stream ended unexpectedly', error);
        if (stream) stream.cleanup();
        res.destroy();
      });
      upstreamRes.once('end', () => {
        if (stream) { this.activeStreams.delete(stream); stream.cleanup(); }
      });
      res.once('close', () => { if (stream) stream.cleanup(); });
      // pipe applies backpressure; SSE data is never aggregated or fabricated.
      upstreamRes.pipe(res);
    });
    let received = 0;
    req.on('data', chunk => {
      received += chunk.length;
      if (received > 50 * 1024 * 1024 && !bodyRejected) {
        bodyRejected = true; req.unpipe(upstream); upstream.destroy(); req.resume();
        jsonError(res, 413, 'payload_too_large', 'Request exceeds 50MB limit');
      }
    });
    req.once('aborted', () => { clientClosed = true; upstream.destroy(); });
    res.once('close', () => { clientClosed = true; if (!res.writableFinished) upstream.destroy(); });
    upstream.once('error', error => {
      if (clientClosed || bodyRejected) return;
      logger.warn('OpenCode upstream connection failed', error);
      jsonError(res, 503, 'opencode_unavailable', 'Private OpenCode is unavailable; check hosting console status / logs');
    });
    req.pipe(upstream);
  }
}

module.exports = OpenCodeProxy;
