'use strict';
// Real HTTPS provider calls. Transport injection exists only for explicit tests.
const https = require('https');
const logger = require('./logger');

// Chat-completions IDs confirmed in the official pinned Zen documentation.
const ZEN_CHAT_MODELS = new Set(["qwen3.8-max", "deepseek-v4.1-flash", "deepseek-v4-pro", "deepseek-v4-flash", "deepseek-v4-flash-vision-exp", "minimax-m3", "minimax-m2.7", "minimax-m2.5", "glm-5.3-flash", "glm-5.3", "glm-5.2", "glm-5.1", "glm-5", "kimi-k2.5", "kimi-k2.6", "kimi-k2.7-code", "kimi-k3", "big-pickle", "space-bunny-free", "longcat-2.5-preview-free", "fledge-alpha-free", "mimo-v2.6-flash-free", "mimo-v2.5-free", "ling-3.1-flash-free", "ling-3.0-flash-fin-free", "nemotron-3-ultra-free", "nemotron-3.5-lightning-free"]);
const fail = (code, status = 400) => Object.assign(new Error(code), { code, status });
function transport(url, method, headers, body, signal, timeout = 120000) {
  return new Promise((resolve, reject) => {
    const target = new URL(url);
    if (target.protocol !== 'https:' || target.username || target.password) return reject(fail('invalid_service_url'));
    const payload = body == null ? null : Buffer.from(JSON.stringify(body));
    const request = https.request(target, { method, headers: { Accept: 'application/json', ...headers,
      ...(payload ? { 'Content-Type': 'application/json', 'Content-Length': payload.length } : {}) } }, response => {
      const chunks = []; let size = 0;
      response.on('data', chunk => {
        size += chunk.length;
        if (size > 32 * 1024 * 1024) request.destroy(fail('service_response_too_large', 502)); else chunks.push(chunk);
      });
      response.once('error', reject);
      response.once('end', () => resolve({ status: response.statusCode, bytes: Buffer.concat(chunks), type: String(response.headers['content-type'] || '') }));
    });
    const timer = setTimeout(() => request.destroy(fail('service_timeout', 504)), timeout);
    const cancel = () => request.destroy(fail('cancelled'));
    if (signal) { signal.addEventListener('abort', cancel, { once: true }); if (signal.aborted) cancel(); }
    request.once('close', () => { clearTimeout(timer); if (signal) signal.removeEventListener('abort', cancel); });
    request.once('error', reject);
    request.end(payload);
  });
}

class Services {
  constructor(config, call = transport) {
    this.config = config; this.call = call; this.ready = false; this.checked = false; this.models = []; this.error = '';
    const keys = config.PROVIDER_KEYS || {};
    const candidate = config.CHAT_PROVIDER && config.CHAT_PROVIDER !== 'auto' ? config.CHAT_PROVIDER
      : keys.OPENAI_API_KEY ? 'openai' : keys.OPENCODE_API_KEY ? 'opencode' : keys.OPENROUTER_API_KEY ? 'openrouter' : '';
    this.provider = candidate;
    this.base = { openai: 'https://api.openai.com/v1', opencode: 'https://opencode.ai/zen/v1', openrouter: 'https://openrouter.ai/api/v1' }[candidate];
    this.key = keys[{ openai: 'OPENAI_API_KEY', opencode: 'OPENCODE_API_KEY', openrouter: 'OPENROUTER_API_KEY' }[candidate]];
    this.name = { openai: 'OpenAI', opencode: 'OpenCode Zen', openrouter: 'OpenRouter' }[candidate] || '';
    this.openaiKey = keys.OPENAI_API_KEY; this.musicKey = config.ELEVENLABS_API_KEY;
    for (const value of [...Object.values(keys), this.musicKey]) logger.registerSecret(value);
    this.model = config.CHAT_MODEL || '';
    this.controllers = new Set(); this.mediaReady = { image: false, speech: false, music: false };
    this.pendingProbe = null; this.stopped = false;
  }
  get configured() { return Boolean(this.base && this.key); }
  info() { return { ready: this.ready, configured: this.configured, verified: this.checked, service: this.name,
    model: this.model, error: this.error, attachments: true, maxUploadMB: this.config.UPLOAD_MAX_MB || 20,
    image: this.mediaReady.image, speech: this.mediaReady.speech, music: this.mediaReady.music }; }
  async request(base, key, route, method = 'GET', body = null, signal = null, timeout = 120000, music = false) {
    if (this.stopped) throw fail('cancelled');
    const response = await this.call(base + route, method, music ? { 'xi-api-key': key } : { Authorization: 'Bearer ' + key }, body, signal, timeout);
    if (response.status < 200 || response.status >= 300) {
      // Never echo remote error bodies, credentials or billing details to a phone/log.
      throw fail(response.status === 401 || response.status === 403 ? 'service_auth_failed'
        : response.status === 429 ? 'service_limit' : 'service_request_failed', response.status === 429 ? 429 : 502);
    }
    return response;
  }
  json(response) {
    try { return JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(response.bytes)); }
    catch (_) { throw fail('service_invalid_response', 502); }
  }
  probe() {
    if (this.pendingProbe) return this.pendingProbe;
    this.pendingProbe = this._probe().finally(() => { this.pendingProbe = null; });
    return this.pendingProbe;
  }
  async _probe() {
    const controller = new AbortController(); this.controllers.add(controller);
    try {
      this.ready = false; this.error = ''; this.checked = false;
      if (this.configured) {
        try {
          const json = this.json(await this.request(this.base, this.key, '/models', 'GET', null, controller.signal, 15000));
          if (!Array.isArray(json.data)) throw fail('service_invalid_response', 502);
          this.models = json.data.filter(m => m && (this.provider !== 'opencode' || ZEN_CHAT_MODELS.has(m.id)) && typeof m.id === 'string' && /^[a-zA-Z0-9_.:/-]{1,200}$/.test(m.id));
          if (!this.model) {
            const preferred = this.provider === 'openai' ? ['gpt-4o-mini', 'gpt-4.1-mini', 'gpt-5-mini'] : this.provider === 'opencode' ? ['big-pickle', 'minimax-m2.5', 'kimi-k2.5'] : [];
            this.model = preferred.find(id => this.models.some(m => m.id === id)) || (this.models.find(m => !/embed|tts|whisper|image|dall-e|moderation/i.test(m.id)) || {}).id || '';
          }
          if (!this.model || !this.models.some(m => m.id === this.model)) throw fail('service_model_unavailable');
          this.ready = true;
          // Zen/OpenRouter model catalogues can be public. Listing alone is not
          // proof that a credential is accepted for inference.
          this.checked = this.provider === 'openai';
          if (this.provider === 'openrouter') {
            await this.request(this.base, this.key, '/key', 'GET', null, controller.signal, 15000); this.checked = true;
          }
        } catch (error) { this.ready = false; this.checked = false; this.error = error.code || 'service_unavailable'; }
      } else this.error = 'service_not_configured';
      this.mediaReady = { image: false, speech: false, music: false };
      if (this.openaiKey) {
        try {
          const catalogue = this.provider === 'openai' && this.checked ? this.models
            : this.json(await this.request('https://api.openai.com/v1', this.openaiKey, '/models', 'GET', null, controller.signal, 15000)).data;
          if (!Array.isArray(catalogue)) throw fail('service_invalid_response');
          this.mediaReady.image = catalogue.some(m => m && m.id === (this.config.IMAGE_MODEL || 'gpt-image-1'));
          this.mediaReady.speech = catalogue.some(m => m && m.id === (this.config.SPEECH_MODEL || 'gpt-4o-mini-tts'));
        } catch (_) {}
      }
      if (this.musicKey) {
        try { const user = this.json(await this.request('https://api.elevenlabs.io', this.musicKey, '/v1/user', 'GET', null, controller.signal, 15000, true)); this.mediaReady.music = Boolean(user && typeof user.subscription === 'object' && user.subscription); }
        catch (_) {}
      }
      return this.ready;
    } finally { this.controllers.delete(controller); }
  }
  async complete(messages, tools, signal) {
    if (!this.ready) throw fail(this.error || 'service_unavailable', 503);
    const body = { model: this.model, messages, ...(tools && tools.length ? { tools } : {}), stream: false };
    let json;
    try { json = this.json(await this.request(this.base, this.key, '/chat/completions', 'POST', body, signal)); }
    catch (error) { this.error = error.code || 'service_unavailable'; if (this.error === 'service_auth_failed') { this.ready = false; this.checked = false; } throw error; }
    const message = json.choices && json.choices[0] && json.choices[0].message;
    if (!message || (!message.content && !Array.isArray(message.tool_calls))) throw fail('service_invalid_response', 502);
    this.checked = true; this.error = ""; return { message, usage: json.usage || {} };
  }
  async generate(kind, prompt, signal) {
    if (!this.mediaReady[kind]) throw fail('feature_unavailable', 503);
    const max = kind === 'music' ? 1000 : kind === 'speech' ? 4096 : 4000;
    if (typeof prompt !== 'string' || !prompt.trim() || prompt.length > max) throw fail('invalid_prompt');
    if (kind === 'image') {
      const json = this.json(await this.request('https://api.openai.com/v1', this.openaiKey, '/images/generations', 'POST',
        { model: this.config.IMAGE_MODEL || 'gpt-image-1', prompt, n: 1, size: '1024x1024' }, signal, 300000));
      const b64 = json.data && json.data[0] && json.data[0].b64_json;
      if (typeof b64 !== 'string' || !/^[A-Za-z0-9+/=\r\n]+$/.test(b64)) throw fail('service_invalid_response', 502);
      const bytes = Buffer.from(b64, 'base64');
      if (!bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) throw fail('service_invalid_response', 502);
      return { bytes, extension: 'png' };
    }
    const response = kind === 'speech' ? await this.request('https://api.openai.com/v1', this.openaiKey, '/audio/speech', 'POST',
      { model: this.config.SPEECH_MODEL || 'gpt-4o-mini-tts', input: prompt, voice: this.config.SPEECH_VOICE || 'alloy', response_format: 'mp3' }, signal, 180000)
      : await this.request('https://api.elevenlabs.io', this.musicKey, '/v1/music?output_format=mp3_44100_128', 'POST',
        { prompt, model_id: this.config.MUSIC_MODEL || 'music_v1', music_length_ms: 30000 }, signal, 600000, true);
    if (!response.bytes.length || (!response.type.startsWith('audio/') && !response.type.includes('octet-stream'))) throw fail('service_invalid_response', 502);
    const bytes = response.bytes;
    if (bytes.subarray(0, 3).toString() !== 'ID3' && !(bytes[0] === 255 && (bytes[1] & 224) === 224)) throw fail('service_invalid_response', 502);
    return { bytes, extension: 'mp3' };
  }
  stop() { this.stopped = true; for (const c of this.controllers) c.abort(); }
}
module.exports = { Services, fail, transport };
