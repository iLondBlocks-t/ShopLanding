'use strict';

const { spawn } = require('child_process');
const { StringDecoder } = require('string_decoder');

function killTree(child, signal = 'SIGTERM') {
  if (!child || child.exitCode !== null || child.signalCode !== null) return;
  try {
    if (process.platform !== 'win32' && child.pid) process.kill(-child.pid, signal);
    else child.kill(signal);
  } catch (_) { try { child.kill(signal); } catch (_) {} }
}

// Every command is an executable + argument array. No shell, eval or HTTP
// endpoint is used to install OpenCode. Signals also reach npm grandchildren.
function runCommand(command, args, options = {}) {
  return new Promise(resolve => {
    let child, settled = false, timedOut = false, cancelled = false, forceTimer;
    let stdout = '', stderr = '';
    const maximum = options.maxOutputChars || 65536;
    const decoders = { stdout: new StringDecoder('utf8'), stderr: new StringDecoder('utf8') };
    const lines = { stdout: '', stderr: '' };
    const omitted = { stdout: false, stderr: false };
    const consume = (name, text, end = false) => {
      if (name === 'stdout') stdout = (stdout + text).slice(-maximum);
      else stderr = (stderr + text).slice(-maximum);
      lines[name] += text;
      let at;
      while ((at = lines[name].search(/[\r\n]/)) !== -1) {
        const line = lines[name].slice(0, at);
        lines[name] = lines[name].slice(at + 1);
        if (options.onLine && (line || omitted[name])) options.onLine(omitted[name] || line.length > 4096 ? '[oversized command output line omitted]' : line, name);
        omitted[name] = false;
      }
      if (lines[name].length > 4096) { lines[name] = ''; omitted[name] = true; }
      if (end && (lines[name] || omitted[name])) {
        if (options.onLine) options.onLine(omitted[name] ? '[oversized command output line omitted]' : lines[name], name);
        lines[name] = ''; omitted[name] = false;
      }
    };
    let timer;
    const finish = (code, signal, error = null) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer); clearTimeout(forceTimer);
      if (options.signal) options.signal.removeEventListener('abort', cancel);
      for (const name of ['stdout', 'stderr']) consume(name, decoders[name].end(), true);
      resolve({ ok: code === 0 && !error && !timedOut && !cancelled, code, signal, error, timedOut, cancelled, stdout, stderr });
    };
    const terminate = () => {
      killTree(child, 'SIGTERM');
      forceTimer = setTimeout(() => killTree(child, 'SIGKILL'), 1500);
    };
    const cancel = () => { cancelled = true; terminate(); };
    if (options.signal && options.signal.aborted) { cancelled = true; return finish(null, null, 'cancelled'); }
    try {
      child = spawn(command, args, { cwd: options.cwd, env: options.env, shell: false,
        detached: process.platform !== 'win32', stdio: ['ignore', 'pipe', 'pipe'] });
    } catch (error) { return finish(null, null, error.code || 'spawn_failed'); }
    child.stdout.on('data', chunk => consume('stdout', decoders.stdout.write(chunk)));
    child.stderr.on('data', chunk => consume('stderr', decoders.stderr.write(chunk)));
    child.once('error', error => finish(null, null, error.code || 'spawn_failed'));
    child.once('close', (code, signal) => finish(code, signal));
    timer = setTimeout(() => { timedOut = true; terminate(); }, options.timeoutMs || 30000);
    if (options.signal) {
      options.signal.addEventListener('abort', cancel, { once: true });
      if (options.signal.aborted) cancel();
    }
  });
}

module.exports = { runCommand, killTree };
