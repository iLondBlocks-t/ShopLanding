'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawn } = require('child_process');
const logger = require('./logger');
const doctor = require('./doctor');

class ProjectsManager {
  constructor(config, stateManager, githubClient) {
    this.config = config;
    this.stateManager = stateManager;
    this.githubClient = githubClient;
    this.workspaceDir = config.WORKSPACE_DIR;
    this.minFreeDiskMB = config.MIN_FREE_DISK_MB === undefined ? 200 : config.MIN_FREE_DISK_MB;

    this.mutexMap = new Map(); // id -> Promise chain for serializing operations

    this._ensureWorkspaceDir();
  }

  _ensureWorkspaceDir() {
    if (!fs.existsSync(this.workspaceDir)) {
      fs.mkdirSync(this.workspaceDir, { recursive: true, mode: 0o700 });
    }
  }

  /**
   * Run an asynchronous task locked by key (e.g. project id)
   */
  async _withLock(key, fn) {
    const prev = this.mutexMap.get(key) || Promise.resolve();
    let release;
    const next = new Promise(resolve => { release = resolve; });
    const chain = prev.then(() => next);
    this.mutexMap.set(key, chain);

    await prev;
    try {
      return await fn();
    } finally {
      release();
      if (this.mutexMap.get(key) === chain) {
        this.mutexMap.delete(key);
      }
    }
  }

  static generateSlug(name) {
    return name
      .toLowerCase()
      .replace(/[^a-z0-9-]+/g, '-')
      .replace(/^-+|-+$/g, '')
      .slice(0, 40) || 'project';
  }

  static validateName(name) {
    if (!name || typeof name !== 'string') return false;
    if (name.length < 1 || name.length > 60) return false;
    // Check for control characters (ASCII 0-31 and 127)
    if (/[\x00-\x1F\x7F]/.test(name)) return false;
    return true;
  }

  /**
   * Verify that a relative path stays strictly within the project directory.
   * Throws 403 forbidden_path if path attempts traversal or symlink escapes.
   */
  safePath(projectDir, relativePath) {
    if (!relativePath || typeof relativePath !== 'string') {
      const err = new Error('Invalid path parameter');
      err.status = 403;
      err.code = 'forbidden_path';
      throw err;
    }

    if (relativePath.includes('\0') || path.isAbsolute(relativePath)) {
      const err = new Error('Access denied: absolute paths or null bytes forbidden');
      err.status = 403;
      err.code = 'forbidden_path';
      throw err;
    }

    // Resolve project real path
    let realProjectDir;
    try {
      realProjectDir = fs.realpathSync(projectDir);
    } catch (e) {
      const err = new Error('Project directory does not exist');
      err.status = 404;
      err.code = 'not_found';
      throw err;
    }

    const resolvedTarget = path.resolve(realProjectDir, relativePath);

    // If target exists, resolve its realpath
    if (fs.existsSync(resolvedTarget)) {
      const realTarget = fs.realpathSync(resolvedTarget);
      if (realTarget !== realProjectDir && !realTarget.startsWith(realProjectDir + path.sep)) {
        const err = new Error('Access denied: path escapes project root');
        err.status = 403;
        err.code = 'forbidden_path';
        throw err;
      }
      return realTarget;
    }

    // Target does not exist yet: verify its parent directory stays within project root
    let curr = path.dirname(resolvedTarget);
    while (curr && !fs.existsSync(curr)) {
      const parent = path.dirname(curr);
      if (parent === curr) break;
      curr = parent;
    }

    try {
      const realCurr = fs.realpathSync(curr);
      if (realCurr !== realProjectDir && !realCurr.startsWith(realProjectDir + path.sep)) {
        const err = new Error('Access denied: target path escapes project root');
        err.status = 403;
        err.code = 'forbidden_path';
        throw err;
      }
    } catch (e) {
      const err = new Error('Access denied: invalid path');
      err.status = 403;
      err.code = 'forbidden_path';
      throw err;
    }

    return resolvedTarget;
  }

  /**
   * Execute a git command using spawn
   */
  _runGit(args, cwd, env = {}, timeout = 10000) {
    return new Promise((resolve, reject) => {
      const gitPath = 'git';
      const childEnv = { ...process.env, ...env };

      let stdout = '';
      let stderr = '';
      let timedOut = false;

      const child = spawn(gitPath, args, {
        cwd,
        env: childEnv,
        shell: false,
        stdio: ['ignore', 'pipe', 'pipe']
      });

      const timer = setTimeout(() => {
        timedOut = true;
        child.kill('SIGKILL');
      }, timeout);

      child.stdout.on('data', d => { stdout += d.toString('utf8'); });
      child.stderr.on('data', d => { stderr += d.toString('utf8'); });

      child.on('error', (err) => {
        clearTimeout(timer);
        if (err.code === 'ENOENT') {
          const e = new Error('Git is not installed on this server');
          e.status = 501;
          e.code = 'git_unavailable';
          reject(e);
        } else {
          reject(err);
        }
      });

      child.on('close', (code) => {
        clearTimeout(timer);
        if (timedOut) {
          const err = new Error(`Git command '${args[0]}' timed out after ${timeout / 1000}s`);
          err.status = 504;
          err.code = 'git_timeout';
          return reject(err);
        }
        resolve({ code, stdout, stderr });
      });
    });
  }

  /**
   * List all projects
   */
  list() {
    return this.stateManager.projects.map(p => ({
      id: p.id,
      name: p.name,
      repoFullName: p.repoFullName || null,
      branch: p.branch || null,
      archived: !!p.archived,
      createdAt: p.createdAt,
      lastActivityAt: p.lastActivityAt
    }));
  }

  /**
   * Get single project by id
   */
  get(id) {
    return this.stateManager.projects.find(p => p.id === id);
  }

  /**
   * Create a new project (empty, clone, or createRepo + clone)
   */
  async create({ name, repoFullName, createRepo }) {
    if (!ProjectsManager.validateName(name)) {
      const err = new Error('Project name must be 1-60 characters and contain no control characters');
      err.status = 400;
      err.code = 'invalid_name';
      throw err;
    }

    // Check duplicate repoFullName among active projects
    if (repoFullName) {
      const existing = this.stateManager.projects.find(
        p => !p.archived && p.repoFullName && p.repoFullName.toLowerCase() === repoFullName.toLowerCase()
      );
      if (existing) {
        const err = new Error(`A project for repository "${repoFullName}" already exists`);
        err.status = 409;
        err.code = 'project_exists';
        throw err;
      }
    }

    const id8 = crypto.randomBytes(4).toString('hex');
    const id = `p_${id8}`;
    const slug = ProjectsManager.generateSlug(name);
    const dirName = `${slug}-${id8}`;
    const projectDir = path.join(this.workspaceDir, dirName);

    return this._withLock(id, async () => {
      // Check disk space
      const freeDisk = doctor.getFreeDiskMB(this.workspaceDir);
      if (freeDisk < this.minFreeDiskMB) {
        const err = new Error(`Insufficient disk space: ${freeDisk}MB free, required ${this.minFreeDiskMB}MB`);
        err.status = 507;
        err.code = 'insufficient_storage';
        throw err;
      }

      let effectiveRepo = repoFullName || null;
      let branch = null;

      // Case 1: createRepo requested
      if (createRepo && typeof createRepo === 'object') {
        const created = await this.githubClient.createRepo({
          name: name,
          private: createRepo.private !== false,
          description: createRepo.description || ''
        });
        effectiveRepo = created.fullName;
      }

      // Case 2: clone repo
      if (effectiveRepo) {
        if (!this.githubClient.getStatus().connected) {
          const err = new Error('GitHub account must be connected to clone a repository');
          err.status = 409;
          err.code = 'github_required';
          throw err;
        }

        if (!doctor.checkCommand('git', ['--version'])) {
          const err = new Error('Git is not installed on this server');
          err.status = 501;
          err.code = 'git_unavailable';
          throw err;
        }

        const token = this.githubClient.getDecryptedToken();
        const gh = this.stateManager.github;
        const login = (gh && gh.login) || 'opencode';

        const cloneUrl = `https://github.com/${effectiveRepo}.git`;
        const gitEnv = {
          GH_TOKEN: token,
          GITHUB_TOKEN: token,
          GIT_ASKPASS: this.githubClient.askpassPath,
          GIT_TERMINAL_PROMPT: '0',
          GIT_AUTHOR_NAME: login,
          GIT_COMMITTER_NAME: login,
          GIT_AUTHOR_EMAIL: `${login}@users.noreply.github.com`,
          GIT_COMMITTER_EMAIL: `${login}@users.noreply.github.com`
        };

        try {
          const cloneRes = await this._runGit(
            ['clone', '--depth', '50', cloneUrl, projectDir],
            this.workspaceDir,
            gitEnv,
            300000 // 5 minutes
          );

          if (cloneRes.code !== 0) {
            throw new Error(`Git clone failed: ${cloneRes.stderr || cloneRes.stdout}`);
          }
        } catch (cloneErr) {
          // Clean up half-created directory
          try {
            if (fs.existsSync(projectDir)) {
              fs.rmSync(projectDir, { recursive: true, force: true });
            }
          } catch (e) {}

          const redacted = logger.redact(cloneErr.message);
          const err = new Error(redacted);
          err.status = cloneErr.status || 500;
          err.code = cloneErr.code || 'clone_failed';
          throw err;
        }

        // Detect default branch
        try {
          const bRes = await this._runGit(['rev-parse', '--abbrev-ref', 'HEAD'], projectDir);
          if (bRes.code === 0 && bRes.stdout.trim()) {
            branch = bRes.stdout.trim();
          }
        } catch (e) {}
      } else {
        // Case 3: Empty project / git init
        fs.mkdirSync(projectDir, { recursive: true, mode: 0o700 });

        if (doctor.checkCommand('git', ['--version'])) {
          try {
            await this._runGit(['init'], projectDir);
            const bRes = await this._runGit(['rev-parse', '--abbrev-ref', 'HEAD'], projectDir);
            if (bRes.code === 0 && bRes.stdout.trim() && bRes.stdout.trim() !== 'HEAD') {
              branch = bRes.stdout.trim();
            }
          } catch (e) {}
        }
      }

      const now = new Date().toISOString();
      const projectRecord = {
        id,
        name,
        repoFullName: effectiveRepo,
        branch,
        dirName,
        archived: false,
        createdAt: now,
        lastActivityAt: now
      };

      this.stateManager.projects.push(projectRecord);
      this.stateManager.save();

      return {
        id: projectRecord.id,
        name: projectRecord.name,
        repoFullName: projectRecord.repoFullName,
        branch: projectRecord.branch,
        archived: projectRecord.archived,
        createdAt: projectRecord.createdAt,
        lastActivityAt: projectRecord.lastActivityAt
      };
    });
  }

  /**
   * Update project (name, archived)
   */
  async update(id, { name, archived }) {
    const project = this.get(id);
    if (!project) {
      const err = new Error('Project not found');
      err.status = 404;
      err.code = 'not_found';
      throw err;
    }

    if (name !== undefined) {
      if (!ProjectsManager.validateName(name)) {
        const err = new Error('Invalid project name');
        err.status = 400;
        err.code = 'invalid_name';
        throw err;
      }
      project.name = name;
    }

    if (archived !== undefined) {
      project.archived = Boolean(archived);
    }

    project.lastActivityAt = new Date().toISOString();
    this.stateManager.save();

    return {
      id: project.id,
      name: project.name,
      repoFullName: project.repoFullName,
      branch: project.branch,
      archived: project.archived,
      createdAt: project.createdAt,
      lastActivityAt: project.lastActivityAt
    };
  }

  /**
   * Delete a project
   */
  async delete(id, confirm) {
    if (confirm !== 'true' && confirm !== true) {
      const err = new Error('Project deletion requires confirm=true parameter');
      err.status = 400;
      err.code = 'confirmation_required';
      throw err;
    }

    const project = this.get(id);
    if (!project) {
      const err = new Error('Project not found');
      err.status = 404;
      err.code = 'not_found';
      throw err;
    }

    return this._withLock(id, async () => {
      const projectDir = path.resolve(this.workspaceDir, project.dirName);
      const realWorkspace = fs.realpathSync(this.workspaceDir);

      // Verify directory is inside workspace directory
      if (fs.existsSync(projectDir)) {
        const realProjectDir = fs.realpathSync(projectDir);
        if (realProjectDir !== realWorkspace && realProjectDir.startsWith(realWorkspace + path.sep)) {
          fs.rmSync(projectDir, { recursive: true, force: true });
        }
      }

      const idx = this.stateManager.projects.findIndex(p => p.id === id);
      if (idx !== -1) {
        this.stateManager.projects.splice(idx, 1);
        this.stateManager.save();
      }
    });
  }

  /**
   * GET /gateway/projects/{id}/git
   */
  async getGitStatus(id) {
    const project = this.get(id);
    if (!project) {
      const err = new Error('Project not found');
      err.status = 404;
      err.code = 'not_found';
      throw err;
    }

    if (!doctor.checkCommand('git', ['--version'])) {
      const err = new Error('Git is not installed on this server');
      err.status = 501;
      err.code = 'git_unavailable';
      throw err;
    }

    const projectDir = path.resolve(this.workspaceDir, project.dirName);
    if (!fs.existsSync(projectDir)) {
      const err = new Error('Project directory does not exist');
      err.status = 404;
      err.code = 'not_found';
      throw err;
    }

    let branch = null;
    let dirty = false;
    let ahead = 0;
    const commits = [];

    // 1. Branch
    try {
      const bRes = await this._runGit(['rev-parse', '--abbrev-ref', 'HEAD'], projectDir, {}, 10000);
      if (bRes.code === 0 && bRes.stdout.trim() && bRes.stdout.trim() !== 'HEAD') {
        branch = bRes.stdout.trim();
      }
    } catch (e) {}

    // 2. Status porcelain
    try {
      const sRes = await this._runGit(['status', '--porcelain'], projectDir, {}, 10000);
      if (sRes.code === 0) {
        dirty = sRes.stdout.trim().length > 0;
      }
    } catch (e) {}

    // 3. Ahead
    try {
      const aRes = await this._runGit(['rev-list', '--count', '@{u}..HEAD'], projectDir, {}, 10000);
      if (aRes.code === 0 && aRes.stdout.trim()) {
        const parsed = Number.parseInt(aRes.stdout.trim(), 10);
        if (!Number.isNaN(parsed)) ahead = parsed;
      }
    } catch (e) {}

    // 4. Last 5 commits: %H%x1f%s%x1f%cI
    try {
      const lRes = await this._runGit(['log', '-n', '5', '--format=%H%x1f%s%x1f%cI'], projectDir, {}, 10000);
      if (lRes.code === 0 && lRes.stdout.trim()) {
        const lines = lRes.stdout.trim().split('\n');
        for (const line of lines) {
          const parts = line.split('\x1f');
          if (parts.length >= 3) {
            commits.push({
              sha: parts[0],
              subject: parts[1],
              date: parts[2]
            });
          }
        }
      }
    } catch (e) {}

    return {
      branch,
      dirty,
      ahead,
      lastCommits: commits
    };
  }
}

module.exports = ProjectsManager;
