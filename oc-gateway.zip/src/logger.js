'use strict';

/**
 * Leveled logger and comprehensive sensitive data redaction.
 * Format: 2026-01-01T12:00:00.000Z INFO  message
 */

const LEVELS = {
  debug: 0,
  info: 1,
  warn: 2,
  error: 3
};

let currentLevel = LEVELS.info;
const registeredSecrets = new Set();

// Register secrets from process.env matching KEY|TOKEN|SECRET|PASSWORD (length >= 8)
function initEnvSecrets() {
  for (const [k, v] of Object.entries(process.env)) {
    if (/KEY|TOKEN|SECRET|PASSWORD/i.test(k) && typeof v === 'string' && v.trim().length >= 8) {
      registerSecret(v.trim());
    }
  }
}
initEnvSecrets();

/**
 * Register a secret string to be redacted everywhere.
 * Automatically adds hex and base64 forms if buffer/string.
 */
function registerSecret(secret) {
  if (!secret) return;
  if (typeof secret === 'string' && secret.trim().length >= 4) {
    registeredSecrets.add(secret.trim());
  } else if (Buffer.isBuffer(secret)) {
    if (secret.length >= 4) {
      registeredSecrets.add(secret.toString('hex'));
      registeredSecrets.add(secret.toString('base64'));
      registeredSecrets.add(secret.toString('base64url'));
    }
  }
}

/**
 * Escape special regex characters.
 */
function escapeRegex(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Pattern-based redaction:
 * - ghp_..., github_pat_..., gho_..., ghs_...
 * - sk-ant-..., sk-...
 * - dt_...
 * - Bearer <anything>
 * - Basic <anything>
 * - URLs: https://user:pass@host
 * - Registered secrets (OpenCode password, master key, env vars)
 */
function redactString(text) {
  if (typeof text !== 'string') return text;
  let res = text;

  // 1. Bearer and Basic authentication headers
  res = res.replace(/Bearer\s+[A-Za-z0-9._~+/-]+=*/gi, 'Bearer [REDACTED]');
  res = res.replace(/Basic\s+[A-Za-z0-9._~+/-]+=*/gi, 'Basic [REDACTED]');

  // 2. GitHub tokens (ghp_, github_pat_, gho_, ghs_)
  res = res.replace(/github_pat_[A-Za-z0-9_]+/g, 'github_pat_[REDACTED]');
  res = res.replace(/ghp_[A-Za-z0-9_]+/g, 'ghp_[REDACTED]');
  res = res.replace(/gho_[A-Za-z0-9_]+/g, 'gho_[REDACTED]');
  res = res.replace(/ghs_[A-Za-z0-9_]+/g, 'ghs_[REDACTED]');

  // 3. API keys (sk-ant-..., sk-...)
  res = res.replace(/sk-(?:ant-)?[A-Za-z0-9_-]+/g, 'sk-[REDACTED]');

  // 4. Device tokens (dt_...)
  res = res.replace(/dt_[A-Za-z0-9_-]+/g, 'dt_[REDACTED]');

  // 5. URLs with embedded credentials: https://user:pass@host
  res = res.replace(/(https?:\/\/)([^:\s\/@]+):([^@\s\/]+)@/gi, '$1***:***@');

  // 6. Registered secrets (sorted longest first to avoid partial replacements)
  const secrets = Array.from(registeredSecrets).sort((a, b) => b.length - a.length);
  for (const s of secrets) {
    if (!s || s.length < 4) continue;
    const re = new RegExp(escapeRegex(s), 'g');
    res = res.replace(re, '[REDACTED]');
  }

  return res;
}

/**
 * Recursive redaction for strings, Errors, arrays, and objects.
 */
function redact(val) {
  if (val === null || val === undefined) return val;
  if (typeof val === 'string') return redactString(val);
  if (typeof val === 'number' || typeof val === 'boolean') return val;

  if (val instanceof Error) {
    const err = new Error(redactString(val.message));
    err.name = val.name;
    if (val.stack) {
      err.stack = redactString(val.stack);
    }
    if (val.code) err.code = val.code;
    return err;
  }

  if (Array.isArray(val)) {
    return val.map(item => redact(item));
  }

  if (typeof val === 'object') {
    const out = {};
    for (const [k, v] of Object.entries(val)) {
      out[k] = redact(v);
    }
    return out;
  }

  return val;
}

function setLogLevel(lvl) {
  const norm = String(lvl).toLowerCase().trim();
  if (LEVELS[norm] !== undefined) {
    currentLevel = LEVELS[norm];
  }
}

function formatLevel(lvl) {
  return (lvl.toUpperCase() + '     ').slice(0, 5);
}

function log(levelStr, msg, meta) {
  const lvl = LEVELS[levelStr.toLowerCase()];
  if (lvl === undefined || lvl < currentLevel) return;

  const now = new Date().toISOString();
  let text = typeof msg === 'string' ? msg : (msg instanceof Error ? msg.stack || msg.message : JSON.stringify(msg));
  text = redactString(text);

  if (meta !== undefined) {
    const metaStr = typeof meta === 'string' ? meta : (meta instanceof Error ? meta.stack || meta.message : JSON.stringify(redact(meta)));
    text = `${text} ${redactString(metaStr)}`;
  }

  const out = `${now} ${formatLevel(levelStr)} ${text}`;
  if (lvl >= LEVELS.error) {
    process.stderr.write(out + '\n');
  } else {
    process.stdout.write(out + '\n');
  }
}

module.exports = {
  setLogLevel,
  registerSecret,
  redact,
  debug: (msg, meta) => log('debug', msg, meta),
  info: (msg, meta) => log('info', msg, meta),
  warn: (msg, meta) => log('warn', msg, meta),
  error: (msg, meta) => log('error', msg, meta)
};
