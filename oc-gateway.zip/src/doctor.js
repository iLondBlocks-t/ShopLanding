'use strict';

const os = require('os');
const fs = require('fs');
const path = require('path');
const https = require('https');
const { spawnSync } = require('child_process');
const { runCommand } = require('./commands');

/**
 * Check if a command is executable and returns exit code 0.
 */
function checkCommand(cmd, args) {
  try {
    const res = spawnSync(cmd, args, {
      shell: false,
      timeout: 3000,
      stdio: ['ignore', 'ignore', 'ignore']
    });
    return res.status === 0;
  } catch (err) {
    return false;
  }
}

/**
 * Check if Android SDK directory exists via env vars.
 */
function checkAndroidSdk() {
  const home = process.env.ANDROID_HOME || process.env.ANDROID_SDK_ROOT;
  if (!home) return false;
  try {
    const stat = fs.statSync(home);
    return stat.isDirectory();
  } catch (e) {
    return false;
  }
}

/**
 * Get free disk space in megabytes.
 * Uses fs.statfsSync if available, falling back to df -Pk.
 */
function getFreeDiskMB(dirPath = '.') {
  try {
    if (typeof fs.statfsSync === 'function') {
      const stats = fs.statfsSync(dirPath);
      // bavail: free blocks available to unprivileged user
      // bsize: block size
      const freeBytes = Number(stats.bavail) * Number(stats.bsize);
      return Math.max(0, Math.round(freeBytes / (1024 * 1024)));
    }
  } catch (e) {
    // Fall back to df -Pk
  }

  try {
    const res = spawnSync('df', ['-Pk', dirPath], {
      shell: false,
      timeout: 3000,
      encoding: 'utf8'
    });
    if (res.status === 0 && res.stdout) {
      const lines = res.stdout.trim().split('\n');
      if (lines.length >= 2) {
        const parts = lines[1].trim().split(/\s+/);
        // df -Pk columns: Filesystem 1024-blocks Used Available Capacity Mounted on
        const availKb = Number.parseInt(parts[3], 10);
        if (!Number.isNaN(availKb)) {
          return Math.max(0, Math.round(availKb / 1024));
        }
      }
    }
  } catch (e) {
    // If df fails, return 0
  }

  return 0;
}

/**
 * Check reachability of an HTTPS endpoint.
 */
function checkUrl(urlStr, timeoutMs = 4000) {
  return new Promise((resolve) => {
    try {
      const parsed = new URL(urlStr);
      const req = https.request(
        {
          hostname: parsed.hostname,
          path: parsed.pathname || '/',
          method: 'HEAD',
          timeout: timeoutMs,
          headers: { 'User-Agent': 'oc-gateway-doctor' }
        },
        (res) => {
          resolve(res.statusCode >= 200 && res.statusCode < 500);
        }
      );

      req.on('timeout', () => {
        req.destroy();
        resolve(false);
      });

      req.on('error', () => {
        resolve(false);
      });

      req.end();
    } catch (e) {
      resolve(false);
    }
  });
}

function getMemoryMB(read = file => fs.readFileSync(file, 'utf8')) {
  let total = os.totalmem(), free = os.freemem();
  for (const [limitPath, usedPath] of [
    ['/sys/fs/cgroup/memory.max', '/sys/fs/cgroup/memory.current'],
    ['/sys/fs/cgroup/memory/memory.limit_in_bytes', '/sys/fs/cgroup/memory/memory.usage_in_bytes']
  ]) {
    try {
      const raw = read(limitPath).trim();
      if (!/^\d+$/.test(raw)) continue;
      const limit = Number(raw), used = Number(read(usedPath).trim());
      if (Number.isFinite(limit) && limit > 0 && limit < total && Number.isFinite(used) && used >= 0) {
        total = limit; free = Math.min(free, Math.max(0, limit - used)); break;
      }
    } catch (_) {}
  }
  return { memTotalMB: Math.round(total / 1048576), memFreeMB: Math.round(Math.max(0, Math.min(free, total)) / 1048576) };
}

const diagnostics = new Map();
async function runDoctor(config = {}) {
  const checkDir = config.WORKSPACE_DIR || '.';
  const cacheKey = [process.env.PATH, process.env.ANDROID_HOME, process.env.ANDROID_SDK_ROOT].join('|');
  let cache = diagnostics.get(cacheKey);
  if (!cache || Date.now() - cache.at > 30000) {
    const command = async (executable, args) => (await runCommand(executable, args, { timeoutMs: 3000, maxOutputChars: 1024 })).ok;
    const pending = Promise.all([
      command('git', ['--version']), command('java', ['-version']), command('gradle', ['-v']),
      checkUrl('https://registry.npmjs.org'), checkUrl('https://api.github.com')
    ]).then(([git, java, gradle, npmRegistry, githubApi]) => ({
      tools: { git, java, gradle, node: process.version, androidSdk: checkAndroidSdk() },
      network: { npmRegistry, githubApi }
    }));
    cache = { at: Date.now(), pending }; diagnostics.set(cacheKey, cache);
    if (diagnostics.size > 8) diagnostics.delete(diagnostics.keys().next().value);
  }
  const { tools, network } = await cache.pending;
  const system = { freeDiskMB: getFreeDiskMB(checkDir), ...getMemoryMB() };
  const summary = `git=${tools.git ? 'yes' : 'no'} java=${tools.java ? 'yes' : 'no'} gradle=${tools.gradle ? 'yes' : 'no'} sdk=${tools.androidSdk ? 'yes' : 'no'} disk=${system.freeDiskMB}MB mem=${system.memFreeMB}/${system.memTotalMB}MB`;
  return { system, tools, network, summary };
}

module.exports = { runDoctor, getFreeDiskMB, checkCommand, getMemoryMB };
