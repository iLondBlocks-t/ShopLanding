'use strict';

const crypto = require('crypto');
const { EventEmitter } = require('events');

class AuthManager extends EventEmitter {
  constructor(config, stateManager) {
    super();
    this.config = config;
    this.stateManager = stateManager;
    this.maxDevices = config.MAX_DEVICES || 10;
  }

  static hashToken(token) {
    return crypto.createHash('sha256').update(token).digest('hex');
  }

  static sanitizeName(rawName) {
    if (!rawName || typeof rawName !== 'string') return 'Unknown Device';
    const cleaned = rawName.replace(/[\x00-\x1F\x7F]/g, '').trim().slice(0, 40);
    return cleaned || 'Unknown Device';
  }

  /**
   * Register a new device after pairing code redemption.
   */
  registerDevice(deviceName) {
    const devices = this.stateManager.devices;

    if (devices.length >= this.maxDevices) {
      const err = new Error('Maximum number of paired devices reached');
      err.status = 409;
      err.code = 'too_many_devices';
      throw err;
    }

    const deviceId = crypto.randomUUID();
    const rawBytes = crypto.randomBytes(32);
    const deviceToken = `dt_${rawBytes.toString('base64url')}`;
    const tokenHash = AuthManager.hashToken(deviceToken);
    const now = new Date().toISOString();

    const deviceRecord = {
      id: deviceId,
      tokenHash,
      name: AuthManager.sanitizeName(deviceName),
      createdAt: now,
      lastSeenAt: now
    };

    devices.push(deviceRecord);
    this.stateManager.save();

    return {
      deviceId,
      deviceToken
    };
  }

  /**
   * Authenticate an incoming request.
   * Extracts 'Authorization: Bearer <token>', hashes, and looks up device.
   */
  authenticate(authHeader) {
    if (!authHeader || typeof authHeader !== 'string') {
      return null;
    }

    const parts = authHeader.trim().split(/\s+/);
    if (parts.length !== 2 || parts[0].toLowerCase() !== 'bearer') {
      return null;
    }

    const token = parts[1];
    const incomingHash = AuthManager.hashToken(token);
    const incomingBuf = Buffer.from(incomingHash, 'hex');

    const devices = this.stateManager.devices;
    for (const dev of devices) {
      if (!dev.tokenHash) continue;
      const storedBuf = Buffer.from(dev.tokenHash, 'hex');
      if (storedBuf.length === incomingBuf.length && crypto.timingSafeEqual(storedBuf, incomingBuf)) {
        // Update lastSeenAt at most once per minute
        const now = Date.now();
        const lastSeen = Date.parse(dev.lastSeenAt) || 0;
        if (now - lastSeen > 60000) {
          dev.lastSeenAt = new Date(now).toISOString();
          this.stateManager.save();
        }
        return dev;
      }
    }

    return null;
  }

  /**
   * List all registered devices, flagging current device.
   */
  listDevices(currentDeviceId) {
    return this.stateManager.devices.map(d => ({
      id: d.id,
      name: d.name,
      createdAt: d.createdAt,
      lastSeenAt: d.lastSeenAt,
      current: d.id === currentDeviceId
    }));
  }

  /**
   * Revoke a device by id.
   */
  revokeDevice(deviceId) {
    const devices = this.stateManager.devices;
    const idx = devices.findIndex(d => d.id === deviceId);
    if (idx === -1) {
      const err = new Error('Device not found');
      err.status = 404;
      err.code = 'not_found';
      throw err;
    }

    devices.splice(idx, 1);
    this.stateManager.save();

    // Notify listeners (e.g. proxy SSE) to close open streams within 1s
    this.emit('revoke', deviceId);
  }

  /**
   * Revoke all devices.
   */
  revokeAll() {
    const devices = this.stateManager.devices;
    const ids = devices.map(d => d.id);
    this.stateManager.state.devices = [];
    this.stateManager.save();

    for (const id of ids) {
      this.emit('revoke', id);
    }
  }

  /**
   * Rotate token for an existing device.
   */
  rotateDevice(deviceId) {
    const devices = this.stateManager.devices;
    const dev = devices.find(d => d.id === deviceId);
    if (!dev) {
      const err = new Error('Device not found');
      err.status = 404;
      err.code = 'not_found';
      throw err;
    }

    const rawBytes = crypto.randomBytes(32);
    const newDeviceToken = `dt_${rawBytes.toString('base64url')}`;
    dev.tokenHash = AuthManager.hashToken(newDeviceToken);
    dev.lastSeenAt = new Date().toISOString();
    this.stateManager.save();

    this.emit('rotate', deviceId);

    return {
      deviceToken: newDeviceToken
    };
  }
}

module.exports = AuthManager;
