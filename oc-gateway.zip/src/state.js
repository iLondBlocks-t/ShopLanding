'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const logger = require('./logger');

class StateManager {
  constructor(config) {
    this.config = config;
    this.dataDir = config.DATA_DIR;
    this.statePath = path.join(this.dataDir, 'state.json');
    this.keyPath = path.join(this.dataDir, 'master.key');

    this.masterKey = null;
    this.state = {
      version: 1,
      devices: [],
      projects: [],
      github: null
    };

    this._saveTimer = null;
    this._isDirty = false;
  }

  /**
   * Safe chmod ignoring errors.
   */
  _safeChmod(targetPath, mode) {
    try {
      fs.chmodSync(targetPath, mode);
    } catch (e) {
      // Ignore chmod errors on unsupported filesystems
    }
  }

  /**
   * Ensure data directory exists with 0700 permissions.
   */
  _ensureDataDir() {
    if (!fs.existsSync(this.dataDir)) {
      fs.mkdirSync(this.dataDir, { recursive: true, mode: 0o700 });
    }
    this._safeChmod(this.dataDir, 0o700);
  }

  /**
   * Load or generate 32-byte master key.
   */
  _initMasterKey() {
    this._ensureDataDir();

    if (fs.existsSync(this.keyPath)) {
      this.masterKey = fs.readFileSync(this.keyPath);
      if (this.masterKey.length !== 32) {
        throw new Error('Invalid master.key: restore the private data backup. Existing credentials will not be overwritten.');
      }
    } else {
      if (fs.existsSync(this.statePath)) throw new Error('Missing master.key for existing state.json: restore the private data backup rather than replacing the encryption key.');
      this.masterKey = crypto.randomBytes(32);
      fs.writeFileSync(this.keyPath, this.masterKey, { mode: 0o600 });
    }

    this._safeChmod(this.keyPath, 0o600);

    // Register secrets with logger for redaction
    logger.registerSecret(this.masterKey);
  }

  /**
   * Encrypt a string using AES-256-GCM.
   */
  encrypt(plaintext) {
    if (typeof plaintext !== 'string') {
      throw new TypeError('Plaintext must be a string');
    }
    const iv = crypto.randomBytes(12);
    const cipher = crypto.createCipheriv('aes-256-gcm', this.masterKey, iv);
    let ciphertext = cipher.update(plaintext, 'utf8', 'base64');
    ciphertext += cipher.final('base64');
    const tag = cipher.getAuthTag();

    return {
      ciphertext,
      iv: iv.toString('base64'),
      tag: tag.toString('base64')
    };
  }

  /**
   * Decrypt a ciphertext using AES-256-GCM.
   */
  decrypt(ciphertext, ivStr, tagStr) {
    const iv = Buffer.from(ivStr, 'base64');
    const tag = Buffer.from(tagStr, 'base64');
    const decipher = crypto.createDecipheriv('aes-256-gcm', this.masterKey, iv);
    decipher.setAuthTag(tag);
    let decrypted = decipher.update(ciphertext, 'base64', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
  }

  /**
   * Load and validate state.json.
   */
  init() {
    this._initMasterKey();

    if (!fs.existsSync(this.statePath)) {
      this.state = {
        version: 1,
        devices: [],
        projects: [],
        github: null
      };
      this._writeStateSync();
      return;
    }

    try {
      const raw = fs.readFileSync(this.statePath, 'utf8');
      const parsed = JSON.parse(raw);

      // Validate schema
      if (
        !parsed ||
        typeof parsed !== 'object' ||
        parsed.version !== 1 ||
        !Array.isArray(parsed.devices) ||
        !Array.isArray(parsed.projects)
      ) {
        throw new Error('Invalid state schema');
      }

      this.state = {
        version: 1,
        devices: parsed.devices,
        projects: parsed.projects,
        github: parsed.github && typeof parsed.github === 'object' ? parsed.github : null
      };
    } catch (err) {
      throw new Error('Invalid state.json: restore the private data backup. Existing devices, projects and encrypted credentials have not been overwritten.');
    }
  }

  /**
   * Atomic sync write of state to state.json via temp file + fsync + rename.
   */
  _writeStateSync() {
    this._ensureDataDir();
    const tmpPath = path.join(
      this.dataDir,
      `state.json.tmp.${process.pid}.${crypto.randomBytes(4).toString('hex')}`
    );

    const data = JSON.stringify(this.state, null, 2);
    const fd = fs.openSync(tmpPath, 'w', 0o600);
    try {
      fs.writeFileSync(fd, data, 'utf8');
      fs.fsyncSync(fd);
    } finally {
      fs.closeSync(fd);
    }

    this._safeChmod(tmpPath, 0o600);
    fs.renameSync(tmpPath, this.statePath);
    this._safeChmod(this.statePath, 0o600);

    this._isDirty = false;
  }

  /**
   * Debounced save (200ms).
   */
  save() {
    this._isDirty = true;
    if (this._saveTimer) return;

    this._saveTimer = setTimeout(() => {
      this._saveTimer = null;
      if (this._isDirty) {
        try {
          this._writeStateSync();
        } catch (err) {
          logger.error('Failed to write state file', err);
        }
      }
    }, 200);
  }

  /**
   * Immediately flush any pending writes.
   */
  flush() {
    if (this._saveTimer) {
      clearTimeout(this._saveTimer);
      this._saveTimer = null;
    }
    if (this._isDirty) {
      this._writeStateSync();
    }
  }

  get devices() {
    return this.state.devices;
  }

  get projects() {
    return this.state.projects;
  }

  get github() {
    return this.state.github;
  }

  set github(val) {
    this.state.github = val;
    this.save();
  }
}

module.exports = StateManager;
