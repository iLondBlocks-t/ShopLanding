'use strict';

const fs = require('fs');
const path = require('path');

const PINNED_OPENCODE_VERSION = '1.18.35';

function parseEnvFile(filePath) {
  const values = Object.create(null);
  if (!fs.existsSync(filePath)) return values;
  for (let line of fs.readFileSync(filePath, 'utf8').split(/\r?\n/)) {
    line = line.trim();
    if (!line || line.startsWith('#')) continue;
    const at = line.indexOf('=');
    if (at < 1) continue;
    const key = line.slice(0, at).trim();
    if (!/^[A-Z_][A-Z0-9_]*$/i.test(key)) continue;
    let value = line.slice(at + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
    values[key] = value;
  }
  return values;
}

function loadConfig(rootDir = path.resolve(__dirname, '..'), environment = process.env) {
  rootDir = path.resolve(rootDir);
  const file = parseEnvFile(path.join(rootDir, '.env'));
  const nonempty = value => typeof value === 'string' && value.trim() !== '';
  const get = (key, fallback) => nonempty(environment[key]) ? environment[key].trim() : nonempty(file[key]) ? file[key].trim() : fallback;
  const integer = (value, key, min, max) => {
    if (!/^\d+$/.test(String(value)) || !Number.isSafeInteger(Number(value)) || Number(value) < min || Number(value) > max) throw new Error(`Invalid ${key}: expected an integer between ${min} and ${max}`);
    return Number(value);
  };
  const number = (key, fallback, min, max) => integer(get(key, fallback), key, min, max);
  const directory = (key, fallback) => path.resolve(rootDir, get(key, fallback));

  // The allocation supplied by Pterodactyl wins over ANY .env port, including
  // a copied SERVER_PORT example when the panel only supplies PORT.
  const publicPort = [environment.SERVER_PORT, environment.PORT, file.SERVER_PORT, file.PORT].find(nonempty) || '3000';
  const serverPort = integer(publicPort, 'SERVER_PORT / PORT', 1, 65535);
  const privatePort = number('OPENCODE_PORT', serverPort === 4096 ? 4097 : 4096, 1, 65535);
  if (privatePort === serverPort) throw new Error('OPENCODE_PORT must differ from the public SERVER_PORT / PORT');
  const version = get('OPENCODE_VERSION', PINNED_OPENCODE_VERSION);
  if (version !== 'latest' && !/^\d+\.\d+\.\d+$/.test(version)) throw new Error('OPENCODE_VERSION must be an exact release such as 1.18.35, or latest');
  const logLevel = get('LOG_LEVEL', 'info').toLowerCase();
  if (!['debug', 'info', 'warn', 'error'].includes(logLevel)) throw new Error('Invalid LOG_LEVEL');

  let publicBaseUrl = get('PUBLIC_BASE_URL', null);
  if (publicBaseUrl) {
    let url;
    try { url = new URL(publicBaseUrl); } catch (_) { throw new Error('PUBLIC_BASE_URL must be an absolute http(s) URL'); }
    if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.search || url.hash || url.pathname !== '/') throw new Error('PUBLIC_BASE_URL must contain only an http(s) host and optional port, without credentials or a path');
    publicBaseUrl = url.origin;
  }
  const tlsCert = get('TLS_CERT_FILE', null), tlsKey = get('TLS_KEY_FILE', null);
  if (Boolean(tlsCert) !== Boolean(tlsKey)) throw new Error('Set both TLS_CERT_FILE and TLS_KEY_FILE, or neither');
  const providerKeys = {};
  for (const key of ['ANTHROPIC_API_KEY', 'OPENAI_API_KEY', 'OPENROUTER_API_KEY', 'GEMINI_API_KEY', 'GOOGLE_GENERATIVE_AI_API_KEY', 'GROQ_API_KEY', 'DEEPSEEK_API_KEY']) providerKeys[key] = get(key, null);
  const runtimeDir = directory('RUNTIME_DIR', './runtime');
  const overrideBin = get('OPENCODE_BIN', null);
  const trustProxy = get('TRUST_PROXY', '0').toLowerCase();
  return Object.freeze({
    ROOT_DIR: rootDir, SERVER_PORT: serverPort, BIND_HOST: get('BIND_HOST', '0.0.0.0'),
    OPENCODE_PORT: privatePort, OPENCODE_VERSION: version, RUNTIME_DIR: runtimeDir,
    OPENCODE_BIN: overrideBin ? path.resolve(rootDir, overrideBin) : null,
    OPENCODE_SERVER_USERNAME: get('OPENCODE_SERVER_USERNAME', 'opencode'),
    OPENCODE_INSTALL_TIMEOUT_SEC: number('OPENCODE_INSTALL_TIMEOUT_SEC', 600, 10, 1800),
    OPENCODE_INSTALL_RETRIES: number('OPENCODE_INSTALL_RETRIES', 3, 1, 5),
    OPENCODE_READY_TIMEOUT_SEC: number('OPENCODE_READY_TIMEOUT_SEC', 90, 5, 300),
    OPENCODE_DISABLE_MODELS_FETCH: get('OPENCODE_DISABLE_MODELS_FETCH', '0') === '1',
    PAIR_CODE_TTL_SEC: number('PAIR_CODE_TTL_SEC', 300, 30, 86400),
    MAX_DEVICES: number('MAX_DEVICES', 10, 1, 1000),
    MIN_FREE_DISK_MB: number('MIN_FREE_DISK_MB', 200, 0, 1000000),
    WORKSPACE_DIR: directory('WORKSPACE_DIR', './workspace'), DATA_DIR: directory('DATA_DIR', './data'),
    TLS_CERT_FILE: tlsCert ? path.resolve(rootDir, tlsCert) : null,
    TLS_KEY_FILE: tlsKey ? path.resolve(rootDir, tlsKey) : null,
    TRUST_PROXY: trustProxy === '1' || trustProxy === 'true', LOG_LEVEL: logLevel,
    PUBLIC_BASE_URL: publicBaseUrl, PROVIDER_KEYS: Object.freeze(providerKeys)
  });
}

module.exports = { loadConfig, parseEnvFile, PINNED_OPENCODE_VERSION };
