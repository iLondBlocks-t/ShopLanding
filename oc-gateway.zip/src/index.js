'use strict';

const http = require('http');
const https = require('https');
const fs = require('fs');
const { loadConfig } = require('./config');
const logger = require('./logger');
const doctor = require('./doctor');
const StateManager = require('./state');
const PairingManager = require('./pairing');
const AuthManager = require('./auth');
const OpenCodeSupervisor = require('./opencode');
const OpenCodeProxy = require('./proxy');
const GitHubClient = require('./github');
const ProjectsManager = require('./projects');
const ArtifactsManager = require('./artifacts');
const Router = require('./router');
const ConsoleInterface = require('./console');
const { Services } = require('./services');
const Attachments = require('./attachments');
const Assistant = require('./assistant');

async function main(customConfig = null, options = {}) {
  const config = customConfig || loadConfig();
  logger.setLogLevel(config.LOG_LEVEL);
  const stateManager = new StateManager(config); stateManager.init();
  const pairingManager = new PairingManager(config);
  const authManager = new AuthManager(config, stateManager);
  const supervisor = new OpenCodeSupervisor(config, stateManager);
  const proxy = new OpenCodeProxy(config, stateManager, supervisor, authManager);
  const githubClient = new GitHubClient(config, stateManager, supervisor, proxy);
  const projectsManager = new ProjectsManager(config, stateManager, githubClient);
  const artifactsManager = new ArtifactsManager(config, projectsManager);
  const services = new Services(config, options.serviceTransport);
  const attachments = new Attachments(config, projectsManager);
  const assistant = new Assistant(config, services, attachments, authManager);
  const direct = config.ASSISTANT_MODE === 'direct' || (config.ASSISTANT_MODE !== 'opencode' && services.configured);
  const router = new Router({ services, assistant, attachments, direct, config, stateManager, pairingManager, authManager, supervisor, proxy, githubClient, projectsManager, artifactsManager });
  const installer = options.installer || null;
  let closing = false, shutdownPromise = null, preparation = null;
  const requestHandler = (req, res) => {
    Promise.resolve(router.handle(req, res)).catch(error => {
      logger.error('Request failed', error);
      if (!res.headersSent) router.sendError(res, 400, 'invalid_request', 'Invalid request');
      else res.destroy();
    });
  };
  let server;
  // Requested HTTPS never silently downgrades to insecure HTTP.
  if (config.TLS_CERT_FILE || config.TLS_KEY_FILE) {
    if (!config.TLS_CERT_FILE || !config.TLS_KEY_FILE) throw new Error('Both TLS files are required');
    server = https.createServer({ cert: fs.readFileSync(config.TLS_CERT_FILE), key: fs.readFileSync(config.TLS_KEY_FILE) }, requestHandler);
  } else server = http.createServer(requestHandler);
  server.headersTimeout = 30000; server.requestTimeout = 0; server.keepAliveTimeout = 65000;

  const shutdown = () => {
    if (shutdownPromise) return shutdownPromise;
    closing = true;
    shutdownPromise = (async () => {
      logger.info('Stopping gateway, installer and OpenCode...');
      consoleInterface.stop(); proxy.stop(); attachments.stop(); services.stop(); await assistant.stop();
      if (githubClient.stop) githubClient.stop();
      const serverClosed = new Promise(resolve => {
        server.close(resolve);
        if (server.closeAllConnections) server.closeAllConnections();
      });
      if (installer) await installer.stop();
      await supervisor.stop(); await serverClosed;
      stateManager.flush();
      for (const [event, handler] of lifecycleHandlers) process.removeListener(event, handler);
      logger.info('Gateway stopped cleanly');
    })();
    return shutdownPromise;
  };
  const lifecycleHandlers = [];
  if (options.manageProcess) {
    let signalled = false;
    const onSignal = () => {
      if (signalled) return process.exit(1);
      signalled = true;
      shutdown().then(() => process.exit(0), error => { logger.error('Shutdown failed', error); process.exit(1); });
    };
    const onFatal = error => {
      logger.error('Fatal gateway error', error);
      shutdown().then(() => process.exit(1), () => process.exit(1));
    };
    lifecycleHandlers.push(['SIGINT', onSignal], ['SIGTERM', onSignal], ['uncaughtException', onFatal], ['unhandledRejection', onFatal]);
    for (const [event, handler] of lifecycleHandlers) process.on(event, handler);
  }

  const prepareOpenCode = () => {
    if (preparation) return preparation;
    if (closing) return Promise.resolve(false);
    preparation = (async () => {
      if (supervisor.running) { logger.info('OpenCode is already ready; no active work will be interrupted'); return true; }
      if (installer && !await installer.ensureInstalled()) {
        supervisor.lastError = installer.lastError;
        logger.warn('Gateway is reachable, but OpenCode installation failed. Check npm output / disk space, then type install-opencode. No automatic LINK CODE is issued before OpenCode readiness.');
        return false;
      }
      if (closing) return false;
      if (installer) supervisor.version = installer.actualVersion;
      supervisor.start();
      if (!supervisor.child) return false;
      const ready = await supervisor.waitUntilReady();
      if (!ready && !closing) logger.warn('OpenCode is not ready yet. Type logs or status for details; type install-opencode to retry a failed installation.');
      return ready;
    })().catch(error => {
      supervisor.lastError = logger.redact(error.message || 'OpenCode startup failed');
      logger.error('OpenCode preparation failed; gateway remains available', error);
      return false;
    }).finally(() => { preparation = null; });
    return preparation;
  };

  const consoleInterface = new ConsoleInterface({ services, direct, config, stateManager, pairingManager, authManager, supervisor, projectsManager,
    onInstall: prepareOpenCode, onStop: () => options.manageProcess ? shutdown().then(() => process.exit(0), () => process.exit(1)) : shutdown() });
  let bannerPrinted = false, doctorSummary;
  const showReady = () => {
    if (closing || bannerPrinted) return;
    bannerPrinted = true;
    pairingManager.generateCode();
    consoleInterface.printBanner(doctorSummary);
  };
  supervisor.on('ready', showReady);
  try {
    await new Promise((resolve, reject) => {
      const onError = error => { server.removeListener('listening', onListening); reject(error); };
      const onListening = () => { server.removeListener('error', onError); resolve(); };
      server.once('error', onError); server.once('listening', onListening);
      server.listen(config.SERVER_PORT, config.BIND_HOST);
    });
    consoleInterface.publicPort = server.address().port;
    logger.info(`Gateway listening on ${config.BIND_HOST}:${consoleInterface.publicPort}; waiting for command-based OpenCode installation / readiness`);
    if (options.manageProcess || options.console === true) consoleInterface.start();
    const doc = await doctor.runDoctor(config); doctorSummary = doc.summary;
  } catch (error) {
    await shutdown();
    throw error;
  }
  const ready = direct ? services.probe().then(value => {
    // Pairing connects a device. Service readiness is reported separately and honestly.
    if (!closing) showReady();
    return value;
  }) : prepareOpenCode();
  if (!direct) services.probe().catch(() => {});
  return { server, config, stateManager, pairingManager, authManager, supervisor, proxy, githubClient,
    projectsManager, artifactsManager, services, assistant, attachments, direct, router, consoleInterface, installer, ready, shutdown };
}

module.exports = { main };
if (require.main === module) {
  const { OpenCodeInstaller } = require('./installer');
  const config = loadConfig();
  main(config, { installer: new OpenCodeInstaller(config), manageProcess: true }).catch(error => {
    logger.error('Gateway startup failed', error); process.exitCode = 1;
  });
}
