'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const logger = require('./logger');

class ArtifactsManager {
  constructor(config, projectsManager) {
    this.config = config;
    this.projectsManager = projectsManager;

    this.hashCache = new Map(); // key: path:size:mtimeMs -> sha256
    this._activeHashes = 0;
    this._hashQueue = [];
  }

  /**
   * Semaphore-controlled hash execution (max 2 concurrent)
   */
  _scheduleHash(filePath, size, mtimeMs) {
    const cacheKey = `${filePath}:${size}:${mtimeMs}`;
    if (this.hashCache.has(cacheKey)) {
      return Promise.resolve(this.hashCache.get(cacheKey));
    }

    return new Promise((resolve, reject) => {
      this._hashQueue.push({
        filePath,
        size,
        mtimeMs,
        cacheKey,
        resolve,
        reject
      });
      this._processHashQueue();
    });
  }

  _processHashQueue() {
    if (this._activeHashes >= 2 || this._hashQueue.length === 0) {
      return;
    }

    const item = this._hashQueue.shift();
    this._activeHashes++;

    this._computeSha256(item.filePath)
      .then((hash) => {
        this.hashCache.set(item.cacheKey, hash);
        item.resolve(hash);
      })
      .catch((err) => {
        item.reject(err);
      })
      .finally(() => {
        this._activeHashes--;
        this._processHashQueue();
      });
  }

  _computeSha256(filePath) {
    return new Promise((resolve, reject) => {
      const hash = crypto.createHash('sha256');
      const stream = fs.createReadStream(filePath);
      stream.on('data', chunk => hash.update(chunk));
      stream.on('end', () => resolve(hash.digest('hex')));
      stream.on('error', err => reject(err));
    });
  }

  /**
   * Determine kind: apk-debug, apk-release, apk, zip, log, other
   */
  static classifyKind(relPath, filename) {
    const lowerRel = relPath.toLowerCase();
    const lowerFile = filename.toLowerCase();
    const combined = `${lowerRel} ${lowerFile}`;

    if (lowerFile.endsWith('.apk')) {
      if (combined.includes('debug')) return 'apk-debug';
      if (combined.includes('release')) return 'apk-release';
      return 'apk';
    }

    if (lowerFile.endsWith('.aab')) {
      return 'other';
    }

    if (lowerFile.endsWith('.zip') || lowerFile.endsWith('.tar.gz')) {
      return 'zip';
    }

    if (lowerFile.endsWith('.log')) {
      return 'log';
    }

    return 'other';
  }

  /**
   * Scan project directory for artifacts
   */
  async scanProject(projectId) {
    const project = this.projectsManager.get(projectId);
    if (!project) {
      const err = new Error('Project not found');
      err.status = 404;
      err.code = 'not_found';
      throw err;
    }

    const projectDir = path.resolve(this.config.WORKSPACE_DIR, project.dirName);
    if (!fs.existsSync(projectDir)) {
      return [];
    }

    const SKIP_DIRS = new Set(['.git', 'node_modules', '.gradle', '.cache']);
    const results = [];
    let entryCount = 0;

    // Traverse up to depth 8, max 5000 entries
    const traverse = (currentDir, currentDepth) => {
      if (currentDepth > 8 || entryCount >= 5000) return;

      let entries;
      try {
        entries = fs.readdirSync(currentDir, { withFileTypes: true });
      } catch (e) {
        return;
      }

      for (const entry of entries) {
        entryCount++;
        if (entryCount > 5000) break;

        const fullPath = path.join(currentDir, entry.name);
        const relPath = path.relative(projectDir, fullPath).replace(/\\/g, '/');

        if (entry.isDirectory()) {
          if (!SKIP_DIRS.has(entry.name)) {
            traverse(fullPath, currentDepth + 1);
          }
        } else if (entry.isFile()) {
          const lowerName = entry.name.toLowerCase();
          const topDir = relPath.split('/')[0];

          // Filter rules:
          // 1. *.apk, *.aab, *.zip, *.tar.gz
          // 2. anything under top-level artifacts/
          // 3. *.log under artifacts/ or build/
          const isArchiveOrApk =
            lowerName.endsWith('.apk') ||
            lowerName.endsWith('.aab') ||
            lowerName.endsWith('.zip') ||
            lowerName.endsWith('.tar.gz');

          const isUnderArtifacts = topDir === 'artifacts';
          const isLogUnderBuildOrArtifacts =
            lowerName.endsWith('.log') && (topDir === 'artifacts' || topDir === 'build');

          if (isArchiveOrApk || isUnderArtifacts || isLogUnderBuildOrArtifacts) {
            try {
              const stat = fs.statSync(fullPath);
              results.push({
                fullPath,
                path: relPath,
                name: entry.name,
                size: stat.size,
                mtimeMs: stat.mtimeMs,
                modifiedAt: stat.mtime.toISOString(),
                kind: ArtifactsManager.classifyKind(relPath, entry.name)
              });
            } catch (e) {}
          }
        }
      }
    };

    traverse(projectDir, 1);

    // Compute hashes (cached & throttled)
    const out = await Promise.all(
      results.map(async (r) => {
        const hash = await this._scheduleHash(r.fullPath, r.size, r.mtimeMs);
        return {
          path: r.path,
          size: r.size,
          sha256: hash,
          modifiedAt: r.modifiedAt,
          kind: r.kind
        };
      })
    );

    return out;
  }

  /**
   * Handle artifact download with Range and Content-Disposition
   */
  async handleDownload(projectId, relativePath, req, res) {
    const project = this.projectsManager.get(projectId);
    if (!project) {
      res.writeHead(404, {
        'Content-Type': 'application/json; charset=utf-8',
        'X-Content-Type-Options': 'nosniff',
        'Cache-Control': 'no-store'
      });
      res.end(JSON.stringify({ error: 'not_found', message: 'Project not found' }));
      return;
    }

    const projectDir = path.resolve(this.config.WORKSPACE_DIR, project.dirName);
    let safeFile;
    try {
      safeFile = this.projectsManager.safePath(projectDir, relativePath);
    } catch (err) {
      res.writeHead(err.status || 403, {
        'Content-Type': 'application/json; charset=utf-8',
        'X-Content-Type-Options': 'nosniff',
        'Cache-Control': 'no-store'
      });
      res.end(JSON.stringify({ error: err.code || 'forbidden_path', message: err.message }));
      return;
    }

    // Never serve .git or anything inside .git
    const relNorm = path.relative(projectDir, safeFile).replace(/\\/g, '/');
    if (relNorm === '.git' || relNorm.startsWith('.git/')) {
      res.writeHead(403, {
        'Content-Type': 'application/json; charset=utf-8',
        'X-Content-Type-Options': 'nosniff',
        'Cache-Control': 'no-store'
      });
      res.end(JSON.stringify({ error: 'forbidden_path', message: 'Access to .git is forbidden' }));
      return;
    }

    let stat;
    try {
      stat = fs.statSync(safeFile);
      if (!stat.isFile()) throw new Error('Not a file');
    } catch (e) {
      res.writeHead(404, {
        'Content-Type': 'application/json; charset=utf-8',
        'X-Content-Type-Options': 'nosniff',
        'Cache-Control': 'no-store'
      });
      res.end(JSON.stringify({ error: 'not_found', message: 'Artifact file not found' }));
      return;
    }

    const filename = path.basename(safeFile);
    const contentType = filename.toLowerCase().endsWith('.apk')
      ? 'application/vnd.android.package-archive'
      : 'application/octet-stream';

    const disposition = `attachment; filename*=UTF-8''${encodeURIComponent(filename)}`;
    const totalSize = stat.size;

    // Range header support
    const rangeHeader = req.headers.range;
    if (rangeHeader) {
      const match = /^bytes=(\d*)-(\d*)$/.exec(rangeHeader.trim());
      if (!match) {
        res.writeHead(416, {
          'Content-Range': `bytes */${totalSize}`,
          'Accept-Ranges': 'bytes'
        });
        res.end();
        return;
      }

      let start = match[1] ? Number.parseInt(match[1], 10) : undefined;
      let end = match[2] ? Number.parseInt(match[2], 10) : undefined;

      if (start === undefined && end === undefined) {
        res.writeHead(416, {
          'Content-Range': `bytes */${totalSize}`,
          'Accept-Ranges': 'bytes'
        });
        res.end();
        return;
      }

      if (start === undefined) {
        // Suffix range: bytes=-500
        start = Math.max(0, totalSize - end);
        end = totalSize - 1;
      } else if (end === undefined) {
        // Prefix range: bytes=100-
        end = totalSize - 1;
      }

      if (start > end || start >= totalSize || end >= totalSize || start < 0) {
        res.writeHead(416, {
          'Content-Range': `bytes */${totalSize}`,
          'Accept-Ranges': 'bytes'
        });
        res.end();
        return;
      }

      const chunkSize = end - start + 1;
      res.writeHead(206, {
        'Content-Range': `bytes ${start}-${end}/${totalSize}`,
        'Accept-Ranges': 'bytes',
        'Content-Length': chunkSize,
        'Content-Type': contentType,
        'Content-Disposition': disposition
      });

      const stream = fs.createReadStream(safeFile, { start, end });
      res.on('close', () => stream.destroy());
      stream.pipe(res);
    } else {
      res.writeHead(200, {
        'Content-Length': totalSize,
        'Accept-Ranges': 'bytes',
        'Content-Type': contentType,
        'Content-Disposition': disposition
      });

      const stream = fs.createReadStream(safeFile);
      res.on('close', () => stream.destroy());
      stream.pipe(res);
    }
  }
}

module.exports = ArtifactsManager;
