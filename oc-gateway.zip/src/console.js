'use strict';

const readline = require('readline');
const logger = require('./logger');

class ConsoleInterface {
  constructor(deps) {
    Object.assign(this, deps);
    this.onStop = deps.onStop || (() => process.exit(0));
    this.publicPort = deps.config.SERVER_PORT;
    this.rl = null;
  }

  printBanner(doctorSummary = 'tools not checked') {
    const status = this.supervisor.getStatus();
    const code = this.pairingManager.getActiveCode() || this.pairingManager.generateCode();
    const address = this.config.PUBLIC_BASE_URL || `Use your PUBLIC panel IP/hostname and port ${this.publicPort} (Network tab)`;
    process.stdout.write([
      '==================================================',
      ' OC GATEWAY v1.0.0 — ready for OC Pilot',
      ` Public port : ${this.publicPort}`,
      ` OpenCode    : ${status.running ? 'running (v' + status.version + ')' : 'NOT RUNNING'}`,
      ` Doctor      : ${doctorSummary}`,
      '--------------------------------------------------',
      ` LINK CODE   : ${code} (valid ${this.config.PAIR_CODE_TTL_SEC}s, single use)`,
      ` App address : ${address}`,
      ' Open OC Pilot: public address + LINK CODE.',
      ' Do NOT enter localhost or the private OpenCode port in the phone.',
      ' Type code for a fresh code; help for console commands.',
      '=================================================='
    ].join('\n') + '\n');
  }

  start() {
    if (this.rl || !process.stdin) return;
    this.rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: false });
    this.rl.on('line', line => {
      const text = line.trim();
      if (!text) return;
      try { Promise.resolve(this.handleCommand(text)).catch(error => logger.error('Console command failed', error)); }
      catch (error) { logger.error('Console command failed', error); }
    });
    // Closed stdin is normal on a managed host; it must not stop the server.
    this.rl.on('close', () => {});
  }

  handleCommand(line) {
    const [command, ...rest] = line.split(/\s+/);
    const argument = rest.join(' ').trim();
    switch (command.toLowerCase()) {
      case 'help':
        process.stdout.write([
          'Available commands:',
          '  help               - this help',
          '  code               - print a new temporary single-use LINK CODE',
          '  status             - real gateway / OpenCode status',
          '  devices            - list paired devices (never tokens)',
          '  revoke <id|all>    - revoke devices',
          '  install-opencode   - retry npm installation / CLI readiness',
          '  restart-opencode   - restart the process (interrupts active work)',
          '  logs               - last 50 redacted OpenCode log lines',
          '  stop               - stop gateway and all managed children'
        ].join('\n') + '\n');
        break;
      case 'code': {
        const code = this.pairingManager.generateCode();
        process.stdout.write(`NEW LINK CODE: ${code} (valid ${this.config.PAIR_CODE_TTL_SEC}s, single use)\n`);
        if (!this.supervisor.running) process.stdout.write('OpenCode is not ready: pairing only. Type status / logs / install-opencode to diagnose.\n');
        break;
      }
      case 'status': {
        const oc = this.supervisor.getStatus();
        process.stdout.write(`Gateway uptime: ${Math.floor(process.uptime())}s\nPublic port: ${this.publicPort}\n` +
          `OpenCode: ${oc.running ? 'running' : 'not ready'}; version=${oc.version || 'unknown'}; restarts=${oc.restarts}\n` +
          `Last error: ${logger.redact(oc.lastError || 'none')}\nDevices: ${this.stateManager.devices.length}\nProjects: ${this.stateManager.projects.length}\n`);
        break;
      }
      case 'devices':
        if (!this.stateManager.devices.length) process.stdout.write('No paired devices.\n');
        for (const device of this.stateManager.devices) {
          const name = String(device.name).replace(/[\x00-\x1f\x7f]/g, '').slice(0, 100);
          process.stdout.write(logger.redact(`ID: ${device.id} | Name: ${name} | Last seen: ${device.lastSeenAt}\n`));
        }
        break;
      case 'revoke':
        if (!argument) process.stdout.write('Usage: revoke <device-id|all>\n');
        else if (argument === 'all') { this.authManager.revokeAll(); process.stdout.write('All devices revoked.\n'); }
        else { this.authManager.revokeDevice(argument); process.stdout.write('Device revoked.\n'); }
        break;
      case 'install-opencode':
        if (!this.onInstall) { process.stdout.write('Use node start.js to enable the installer.\n'); break; }
        process.stdout.write('Checking / installing OpenCode with npm commands...\n');
        return this.onInstall().then(ready => process.stdout.write(ready ? 'OpenCode is ready. Type code for a fresh LINK CODE.\n' : 'Not ready. Read bootstrap output and type status / logs.\n'));
      case 'restart-opencode':
        process.stdout.write('Restarting OpenCode; active work will be interrupted.\n');
        return this.supervisor.restart().then(() => process.stdout.write('Restart started. Type status to check actual readiness.\n'));
      case 'logs': {
        const lines = this.supervisor.getLogs(50);
        process.stdout.write(lines.length ? lines.join('\n') + '\n' : 'No OpenCode output recorded yet.\n');
        break;
      }
      case 'stop': return this.onStop();
      default: process.stdout.write('Unknown command. Type help for a list of commands.\n');
    }
  }

  stop() { if (this.rl) { this.rl.close(); this.rl = null; } }
}

module.exports = ConsoleInterface;
