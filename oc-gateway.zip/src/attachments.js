'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { Transform } = require('stream');
const { pipeline } = require('stream/promises');
const { fail } = require('./services');

class Attachments {
  constructor(config, projects) { this.config = config; this.projects = projects; this.active = new Set(); }
  directory(projectId) {
    const project = this.projects.get(projectId);
    if (!project) throw fail('project_not_found', 404);
    const root = fs.realpathSync(this.config.WORKSPACE_DIR);
    const directory = fs.realpathSync(path.resolve(root, project.dirName));
    if (!directory.startsWith(root + path.sep)) throw fail('forbidden_path', 403);
    return directory;
  }
  root(projectId) {
    const directory = this.directory(projectId), target = path.join(directory, '.attachments');
    fs.mkdirSync(target, { recursive: true, mode: 0o700 });
    if (fs.realpathSync(target) !== target) throw fail('forbidden_path', 403);
    return target;
  }
  resolve(projectId, uri) {
    const match = /^attachment:\/\/([a-f0-9]{32})$/.exec(uri);
    if (!match) throw fail('invalid_attachment');
    const root = this.root(projectId), file = path.join(root, match[1]);
    if (!fs.existsSync(file) || fs.realpathSync(file) !== file || !fs.statSync(file).isFile()) throw fail('attachment_not_found', 404);
    const meta = JSON.parse(fs.readFileSync(file + '.json', 'utf8'));
    if (!meta || meta.url !== uri || typeof meta.mime !== 'string' || typeof meta.filename !== 'string') throw fail('invalid_attachment');
    return { ...meta, file };
  }
  async upload(req, projectId) {
    if (this.active.size >= 4) throw fail('service_busy', 429);
    const limit = (this.config.UPLOAD_MAX_MB || 20) * 1024 * 1024;
    const size = Number(req.headers['content-length']);
    if (!Number.isSafeInteger(size) || size < 1 || size > limit) throw fail('payload_too_large', 413);
    const encoded = String(req.headers['x-file-name'] || '');
    if (encoded.length > 1000 || !/^[A-Za-z0-9+/=]+$/.test(encoded)) throw fail('invalid_filename');
    let filename;
    try { filename = new TextDecoder('utf-8', { fatal: true }).decode(Buffer.from(encoded, 'base64')); } catch (_) { throw fail('invalid_filename'); }
    if (!filename || filename.length > 180 || /[\x00-\x1f\x7f/\\]/.test(filename) || filename === '.' || filename === '..') throw fail('invalid_filename');
    const mime = String(req.headers['content-type'] || '').split(';')[0].trim();
    if (!/^[a-zA-Z0-9.+-]+\/[a-zA-Z0-9.+-]+$/.test(mime)) throw fail('invalid_mime');
    const digest = String(req.headers['x-file-sha256'] || '');
    if (!/^[a-f0-9]{64}$/.test(digest)) throw fail('invalid_hash');
    if (fs.readdirSync(this.root(projectId)).filter(n => /^[a-f0-9]{32}$/.test(n)).length >= 100) throw fail('attachment_limit', 409);
    const id = crypto.randomBytes(16).toString('hex'), root = this.root(projectId), file = path.join(root, id), temp = file + '.part';
    const output = fs.createWriteStream(temp, { flags: 'wx', mode: 0o600 });
    let bytes = 0; const hash = crypto.createHash('sha256');
    const counter = new Transform({ transform(chunk, _, callback) {
      bytes += chunk.length; if (bytes > size || bytes > limit) return callback(fail('payload_too_large', 413));
      hash.update(chunk); callback(null, chunk);
    } });
    const controller = new AbortController(); this.active.add(controller);
    const timer = setTimeout(() => controller.abort(), 120000);
    const aborted = () => controller.abort(); req.once('aborted', aborted);
    try {
      await pipeline(req, counter, output, { signal: controller.signal });
      if (bytes !== size || hash.digest('hex') !== digest) throw fail('hash_mismatch');
      fs.renameSync(temp, file);
      const meta = { type: 'file', url: 'attachment://' + id, filename, mime, size, sha256: digest };
      fs.writeFileSync(file + '.json', JSON.stringify(meta), { flag: 'wx', mode: 0o600 });
      return meta;
    } catch (error) {
      for (const p of [temp, file, file + '.json']) { try { fs.unlinkSync(p); } catch (_) {} }
      throw error;
    } finally { clearTimeout(timer); req.removeListener('aborted', aborted); this.active.delete(controller); }
  }
  async content(projectId, parts) {
    const content = []; let total = 0;
    for (const part of parts) {
      if (part.type === 'text') { content.push({ type: 'text', text: String(part.text || '') }); continue; }
      if (part.type !== 'file') throw fail('invalid_attachment');
      const meta = this.resolve(projectId, part.url);
      total += meta.size;
      if (total > 24 * 1024 * 1024) throw fail('payload_too_large', 413);
      const bytes = await fs.promises.readFile(meta.file);
      if (crypto.createHash('sha256').update(bytes).digest('hex') !== meta.sha256) throw fail('hash_mismatch');
      if (/^image\/(png|jpeg|webp|gif)$/.test(meta.mime)) content.push({ type: 'image_url', image_url: { url: `data:${meta.mime};base64,${bytes.toString('base64')}` } });
      else if (meta.mime === 'application/pdf') content.push({ type: 'file', file: { filename: meta.filename, file_data: `data:application/pdf;base64,${bytes.toString('base64')}` } });
      else if (meta.mime.startsWith('text/') || /\.(json|xml|md|java|js|ts|py|c|cpp|h|css|html|gradle|yaml|yml|csv|txt)$/i.test(meta.filename)) {
        if (bytes.length > 512 * 1024) throw fail('text_file_too_large', 413);
        let text; try { text = new TextDecoder('utf-8', { fatal: true }).decode(bytes); } catch (_) { throw fail('unsupported_file_type'); }
        content.push({ type: 'text', text: `Attached file: ${meta.filename}\n${text}` });
      } else throw fail('unsupported_file_type');
    }
    return content;
  }
  stop() { for (const controller of this.active) controller.abort(); }
}
module.exports = Attachments;
