# OC Gateway + OC Pilot

Companion **hosting bot/gateway** for the native OC Pilot Android app. This is the revised source of the user-supplied `oc-gateway.zip`.

## التشغيل على Waifly / Pterodactyl

1. ارفع **oc-gateway.zip** وفك ضغطه في جذر ملفات الاستضافة.
2. اختر صورة **Node.js 20 أو 22**. اجعل Main File يساوي **start.js**.
3. شغّل:

   ```sh
   node start.js
   ```

4. ينتظر البوت نجاح تثبيت OpenCode بأوامر npm وفحص CLI، ثم يطبع **LINK CODE** بعد جاهزية OpenCode.
5. ثبّت **ocpilot-debug.apk**؛ أدخل العنوان العام والمنفذ المخصّص في Network، ثم الكود. لا تدخل localhost أو منفذ OpenCode الخاص.
6. للكود الجديد: اكتب **code** في Console البوت.

التعليمات العربية الكاملة وإعداد النماذج والموارد وHTTPS في [DEPLOY.md](DEPLOY.md).

## What changed

- OpenCode is installed with real, non-shell `npm install` commands into a local runtime, then verified with `opencode --version`. Default version is pinned to **1.18.35**, the classic API used by the app. `latest` is an explicit, unverified compatibility choice.
- The gateway opens its public allocation **before** installation; `/health` works while bootstrap is pending. Panel `SERVER_PORT` / `PORT` wins over `.env`. The private OpenCode port cannot collide with the public allocation.
- An automatic LINK CODE is generated **only after actual OpenCode readiness**. Failed installs retain diagnostic access without fabricating readiness. `install-opencode` retries the commands; `code` can explicitly issue a diagnostic code with an offline warning.
- Installation has bounded retries/timeouts/cancellation, clean npm environment, UTF-8 output handling and redacted, bounded logging. HOME/XDG/cache paths respect configured persistent storage. Verified existing installations are reused on restart.
- OpenCode runs as a supervised child process bound to loopback, with generated private Basic authentication, controlled environment and graceful process-group termination/restart.
- Existing v1 device/GitHub/project/git/artifact/passthrough routes are retained. Server-owned canonical project scope cannot be overridden by client directory/workspace headers. SSE has backpressure, idle comments and immediate rotation/revocation cleanup; cursor and Last-Event-ID headers are preserved.
- Private OpenCode authentication errors and expired GitHub tokens do not masquerade as revoked phone credentials. GitHub saves are encrypted and generation-checked, so a delayed validation cannot undo a disconnect. Invalid/missing master keys and corrupt state fail closed without replacing existing credentials.
- JSON parsing retains Arabic/emoji across byte boundaries, validates UTF-8/object shape and enforces limits. Container-memory diagnostics respect cgroup limits where available. Requested TLS fails closed rather than silently falling back to HTTP.

**Installation uses commands; the gateway-to-OpenCode API is still used internally for chat/SSE/permissions**, as selected in the request. No generic public shell/installation endpoint has been added. The phone never runs Node, OpenCode or build tools.

## Runtime requirements and security

Node.js **18+** and npm, Linux process execution, writable persistent storage and outbound npm access. Prefer Node.js **20/22**, at least **1 GB RAM** and **1–2 GB free disk** before projects; actual model/build workloads need more. The gateway itself has **zero npm runtime dependencies**. The OpenCode CLI is a separately installed host dependency, not bundled into this ZIP or the phone APK.

Installing OpenCode does **not** supply an AI subscription, guarantee free models or install Java/Gradle/Android SDK. Configure model access on the host. Android builds need their own toolchain. GitHub clones need git and a connected GitHub account.

Use trusted HTTPS or a VPN. Pairing grants control of the host's projects and OpenCode tools; only pair trusted devices. Do not publish `.env`, `data/`, `workspace/`, signing keys or backups. Upgrades must retain those private directories. OpenCode commands run with the hosting account's permissions; this gateway is not an OS sandbox for untrusted repositories.

The shared contract is retained byte-for-byte in [docs/CONTRACT.md](docs/CONTRACT.md). Source/API findings are in [docs/OPENCODE-NOTES.md](docs/OPENCODE-NOTES.md).

## Tests

```sh
npm test
# 15 test files; unit and explicitly simulated transport integration tests.
# No model account is required. These are NOT live AI/GitHub-account tests.
```

Opt-in integration with the **genuine installed CLI**, temporary private data/workspaces and actual HTTP/SSE:

```sh
node scripts/real-smoke.js --runtime ./runtime
# Optionally verify an actual APK and write sanitized captures privately:
node scripts/real-smoke.js --runtime ./runtime --apk /path/to/ocpilot-debug.apk --record-dir /private/test-responses
```

The real smoke script never sends an AI prompt or uses a GitHub account. It tests health, pairing, canonical project/session scope, real provider metadata, status/history/permissions/diff/abort, actual SSE, artifact SHA/Range/path protection, full restart, rotation and revocation. Provider captures remove optional `key` and empty `options`; they are intentionally not byte-exact secret captures.

`npm run smoke` exposes the original operator-driven `scripts/smoke.js`; it requires that script's configured running gateway/code and may include provider-dependent work. Its full prompt/build scenario was **not** executed in this delivery.

Actual results and remaining checks: [docs/VERIFICATION.md](docs/VERIFICATION.md). Android/device/UI, your actual Waifly instance, AI prompts/tool execution, provider-account/OAuth and live GitHub operations remain to be tested.
