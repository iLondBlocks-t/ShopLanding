# Assistant Server + native Android client

This is the revised user-supplied gateway. It keeps the original shared v1 pairing/device/GitHub/project/git/artifact routes and adds optional assistant/file/media extensions. The Android UI is now a plain assistant/chat without deployment/runtime brand instructions.

## Setup

Extract the hosting ZIP at the server root (`start.js` at root), choose Node.js 20/22 and run **`node start.js`**. Copy `.env.example` to private `.env`, set your own service keys and use the allocated public port. **Read [DEPLOY.md](DEPLOY.md)** for concrete Arabic instructions and security/update requirements.

- `ASSISTANT_MODE=auto`: use direct services when a supported chat key exists; otherwise retain command-installed OpenCode mode.
- `direct`: no OpenCode download needed for provider chat. Supports OpenAI, a confirmed chat-completions subset of OpenCode Zen, or OpenRouter. Real authenticated provider requests, private durable sessions and existing native SSE/history/tool/permission wire semantics.
- `opencode`: original private supervised OpenCode 1.18.35, with genuine npm installation. `OPENCODE_API_KEY` is now included in the private environment.
- Images/text-to-speech: optional OpenAI services. Music/songs: separate optional ElevenLabs Music service. Jobs produce actual private artifact files with SHA-256, authenticated download/Range and persistence. Missing keys/permissions/account/model access do not produce fake output.
- Authenticated binary uploads: default20MB, max4 concurrent, SHA verified, UTF-8 names, server-owned `attachment://` identifiers, no public links or phone-supplied filesystem scope. Direct inputs include supported images/PDF/UTF-8 text, subject to model capabilities/context limits.
- Direct project tools list/read/write actual files; writes require approval. Process execution is **opt-in `DIRECT_ALLOW_COMMANDS=1`** and always requires approval. API keys are not injected into its environment. This is not an OS sandbox: only trust authorized devices/commands. Builds require host toolchains/resources.
- Credential verification is separate from pairing, key presence and public model catalogues. Zen is marked verified only after an actual successful completion; no automatic paid validation prompt is sent. An authenticated model listing does not guarantee generation permissions/credit/quota.

All keys live on the server. Never publish `.env`, data/workspace/runtime, keys or backups. Retain these directories when upgrading. Original contract document is unchanged byte-for-byte; extensions are documented separately in [docs/ASSISTANT.md](docs/ASSISTANT.md).

## Tests

```sh
npm test
# 125 tests at this delivery: original suites + explicitly simulated provider integration.
node scripts/real-smoke.js --runtime ./runtime --apk /path/to/ocpilot-debug.apk
# Genuine installed OpenCode; 27 checks; no AI prompt or GitHub account.
```

Provider fixtures are test-only and are NOT live account/inference/image/voice/music verification. The old `npm run smoke` operator scenario was not run. See [docs/VERIFICATION.md](docs/VERIFICATION.md) for actual results, signing changes and unverified phone/hosting/provider/Gradle/CI behavior. No promise of universal capability, free access or 100% success.
