'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const http = require('http');
const { main } = require('../src/index');
const { loadConfig } = require('../src/config');
const { Services } = require('../src/services');
const Attachments = require('../src/attachments');

// Explicit provider transport fixtures: these are NOT live provider/account tests.
const json = value => ({ status: 200, type: 'application/json', bytes: Buffer.from(JSON.stringify(value)) });
const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVQIHWP4z8DwHwAFgAI/ScLbtAAAAABJRU5ErkJggg==', 'base64');
const mockProvider = async (url, method, headers, body, signal) => {
  if (url.endsWith('/models')) return json({ data: [{ id: 'gpt-4o-mini' }, { id: 'big-pickle' }, { id: 'gpt-image-1' }, { id: 'gpt-4o-mini-tts' }] });
  if (url.includes('/chat/completions')) return json({ choices: [{ message: { role: 'assistant', content: 'Fixture response العربية' } }] });
  if (url.endsWith('/images/generations')) return json({ data: [{ b64_json: png.toString('base64') }] });
  if (url.endsWith('/audio/speech') || url.includes('/v1/music?')) return { status: 200, type: 'audio/mpeg', bytes: Buffer.from('ID3fixture-audio-only') };
  if (url.endsWith('/v1/user')) return json({ subscription: { status: 'active' } });
  throw new Error('Unexpected fixture URL: ' + url);
};
function request(base, method, route, token, body, headers = {}) {
  return new Promise((resolve, reject) => {
    const bytes = Buffer.isBuffer(body) ? body : body == null ? null : Buffer.from(JSON.stringify(body));
    const req = http.request(new URL(route, base), { method, headers: { ...(token ? { Authorization: 'Bearer ' + token } : {}),
      ...(bytes ? { 'Content-Type': 'application/json', 'Content-Length': bytes.length } : {}), ...headers } }, res => {
      const chunks = []; res.on('data', c => chunks.push(c)); res.once('end', () => {
        const bytes = Buffer.concat(chunks); let value; try { value = JSON.parse(bytes); } catch (_) {}
        resolve({ status: res.statusCode, json: value, bytes, headers: res.headers });
      }); res.once('error', reject);
    }); req.once('error', reject); req.end(bytes);
  });
}
async function host(t, call = mockProvider, values = {}) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'assistant-test-'));
  const config = { ...loadConfig(root, { ASSISTANT_MODE: 'direct', OPENAI_API_KEY: 'synthetic-test-only-key', ELEVENLABS_API_KEY: 'synthetic-music-key', MIN_FREE_DISK_MB: '0', LOG_LEVEL: 'error', ...values }), SERVER_PORT: 0 };
  const app = await main(config, { serviceTransport: call, installer: { ensureInstalled: () => { throw new Error('Direct mode must never install'); }, stop: async () => {} } });
  t.after(async () => { await app.shutdown(); fs.rmSync(root, { recursive: true, force: true }); }); await app.ready;
  const base = `http://127.0.0.1:${app.server.address().port}`;
  const paired = await request(base, 'POST', '/pair/redeem', null, { code: app.pairingManager.getActiveCode(), deviceName: 'fixture' });
  const token = paired.json.deviceToken;
  const project = (await request(base, 'POST', '/gateway/projects', token, { name: 'المحادثة' })).json;
  const session = (await request(base, 'POST', '/oc/session', token, {}, { 'X-Project-Id': project.id })).json;
  return { app, config, root, base, token, project, session };
}
async function upload(h, bytes = png, filename = 'صورة.png', mime = 'image/png', hash = null) {
  return request(h.base, 'POST', `/gateway/projects/${h.project.id}/attachments`, h.token, bytes,
    { 'Content-Type': mime, 'X-File-Name': Buffer.from(filename).toString('base64'), 'X-File-SHA256': hash || crypto.createHash('sha256').update(bytes).digest('hex') });
}

test('config supports Zen/media keys, opt-in commands and original runtime mode', () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'config-services-')); try {
    const c = loadConfig(root, { OPENCODE_API_KEY: 'synthetic', ELEVENLABS_API_KEY: 'synthetic2', ASSISTANT_MODE: 'direct' });
    assert.equal(c.PROVIDER_KEYS.OPENCODE_API_KEY, 'synthetic'); assert.equal(c.ELEVENLABS_API_KEY, 'synthetic2'); assert.equal(c.DIRECT_ALLOW_COMMANDS, false);
    assert.throws(() => loadConfig(root, { ASSISTANT_MODE: 'invented' }));
  } finally { fs.rmSync(root, { recursive: true, force: true }); }
});
test('direct health distinguishes real provider verification from absent OpenCode process', async t => {
  const h = await host(t); const health = await request(h.base, 'GET', '/health');
  assert.equal(health.json.opencode.running, false); assert.equal(health.json.assistant.ready, true); assert.equal(health.json.assistant.verified, true);
  assert.equal(health.json.assistant.service, 'OpenAI'); assert.equal(h.app.supervisor.child, null);
  assert.equal((await request(h.base, 'GET', '/gateway/assistant')).status, 401);
  assert.ok(h.app.pairingManager.getActiveCode() == null); // consumed, not a sample code
});
test('invalid provider key is never reported connected and does not revoke phone auth', async t => {
  const h = await host(t, async () => ({ status: 401, bytes: Buffer.from('secret raw remote body'), type: 'application/json' }));
  const status = await request(h.base, 'GET', '/gateway/assistant', h.token);
  assert.equal(status.json.ready, false); assert.equal(status.json.verified, false); assert.equal(status.json.error, 'service_auth_failed');
  const result = await request(h.base, 'POST', `/oc/session/${h.session.id}/prompt_async`, h.token, { parts: [{ type: 'text', text: 'hello' }] }, { 'X-Project-Id': h.project.id });
  assert.equal(result.status, 503); assert.equal(result.json.error, 'service_auth_failed');
  assert.equal((await request(h.base, 'GET', '/gateway/devices', h.token)).status, 200);
  assert.ok(!JSON.stringify(status.json).includes('secret raw'));
});
test('public Zen catalogue does not falsely verify a key; actual completion does', async () => {
  const services = new Services({ CHAT_PROVIDER: 'opencode', PROVIDER_KEYS: { OPENCODE_API_KEY: 'synthetic' } }, mockProvider);
  assert.equal(await services.probe(), true); assert.equal(services.checked, false);
  await services.complete([{ role: 'user', content: 'fixture' }], [], new AbortController().signal); assert.equal(services.checked, true); services.stop();
});
test('provider model mismatch stays unready instead of fabricating a valid model', async () => {
  const services = new Services({ CHAT_MODEL: 'not-present', PROVIDER_KEYS: { OPENAI_API_KEY: 'synthetic' } }, mockProvider);
  assert.equal(await services.probe(), false); assert.equal(services.checked, false); services.stop();
});
test('provider failures are bounded typed errors, never raw provider secrets', async () => {
  for (const [status, expected] of [[403, 'service_auth_failed'], [429, 'service_limit'], [500, 'service_request_failed']]) {
    const services = new Services({ PROVIDER_KEYS: { OPENAI_API_KEY: 'synthetic' } }, async () => ({ status, bytes: Buffer.from('secret'), type: 'application/json' }));
    await services.probe(); assert.equal(services.error, expected); services.stop();
  }
});
test('binary uploads preserve Arabic name, bytes/hash and private server-owned URI', async t => {
  const h = await host(t); const result = await upload(h);
  assert.equal(result.status, 201); assert.equal(result.json.filename, 'صورة.png'); assert.match(result.json.url, /^attachment:\/\/[a-f0-9]{32}$/);
  const resolved = h.app.attachments.resolve(h.project.id, result.json.url);
  assert.deepEqual(fs.readFileSync(resolved.file), png); assert.equal(fs.statSync(resolved.file).mode & 0o777, 0o600);
  assert.ok(!JSON.stringify(result.json).includes(h.root));
});
test('wrong SHA deletes upload and all partial metadata', async t => {
  const h = await host(t); const result = await upload(h, png, 'x.png', 'image/png', '0'.repeat(64));
  assert.equal(result.status, 400); assert.equal(result.json.error, 'hash_mismatch'); assert.deepEqual(fs.readdirSync(h.app.attachments.root(h.project.id)), []);
});
test('upload filename traversal/control characters and unsupported prompt URLs are rejected', async t => {
  const h = await host(t);
  for (const name of ['../x', 'x\ny', '..']) assert.equal((await upload(h, png, name)).status, 400);
  const result = await request(h.base, 'POST', `/oc/session/${h.session.id}/message`, h.token, { parts: [{ type: 'file', url: 'file:///etc/passwd' }] }, { 'X-Project-Id': h.project.id });
  assert.equal(result.status, 400);
});
test('attachment from another project is never accepted', async t => {
  const h = await host(t); const result = await upload(h);
  const other = (await request(h.base, 'POST', '/gateway/projects', h.token, { name: 'other' })).json;
  assert.throws(() => h.app.attachments.resolve(other.id, result.json.url));
});
test('actual scoped session/history format, provider request and uploaded image/text content mapping', async t => {
  let submitted;
  const h = await host(t, async (...args) => { if (args[0].endsWith('/chat/completions')) submitted = args[3]; return mockProvider(...args); });
  const image = (await upload(h)).json; const text = (await upload(h, Buffer.from('مرحبا'), 'ملف.txt', 'text/plain')).json;
  const message = await request(h.base, 'POST', `/oc/session/${h.session.id}/message`, h.token, { messageID: 'msg_test', parts: [{ type: 'text', text: 'اقرأ' }, image, text] }, { 'X-Project-Id': h.project.id });
  assert.equal(message.status, 200); assert.equal(message.json.info.role, 'assistant'); assert.ok(message.json.info.time.completed);
  assert.equal(submitted.messages.at(-1).content[1].type, 'image_url'); assert.ok(submitted.messages.at(-1).content[2].text.includes('مرحبا'));
  const history = await request(h.base, 'GET', `/oc/session/${h.session.id}/message?limit=400`, h.token, null, { 'X-Project-Id': h.project.id });
  assert.equal(history.json.length, 2); assert.equal(history.json[0].parts[1].filename, 'صورة.png');
  assert.equal((await request(h.base, 'GET', '/oc/session/status', h.token, null, { 'X-Project-Id': h.project.id })).json[h.session.id], undefined);
});
test('duplicate message ID does not call a provider twice', async t => {
  let count = 0; const h = await host(t, async (...args) => { if (args[0].endsWith('/chat/completions')) count++; return mockProvider(...args); });
  const route = `/oc/session/${h.session.id}/message`, body = { messageID: 'msg_idempotent', parts: [{ type: 'text', text: 'fixture' }] }, headers = { 'X-Project-Id': h.project.id };
  assert.equal((await request(h.base, 'POST', route, h.token, body, headers)).status, 200);
  assert.equal((await request(h.base, 'POST', route, h.token, body, headers)).status, 204); assert.equal(count, 1);
});
test('real files are created only after a permission answer; diff reflects actual write', async t => {
  let step = 0; const h = await host(t, async (...args) => {
    if (!args[0].endsWith('/chat/completions')) return mockProvider(...args);
    if (step++ === 0) return json({ choices: [{ message: { role: 'assistant', content: null, tool_calls: [{ id: 'call_1', type: 'function', function: { name: 'write_file', arguments: JSON.stringify({ path: 'hello.txt', content: 'Hello actual file\n' }) } }] } }] });
    return mockProvider(...args);
  });
  const headers = { 'X-Project-Id': h.project.id };
  const permissionReady = new Promise(resolve => h.app.assistant.once('permission.asked', resolve));
  const completion = request(h.base, 'POST', `/oc/session/${h.session.id}/message`, h.token, { parts: [{ type: 'text', text: 'create a file' }] }, headers);
  await permissionReady;
  const pending = (await request(h.base, 'GET', '/oc/permission', h.token, null, headers)).json;
  assert.equal(pending.length, 1); assert.equal(fs.existsSync(path.join(h.app.attachments.directory(h.project.id), 'hello.txt')), false);
  assert.equal((await request(h.base, 'POST', `/oc/permission/${pending[0].id}/reply`, h.token, { reply: 'once' }, headers)).json, true);
  assert.equal((await completion).status, 200); assert.equal(fs.readFileSync(path.join(h.app.attachments.directory(h.project.id), 'hello.txt'), 'utf8'), 'Hello actual file\n');
  const diff = (await request(h.base, 'GET', `/oc/session/${h.session.id}/diff`, h.token, null, headers)).json;
  assert.equal(diff[0].file, 'hello.txt'); assert.ok(diff[0].patch.includes('+Hello actual file'));
});
test('read/write scope rejects absolute path, dot traversal, private files and symlinks', async t => {
  const h = await host(t), engine = h.app.assistant;
  for (const file of ['../../outside', '/etc/passwd', '.env', '.attachments/file', '.git/config']) assert.throws(() => engine.safePath(h.project.id, file));
  const root = h.app.attachments.directory(h.project.id); fs.symlinkSync(os.tmpdir(), path.join(root, 'escape'));
  assert.throws(() => engine.safePath(h.project.id, 'escape/data'));
  assert.ok(!engine.toolDefinitions().some(d => d.function.name === 'run_command'));
});
test('media output is an actual file with SHA and authenticated full/Range downloads', async t => {
  const h = await host(t);
  for (const kind of ['image', 'speech', 'music']) {
    const job = (await request(h.base, 'POST', '/gateway/assistant/generate', h.token, { projectId: h.project.id, kind, prompt: 'fixture only' })).json;
    await Promise.allSettled([...h.app.assistant.operations]);
    const completed = (await request(h.base, 'GET', `/gateway/assistant/jobs/${job.id}?projectId=${h.project.id}`, h.token)).json;
    assert.equal(completed.state, 'completed');
    const result = await request(h.base, 'GET', `/gateway/projects/${h.project.id}/download?path=${encodeURIComponent(completed.artifact.path)}`, h.token);
    assert.equal(result.status, 200); assert.equal(crypto.createHash('sha256').update(result.bytes).digest('hex'), completed.artifact.sha256);
    assert.equal((await request(h.base, 'GET', `/gateway/projects/${h.project.id}/download?path=${encodeURIComponent(completed.artifact.path)}`)).status, 401);
    const range = await request(h.base, 'GET', `/gateway/projects/${h.project.id}/download?path=${encodeURIComponent(completed.artifact.path)}`, h.token, null, { Range: 'bytes=0-3' });
    assert.equal(range.status, 206); assert.deepEqual(range.bytes, result.bytes.subarray(0, 4));
  }
});
test('no key/capability means unavailable, never a fabricated output', async t => {
  const h = await host(t, mockProvider, { OPENAI_API_KEY: '', ELEVENLABS_API_KEY: '' });
  assert.equal(h.app.services.ready, false);
  const response = await request(h.base, 'POST', '/gateway/assistant/generate', h.token, { projectId: h.project.id, kind: 'image', prompt: 'fixture' });
  assert.equal(response.status, 503); assert.equal(h.app.assistant.jobs.length, 0);
});
test('invalid media JSON/image bytes cannot become a successful artifact', async t => {
  const h = await host(t, async (...args) => args[0].endsWith('/images/generations') ? json({ data: [{ b64_json: Buffer.from('not an image').toString('base64') }] }) : mockProvider(...args));
  const job = await h.app.assistant.startGeneration(h.project.id, 'image', 'fixture'); await Promise.allSettled([...h.app.assistant.operations]);
  assert.equal(job.state, 'failed'); assert.equal(job.artifact, undefined);
});
test('assistant messages and output survive actual gateway restart in private data', async t => {
  const h = await host(t); await request(h.base, 'POST', `/oc/session/${h.session.id}/message`, h.token, { parts: [{ type: 'text', text: 'persist fixture' }] }, { 'X-Project-Id': h.project.id });
  await h.app.shutdown();
  const restarted = await main(h.config, { serviceTransport: mockProvider }); t.after(() => restarted.shutdown()); await restarted.ready;
  assert.equal(restarted.assistant.session(h.project.id, h.session.id).messages.length, 2); assert.ok(restarted.authManager.authenticate('Bearer ' + h.token));
  assert.ok(!fs.readFileSync(restarted.assistant.file, 'utf8').includes('synthetic-test-only-key'));
});

test('direct SSE is real, scoped, unbuffered and closes immediately on token rotation', async t => {
  const h = await host(t);
  const stream = await new Promise((resolve, reject) => {
    const req = http.get(new URL('/oc/event', h.base), { headers: { Authorization: 'Bearer ' + h.token, 'X-Project-Id': h.project.id } }, res => {
      assert.equal(res.headers['x-accel-buffering'], 'no'); let data = '';
      const closed = new Promise(done => res.once('close', done));
      res.on('data', bytes => { data += bytes.toString(); if (data.includes('server.connected')) resolve({ closed, req }); });
      res.once('error', () => {});
    }); req.once('error', reject);
  });
  const rotated = await request(h.base, 'POST', '/gateway/devices/rotate', h.token, {}); assert.equal(rotated.status, 200);
  await Promise.race([stream.closed, new Promise((_, reject) => { const timer = setTimeout(() => reject(new Error('SSE remained open')), 2000); timer.unref(); })]);
  assert.equal(h.app.assistant.streams.size, 0); stream.req.destroy();
});
test('abort cancels actual pending provider transport and reports cancelled, not completed', async t => {
  let entered; const started = new Promise(resolve => { entered = resolve; });
  const h = await host(t, async (...args) => {
    if (!args[0].endsWith('/chat/completions')) return mockProvider(...args);
    entered(); return new Promise((_, reject) => args[4].addEventListener('abort', () => reject(new Error('aborted fixture')), { once: true }));
  });
  const headers = { 'X-Project-Id': h.project.id };
  const sending = request(h.base, 'POST', `/oc/session/${h.session.id}/message`, h.token, { parts: [{ type: 'text', text: 'fixture' }] }, headers);
  await started; assert.equal((await request(h.base, 'POST', `/oc/session/${h.session.id}/abort`, h.token, {}, headers)).json, true);
  const response = await sending; assert.equal(response.json.info.error.name, 'MessageAbortedError'); assert.ok(response.json.info.time.completed);
  assert.equal(h.app.assistant.running.size, 0);
});

test('generation retry uses an idempotent client request ID instead of charging twice', async t => {
  const h = await host(t); const requestId = crypto.randomUUID();
  const a = await h.app.assistant.startGeneration(h.project.id, 'image', 'same fixture', requestId);
  const b = await h.app.assistant.startGeneration(h.project.id, 'image', 'same fixture', requestId);
  assert.equal(a.id, b.id); assert.equal(h.app.assistant.jobs.length, 1);
  await assert.rejects(h.app.assistant.startGeneration(h.project.id, 'image', 'different', requestId), { code: 'request_conflict' });
});

test('opt-in command executes actual process only after permission and receives no service key environment', async t => {
  let step = 0;
  const h = await host(t, async (...args) => {
    if (!args[0].endsWith('/chat/completions') || step++ > 0) return mockProvider(...args);
    return json({ choices: [{ message: { role: 'assistant', tool_calls: [{ id: 'actual-command', type: 'function', function: { name: 'run_command', arguments: JSON.stringify({ executable: process.execPath, args: ['-e', "if(process.env.OPENAI_API_KEY)process.exit(9);require('fs').writeFileSync('executed.txt','real process');"] }) } }] } }] });
  }, { DIRECT_ALLOW_COMMANDS: '1' });
  const permission = new Promise(resolve => h.app.assistant.once('permission.asked', resolve));
  const headers = { 'X-Project-Id': h.project.id };
  const result = request(h.base, 'POST', `/oc/session/${h.session.id}/message`, h.token, { parts: [{ type: 'text', text: 'fixture' }] }, headers);
  const asked = await permission; assert.equal(asked.permission, 'bash');
  assert.equal(fs.existsSync(path.join(h.app.attachments.directory(h.project.id), 'executed.txt')), false);
  await request(h.base, 'POST', `/oc/permission/${asked.id}/reply`, h.token, { reply: 'once' }, headers); await result;
  assert.equal(fs.readFileSync(path.join(h.app.attachments.directory(h.project.id), 'executed.txt'), 'utf8'), 'real process');
});
test('rejecting a write permission does not create any requested file', async t => {
  let step = 0;
  const h = await host(t, async (...args) => {
    if (!args[0].endsWith('/chat/completions') || step++ > 0) return mockProvider(...args);
    return json({ choices: [{ message: { role: 'assistant', tool_calls: [{ id: 'reject-write', type: 'function', function: { name: 'write_file', arguments: '{"path":"denied.txt","content":"denied"}' } }] } }] });
  });
  const permission = new Promise(resolve => h.app.assistant.once('permission.asked', resolve));
  const headers = { 'X-Project-Id': h.project.id };
  const response = request(h.base, 'POST', `/oc/session/${h.session.id}/message`, h.token, { parts: [{ type: 'text', text: 'fixture' }] }, headers);
  const asked = await permission; await request(h.base, 'POST', `/oc/permission/${asked.id}/reply`, h.token, { reply: 'reject' }, headers); await response;
  assert.equal(fs.existsSync(path.join(h.app.attachments.directory(h.project.id), 'denied.txt')), false);
});
