#!/usr/bin/env node
'use strict';

const http = require('http');
const { URL } = require('url');

/**
 * Tiny fake OpenCode HTTP server for integration tests.
 * Implements basic auth verification, health check, session list/create, abort, and SSE event stream.
 */
function createFakeOpenCode(options = {}) {
  const expectedUser = options.username || 'opencode';
  const expectedPassword = options.password || 'testpassword';
  const expectedAuth = 'Basic ' + Buffer.from(`${expectedUser}:${expectedPassword}`).toString('base64');

  const calls = [];
  let sseClients = new Set();

  const server = http.createServer((req, res) => {
    const parsed = new URL(req.url, 'http://127.0.0.1');
    const authHeader = req.headers['authorization'];

    calls.push({
      method: req.method,
      path: parsed.pathname,
      query: Object.fromEntries(parsed.searchParams.entries()),
      headers: req.headers
    });

    // Verify basic auth
    if (!authHeader || authHeader !== expectedAuth) {
      res.writeHead(401, {
        'Content-Type': 'application/json',
        'WWW-Authenticate': 'Basic realm="FakeOpenCode"'
      });
      return res.end(JSON.stringify({ error: 'unauthorized' }));
    }

    // GET /global/health
    if (parsed.pathname === '/global/health' && req.method === 'GET') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ healthy: true, version: '1.18.35' }));
    }

    // GET /session
    if (parsed.pathname === '/session' && req.method === 'GET') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify([
        { id: 'ses_1', title: 'Fake Session 1', directory: parsed.searchParams.get('directory') }
      ]));
    }

    // POST /session
    if (parsed.pathname === '/session' && req.method === 'POST') {
      let body = '';
      req.on('data', chunk => { body += chunk; });
      req.on('end', () => {
        res.writeHead(201, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          id: 'ses_new',
          title: 'Created Session',
          directory: parsed.searchParams.get('directory')
        }));
      });
      return;
    }

    // POST /session/:id/abort
    if (parsed.pathname.startsWith('/session/') && parsed.pathname.endsWith('/abort') && req.method === 'POST') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ ok: true }));
    }

    // GET /event (SSE stream)
    if (parsed.pathname === '/event' && req.method === 'GET') {
      res.writeHead(200, {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive'
      });
      if (typeof res.flushHeaders === 'function') {
        res.flushHeaders();
      }

      sseClients.add(res);

      res.write('event: message\ndata: {"type":"server.connected","properties":{}}\n\n');

      const timer = setTimeout(() => {
        try {
          res.write('event: message\ndata: {"type":"server.heartbeat","properties":{}}\n\n');
        } catch (e) {}
      }, 50);

      const cleanup = () => {
        clearTimeout(timer);
        sseClients.delete(res);
      };

      req.on('close', cleanup);
      res.on('close', cleanup);
      return;
    }

    // Fallback 404
    res.writeHead(404, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'not_found' }));
  });

  return {
    server,
    calls,
    getSseClientCount: () => sseClients.size,
    listen: (port = 0) => {
      return new Promise((resolve) => {
        server.listen(port, '127.0.0.1', () => {
          const actualPort = server.address().port;
          resolve(actualPort);
        });
      });
    },
    stop: () => {
      return new Promise((resolve) => {
        for (const client of sseClients) {
          try { client.end(); } catch (e) {}
        }
        sseClients.clear();
        server.close(resolve);
      });
    }
  };
}

module.exports = { createFakeOpenCode };

if (require.main === module && process.argv.includes('serve')) {
  const portIdx = process.argv.indexOf('--port');
  const port = portIdx !== -1 ? Number.parseInt(process.argv[portIdx + 1], 10) : 4096;
  const username = process.env.OPENCODE_SERVER_USERNAME || 'opencode';
  const password = process.env.OPENCODE_SERVER_PASSWORD || 'testpassword';

  const fake = createFakeOpenCode({ username, password });
  fake.listen(port).then((actualPort) => {
    process.stdout.write(`Fake OpenCode listening on http://127.0.0.1:${actualPort}\n`);
  });
}
