'use strict';

const { test, describe, it } = require('node:test');
const assert = require('node:assert');
const logger = require('../src/logger');

describe('Redaction', () => {
  it('redacts GitHub tokens (ghp_, github_pat_, gho_, ghs_)', () => {
    const raw = 'Tokens: ghp_1234567890abcdef, github_pat_11AAAAAAA_987654321, gho_OAuthToken12345, ghs_ServerToken12345';
    const redacted = logger.redact(raw);
    assert.strictEqual(redacted.includes('ghp_1234567890abcdef'), false);
    assert.strictEqual(redacted.includes('github_pat_11AAAAAAA_987654321'), false);
    assert.strictEqual(redacted.includes('gho_OAuthToken12345'), false);
    assert.strictEqual(redacted.includes('ghs_ServerToken12345'), false);
    assert.match(redacted, /ghp_\[REDACTED\]/);
    assert.match(redacted, /github_pat_\[REDACTED\]/);
    assert.match(redacted, /gho_\[REDACTED\]/);
    assert.match(redacted, /ghs_\[REDACTED\]/);
  });

  it('redacts model API keys (sk-..., sk-ant-...) and device tokens (dt_...)', () => {
    const raw = 'Keys: sk-ant-api03-abcdef1234567890, sk-openai-1234567890, dt_deviceToken12345';
    const redacted = logger.redact(raw);
    assert.strictEqual(redacted.includes('sk-ant-api03-abcdef1234567890'), false);
    assert.strictEqual(redacted.includes('sk-openai-1234567890'), false);
    assert.strictEqual(redacted.includes('dt_deviceToken12345'), false);
    assert.match(redacted, /sk-\[REDACTED\]/);
    assert.match(redacted, /dt_\[REDACTED\]/);
  });

  it('redacts Bearer and Basic authentication headers', () => {
    const raw = 'Headers: Bearer secretToken12345 and Basic b3BlbmNvZGU6cGFzc3dvcmQ=';
    const redacted = logger.redact(raw);
    assert.strictEqual(redacted.includes('secretToken12345'), false);
    assert.strictEqual(redacted.includes('b3BlbmNvZGU6cGFzc3dvcmQ='), false);
    assert.match(redacted, /Bearer \[REDACTED\]/);
    assert.match(redacted, /Basic \[REDACTED\]/);
  });

  it('redacts URLs with embedded credentials (https://user:pass@host)', () => {
    const raw = 'Cloning from https://myuser:secretpassword123@github.com/org/repo.git';
    const redacted = logger.redact(raw);
    assert.strictEqual(redacted.includes('secretpassword123'), false);
    assert.match(redacted, /https:\/\/\*\*\*:\*\*\*@github\.com\/org\/repo\.git/);
  });

  it('redacts registered secrets including master key and opencode password', () => {
    const masterKey = Buffer.from('abcdef0123456789abcdef0123456789');
    const opencodePass = 'oc_pw_9876543210zyxwv';
    logger.registerSecret(masterKey);
    logger.registerSecret(opencodePass);

    const rawHex = `Master key is ${masterKey.toString('hex')}`;
    const rawBase64 = `Master key base64 is ${masterKey.toString('base64')}`;
    const rawPass = `Server pass is ${opencodePass}`;

    assert.strictEqual(logger.redact(rawHex).includes(masterKey.toString('hex')), false);
    assert.strictEqual(logger.redact(rawBase64).includes(masterKey.toString('base64')), false);
    assert.strictEqual(logger.redact(rawPass).includes(opencodePass), false);
  });

  it('redacts sensitive values inside nested error objects and structures', () => {
    const secret = 'superSecretInternalKey999';
    logger.registerSecret(secret);

    const innerError = new Error(`Connection failed with token ghp_secretToken123 and key ${secret}`);
    const outerError = new Error('Database operation failed');
    outerError.cause = innerError;

    const redactedError = logger.redact(innerError);
    assert.strictEqual(redactedError.message.includes('ghp_secretToken123'), false);
    assert.strictEqual(redactedError.message.includes(secret), false);

    const complexObj = {
      status: 500,
      details: {
        error: innerError,
        auth: 'Bearer tokenX12345',
        nested: ['https://user:pass123@host.com', { key: secret }]
      }
    };

    const redactedObj = logger.redact(complexObj);
    assert.strictEqual(redactedObj.details.error.message.includes(secret), false);
    assert.strictEqual(redactedObj.details.auth, 'Bearer [REDACTED]');
    assert.strictEqual(redactedObj.details.nested[0], 'https://***:***@host.com');
    assert.strictEqual(redactedObj.details.nested[1].key, '[REDACTED]');
  });
});
