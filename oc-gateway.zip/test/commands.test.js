'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { runCommand } = require('../src/commands');

test('commands pass metacharacters as literal arguments, without a shell', async () => {
  const text = 'value; $(echo not-executed) & | literal';
  const result = await runCommand(process.execPath, ['-e', 'process.stdout.write(process.argv[1])', text]);
  assert.equal(result.ok, true); assert.equal(result.stdout, text);
});
test('incremental command output retains UTF-8 Arabic and emoji', async () => {
  const text = 'مرحبا 👋\n'; const lines = [];
  const result = await runCommand(process.execPath, ['-e', 'const b=Buffer.from(process.argv[1]); for(const v of b) process.stdout.write(Buffer.from([v]));', text], { onLine: line => lines.push(line) });
  assert.equal(result.stdout, text); assert.deepEqual(lines, [text.trim()]);
});
test('missing executable reports a typed spawn result', async () => {
  const result = await runCommand('/definitely-missing-oc-fixture', []);
  assert.equal(result.ok, false); assert.equal(result.error, 'ENOENT');
});
test('timeout terminates an actual long-running command', async () => {
  const result = await runCommand(process.execPath, ['-e', 'setInterval(()=>{},1000)'], { timeoutMs: 100 });
  assert.equal(result.ok, false); assert.equal(result.timedOut, true);
});
test('cancellation terminates a command and does not become a success', async () => {
  const controller = new AbortController();
  const promise = runCommand(process.execPath, ['-e', 'setInterval(()=>{},1000)'], { signal: controller.signal });
  setTimeout(() => controller.abort(), 100);
  const result = await promise; assert.equal(result.ok, false); assert.equal(result.cancelled, true);
});
test('pre-cancelled command is never executed', async () => {
  const controller = new AbortController(); controller.abort();
  const result = await runCommand(process.execPath, ['-e', 'throw Error("must not run")'], { signal: controller.signal });
  assert.equal(result.ok, false); assert.equal(result.error, 'cancelled');
});
test('captured output stays bounded', async () => {
  const result = await runCommand(process.execPath, ['-e', 'process.stdout.write("x".repeat(100000))'], { maxOutputChars: 32 });
  assert.equal(result.ok, true); assert.equal(result.stdout.length, 32);
});
