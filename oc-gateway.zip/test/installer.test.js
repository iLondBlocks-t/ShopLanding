'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { OpenCodeInstaller } = require('../src/installer');

async function fixture(callback) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'oc-install-'));
  const config = { ROOT_DIR: root, DATA_DIR: path.join(root, 'storage'), OPENCODE_VERSION: '1.18.35', OPENCODE_INSTALL_RETRIES: 3, OPENCODE_INSTALL_TIMEOUT_SEC: 10, PROVIDER_KEYS: { OPENAI_API_KEY: 'fixture-provider-credential' } };
  try { await callback(config); } finally { fs.rmSync(root, { recursive: true, force: true }); }
}
const success = stdout => ({ ok: true, stdout, stderr: '', code: 0 });

test('installer performs npm argument-array install then verifies the real CLI version command', () => fixture(async config => {
  const calls = []; let installer;
  installer = new OpenCodeInstaller(config, { resolveNpm: () => '/fixture/npm', runCommand: async (command, args, options) => {
    calls.push({ command, args, options });
    if (command === '/fixture/npm') { fs.mkdirSync(path.dirname(installer.binary), { recursive: true }); fs.writeFileSync(installer.binary, 'test-only executable marker'); return success(''); }
    return success('1.18.35\n');
  } });
  assert.equal(await installer.ensureInstalled(), true);
  assert.equal(calls[0].command, '/fixture/npm');
  assert.equal(calls[0].args[0], 'install'); assert.ok(calls[0].args.includes('opencode-ai@1.18.35'));
  assert.ok(calls[0].args.includes('--include=optional')); assert.deepEqual(calls[1].args, ['--version']);
  assert.equal(calls[0].options.env.OPENAI_API_KEY, undefined);
  assert.equal(calls[0].options.env.HOME, path.join(config.DATA_DIR, 'home'));
  assert.equal(installer.actualVersion, '1.18.35');
}));
test('verified existing CLI avoids npm on every hosting restart', () => fixture(async config => {
  const calls = []; const installer = new OpenCodeInstaller(config, { runCommand: async (command, args) => { calls.push(args); return success('1.18.35\n'); } });
  fs.mkdirSync(path.dirname(installer.binary), { recursive: true }); fs.writeFileSync(installer.binary, 'fixture');
  assert.equal(await installer.ensureInstalled(), true); assert.deepEqual(calls, [['--version']]);
}));
test('wrong version never counts as a successful installation', () => fixture(async config => {
  let npmCalls = 0; let installer;
  installer = new OpenCodeInstaller(config, { resolveNpm: () => 'fixture-npm', runCommand: async command => {
    if (command === 'fixture-npm') { ++npmCalls; fs.mkdirSync(path.dirname(installer.binary), { recursive: true }); fs.writeFileSync(installer.binary, 'fixture'); return success(''); }
    return success('2.0.0\n');
  } });
  installer._retryDelay = async () => {};
  assert.equal(await installer.ensureInstalled(), false); assert.equal(npmCalls, 3);
  assert.match(installer.lastError, /version verification failed/);
}));
test('missing configured executable fails clearly without replacing the admin override', () => fixture(async config => {
  config.OPENCODE_BIN = path.join(config.ROOT_DIR, 'missing-custom-bin'); let calls = 0;
  const installer = new OpenCodeInstaller(config, { runCommand: async () => { ++calls; return success(''); } });
  assert.equal(await installer.ensureInstalled(), false); assert.equal(calls, 0); assert.match(installer.lastError, /OPENCODE_BIN/);
}));
test('concurrent bootstrap / console retries share one installation', () => fixture(async config => {
  let installer, release, calls = 0;
  installer = new OpenCodeInstaller(config, { resolveNpm: () => 'fixture-npm', runCommand: async command => {
    if (command === 'fixture-npm') { ++calls; await new Promise(resolve => { release = resolve; }); fs.mkdirSync(path.dirname(installer.binary), { recursive: true }); fs.writeFileSync(installer.binary, 'fixture'); return success(''); }
    return success('1.18.35\n');
  } });
  const first = installer.ensureInstalled(), second = installer.ensureInstalled(); assert.equal(first, second);
  await new Promise(resolve => setImmediate(resolve)); release();
  assert.equal(await first, true); assert.equal(calls, 1);
}));
test('shutdown cancels an installer instead of starting another retry', () => fixture(async config => {
  const installer = new OpenCodeInstaller(config, { runCommand: async (command, args, options) => new Promise(resolve => options.signal.addEventListener('abort', () => resolve({ ok: false, cancelled: true, stdout: '', stderr: '' }), { once: true })) });
  const pending = installer.ensureInstalled(); await new Promise(resolve => setImmediate(resolve));
  await installer.stop(); assert.equal(await pending, false); assert.match(installer.lastError, /cancelled/);
}));
