'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const OpenCodeProxy = require('../src/proxy');
const { createFakeOpenCode } = require('./fake-opencode');

async function fixture(callback) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'oc-proxy-scope-'));
  const folder = path.join(root, 'project'); fs.mkdirSync(folder);
  const upstream = createFakeOpenCode(); const port = await upstream.listen(0);
  const state = { projects: [{ id: 'p_fixture', dirName: 'project' }], devices: [], save() {} };
  const supervisor = { running: true, port, getBasicAuthHeader: () => 'Basic ' + Buffer.from('opencode:testpassword').toString('base64') };
  const proxy = new OpenCodeProxy({ WORKSPACE_DIR: root }, state, supervisor, null);
  const server = http.createServer((req, res) => proxy.handle(req, res));
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  try { await callback({ root, folder, upstream, supervisor, base }); }
  finally { proxy.stop(); await new Promise(resolve => server.close(resolve)); await upstream.stop(); fs.rmSync(root, { recursive: true, force: true }); }
}
test('project headers override all client-supplied filesystem scopes while cursor / Last-Event-ID survive', () => fixture(async ({ folder, upstream, base }) => {
  const response = await fetch(base + '/oc/session?limit=400&before=opaque-cursor&directory=/bad&location[directory]=/worse', { headers: {
    'X-Project-Id': 'p_fixture', 'X-Opencode-Directory': '/bad', 'X-Opencode-Workspace': 'bad-workspace', 'Last-Event-ID': 'event-fixture-42'
  } });
  await response.arrayBuffer(); assert.equal(response.status, 200);
  const call = upstream.calls.at(-1); assert.equal(call.query.directory, folder);
  assert.equal(call.query['location[directory]'], undefined); assert.equal(call.headers['x-opencode-workspace'], undefined);
  assert.equal(decodeURIComponent(call.headers['x-opencode-directory']), folder);
  assert.equal(call.query.before, 'opaque-cursor'); assert.equal(call.query.limit, '400'); assert.equal(call.headers['last-event-id'], 'event-fixture-42');
}));
test('global provider / session calls do not accept any client filesystem scope', () => fixture(async ({ upstream, base }) => {
  const response = await fetch(base + '/oc/session?directory=/bad&location[directory]=/worse', { headers: { 'X-Opencode-Directory': '/bad', 'X-Opencode-Workspace': 'bad-workspace' } });
  await response.arrayBuffer(); const call = upstream.calls.at(-1);
  assert.equal(call.query.directory, undefined); assert.equal(call.query['location[directory]'], undefined);
  assert.equal(call.headers['x-opencode-directory'], undefined); assert.equal(call.headers['x-opencode-workspace'], undefined);
}));
test('upstream Basic-auth rejection must not become a phone-credential 401', () => fixture(async ({ supervisor, base }) => {
  supervisor.getBasicAuthHeader = () => 'Basic ' + Buffer.from('wrong:fixture').toString('base64');
  const response = await fetch(base + '/oc/session');
  assert.equal(response.status, 503); assert.equal((await response.json()).error, 'opencode_unavailable');
}));
test('project root symlink outside workspace is denied before OpenCode sees it', () => fixture(async ({ root, folder, upstream, base }) => {
  fs.rmSync(folder, { recursive: true }); fs.symlinkSync(path.dirname(root), folder, 'dir');
  const response = await fetch(base + '/oc/session', { headers: { 'X-Project-Id': 'p_fixture' } });
  assert.equal(response.status, 403); assert.equal((await response.json()).error, 'forbidden_path');
  assert.equal(upstream.calls.length, 0);
}));
