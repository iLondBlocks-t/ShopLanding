'use strict';

const { test, describe, it, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');

const StateManager = require('../src/state');
const ProjectsManager = require('../src/projects');

describe('Projects Manager', () => {
  let tmpDataDir;
  let tmpWorkspaceDir;
  let stateManager;
  let projectsManager;
  let mockGithub;

  beforeEach(() => {
    const id = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    tmpDataDir = path.join(os.tmpdir(), `tmp-proj-data-${id}`);
    tmpWorkspaceDir = path.join(os.tmpdir(), `tmp-proj-ws-${id}`);
    fs.mkdirSync(tmpDataDir, { recursive: true });
    fs.mkdirSync(tmpWorkspaceDir, { recursive: true });

    stateManager = new StateManager({ DATA_DIR: tmpDataDir });
    stateManager.init();

    mockGithub = {
      getStatus: () => ({ connected: true, login: 'testuser', scopes: ['repo'] }),
      getDecryptedToken: () => 'fake_gh_token',
      askpassPath: path.join(tmpDataDir, 'git-askpass.sh')
    };

    projectsManager = new ProjectsManager(
      {
        WORKSPACE_DIR: tmpWorkspaceDir,
        MIN_FREE_DISK_MB: 10
      },
      stateManager,
      mockGithub
    );
  });

  afterEach(() => {
    try {
      fs.rmSync(tmpDataDir, { recursive: true, force: true });
      fs.rmSync(tmpWorkspaceDir, { recursive: true, force: true });
    } catch (e) {}
  });

  it('creates an empty project with directory', async () => {
    const proj = await projectsManager.create({ name: 'My First Project' });
    assert.match(proj.id, /^p_[0-9a-f]{8}$/);
    assert.strictEqual(proj.name, 'My First Project');
    assert.strictEqual(proj.archived, false);

    const projectDir = path.join(tmpWorkspaceDir, proj.dirName || `${ProjectsManager.generateSlug(proj.name)}-${proj.id.slice(2)}`);
    assert.strictEqual(fs.existsSync(projectDir), true);
  });

  it('rejects path traversal and NUL bytes with 403 forbidden_path', async () => {
    const proj = await projectsManager.create({ name: 'Traversal Test' });
    const projectDir = path.join(tmpWorkspaceDir, stateManager.projects.find(p => p.id === proj.id).dirName);

    // Absolute path
    assert.throws(
      () => projectsManager.safePath(projectDir, '/etc/passwd'),
      (err) => err.status === 403 && err.code === 'forbidden_path'
    );

    // Parent traversal
    assert.throws(
      () => projectsManager.safePath(projectDir, '../../etc/passwd'),
      (err) => err.status === 403 && err.code === 'forbidden_path'
    );

    // Embedded traversal
    assert.throws(
      () => projectsManager.safePath(projectDir, 'sub/../../outside.txt'),
      (err) => err.status === 403 && err.code === 'forbidden_path'
    );

    // NUL byte
    assert.throws(
      () => projectsManager.safePath(projectDir, 'file\0.txt'),
      (err) => err.status === 403 && err.code === 'forbidden_path'
    );
  });

  it('rejects symlink escape pointing outside project with 403 forbidden_path', async () => {
    const proj = await projectsManager.create({ name: 'Symlink Test' });
    const projectDir = path.join(tmpWorkspaceDir, stateManager.projects.find(p => p.id === proj.id).dirName);

    const outsideTarget = path.join(tmpWorkspaceDir, 'secret-outside.txt');
    fs.writeFileSync(outsideTarget, 'secret content');

    const linkPath = path.join(projectDir, 'escape-link');
    try {
      fs.symlinkSync(outsideTarget, linkPath);
    } catch (e) {
      // If symlink not supported on platform, skip
      return;
    }

    assert.throws(
      () => projectsManager.safePath(projectDir, 'escape-link'),
      (err) => err.status === 403 && err.code === 'forbidden_path'
    );
  });

  it('requires confirm=true to delete a project', async () => {
    const proj = await projectsManager.create({ name: 'To Delete' });

    // Missing confirm
    await assert.rejects(
      async () => projectsManager.delete(proj.id, false),
      (err) => err.status === 400 && err.code === 'confirmation_required'
    );

    // confirm=true succeeds
    await projectsManager.delete(proj.id, 'true');
    assert.strictEqual(projectsManager.get(proj.id), undefined);
    assert.strictEqual(stateManager.projects.length, 0);
  });

  it('updates project archive flag and name', async () => {
    const proj = await projectsManager.create({ name: 'Archive Test' });

    const updated = await projectsManager.update(proj.id, { archived: true, name: 'Renamed' });
    assert.strictEqual(updated.archived, true);
    assert.strictEqual(updated.name, 'Renamed');

    const retrieved = projectsManager.get(proj.id);
    assert.strictEqual(retrieved.archived, true);
    assert.strictEqual(retrieved.name, 'Renamed');
  });

  it('rejects duplicate repoFullName for active projects with 409 project_exists', async () => {
    stateManager.projects.push({
      id: 'p_11112222',
      name: 'Existing Repo',
      repoFullName: 'org/my-repo',
      branch: 'main',
      dirName: 'existing-repo-11112222',
      archived: false,
      createdAt: new Date().toISOString(),
      lastActivityAt: new Date().toISOString()
    });

    await assert.rejects(
      async () => projectsManager.create({ name: 'Duplicate', repoFullName: 'org/my-repo' }),
      (err) => err.status === 409 && err.code === 'project_exists'
    );
  });

  it('handles git-unavailable path when git binary is missing', async () => {
    const originalPath = process.env.PATH;
    process.env.PATH = '/nonexistent_dir';

    try {
      // Trying to get git status when git is missing must throw 501
      const proj = await projectsManager.create({ name: 'No Git Test' });
      await assert.rejects(
        async () => projectsManager.getGitStatus(proj.id),
        (err) => err.status === 501 && err.code === 'git_unavailable'
      );
    } finally {
      process.env.PATH = originalPath;
    }
  });

  it('rejects creation on insufficient disk space with 507 insufficient_storage', async () => {
    projectsManager.minFreeDiskMB = 999999999; // Exceeds any actual disk space

    await assert.rejects(
      async () => projectsManager.create({ name: 'Big Project' }),
      (err) => err.status === 507 && err.code === 'insufficient_storage'
    );
  });
});
