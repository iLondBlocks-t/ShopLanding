'use strict';

const { test, describe, it, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const http = require('http');

const StateManager = require('../src/state');
const ProjectsManager = require('../src/projects');
const ArtifactsManager = require('../src/artifacts');

describe('Artifacts Manager', () => {
  let tmpDataDir;
  let tmpWorkspaceDir;
  let stateManager;
  let projectsManager;
  let artifactsManager;
  let project;
  let projectDir;

  beforeEach(async () => {
    const id = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    tmpDataDir = path.join(os.tmpdir(), `tmp-art-data-${id}`);
    tmpWorkspaceDir = path.join(os.tmpdir(), `tmp-art-ws-${id}`);
    fs.mkdirSync(tmpDataDir, { recursive: true });
    fs.mkdirSync(tmpWorkspaceDir, { recursive: true });

    stateManager = new StateManager({ DATA_DIR: tmpDataDir });
    stateManager.init();

    projectsManager = new ProjectsManager(
      { WORKSPACE_DIR: tmpWorkspaceDir, MIN_FREE_DISK_MB: 10 },
      stateManager,
      null
    );

    project = await projectsManager.create({ name: 'Artifact Project' });
    projectDir = path.join(tmpWorkspaceDir, stateManager.projects.find(p => p.id === project.id).dirName);

    artifactsManager = new ArtifactsManager(
      { WORKSPACE_DIR: tmpWorkspaceDir },
      projectsManager
    );
  });

  afterEach(() => {
    try {
      fs.rmSync(tmpDataDir, { recursive: true, force: true });
      fs.rmSync(tmpWorkspaceDir, { recursive: true, force: true });
    } catch (e) {}
  });

  it('classifies artifact kinds correctly and skips non-artifact files', async () => {
    // Create folders
    fs.mkdirSync(path.join(projectDir, 'build/outputs'), { recursive: true });
    fs.mkdirSync(path.join(projectDir, 'artifacts'), { recursive: true });
    fs.mkdirSync(path.join(projectDir, '.git'), { recursive: true });

    // Artifacts
    fs.writeFileSync(path.join(projectDir, 'build/outputs/app-debug.apk'), 'apk debug data');
    fs.writeFileSync(path.join(projectDir, 'build/outputs/app-release.apk'), 'apk release data');
    fs.writeFileSync(path.join(projectDir, 'test.apk'), 'regular apk');
    fs.writeFileSync(path.join(projectDir, 'dist.zip'), 'zip archive');
    fs.writeFileSync(path.join(projectDir, 'build/test.log'), 'build log data');
    fs.writeFileSync(path.join(projectDir, 'artifacts/custom-meta.json'), '{"meta":true}');

    // Non-artifacts: should be ignored
    fs.writeFileSync(path.join(projectDir, 'random-note.txt'), 'ignore me');
    fs.writeFileSync(path.join(projectDir, 'some.log'), 'root log ignored');
    fs.writeFileSync(path.join(projectDir, '.git/config'), 'git config data');

    const scanned = await artifactsManager.scanProject(project.id);
    const byPath = Object.fromEntries(scanned.map(a => [a.path.replace(/\\/g, '/'), a]));

    assert.strictEqual(byPath['build/outputs/app-debug.apk']?.kind, 'apk-debug');
    assert.strictEqual(byPath['build/outputs/app-release.apk']?.kind, 'apk-release');
    assert.strictEqual(byPath['test.apk']?.kind, 'apk');
    assert.strictEqual(byPath['dist.zip']?.kind, 'zip');
    assert.strictEqual(byPath['build/test.log']?.kind, 'log');
    assert.strictEqual(byPath['artifacts/custom-meta.json']?.kind, 'other');

    assert.strictEqual(byPath['random-note.txt'], undefined);
    assert.strictEqual(byPath['some.log'], undefined);
    assert.strictEqual(byPath['.git/config'], undefined);
  });

  it('computes correct sha256 streaming hash', async () => {
    const content = 'The quick brown fox jumps over the lazy dog';
    const expectedSha256 = crypto.createHash('sha256').update(content).digest('hex');

    fs.writeFileSync(path.join(projectDir, 'test.zip'), content);
    const scanned = await artifactsManager.scanProject(project.id);
    const item = scanned.find(s => s.path === 'test.zip');

    assert.ok(item);
    assert.strictEqual(item.sha256, expectedSha256);
  });

  it('handles HTTP Range 206 partial content and 416 out of bounds', async () => {
    const testData = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    fs.writeFileSync(path.join(projectDir, 'range-test.zip'), testData);

    const server = http.createServer((req, res) => {
      artifactsManager.handleDownload(project.id, 'range-test.zip', req, res);
    });

    await new Promise(r => server.listen(0, '127.0.0.1', r));
    const port = server.address().port;

    try {
      // 1. Full download without Range (200 OK)
      const fullRes = await new Promise((resolve) => {
        http.get(`http://127.0.0.1:${port}/`, (res) => {
          let b = '';
          res.on('data', c => { b += c; });
          res.on('end', () => resolve({ status: res.statusCode, body: b, headers: res.headers }));
        });
      });
      assert.strictEqual(fullRes.status, 200);
      assert.strictEqual(fullRes.body, testData);
      assert.strictEqual(fullRes.headers['accept-ranges'], 'bytes');

      // 2. Range 206 Partial Content (bytes 0-9)
      const partRes = await new Promise((resolve) => {
        const req = http.request({
          hostname: '127.0.0.1',
          port,
          path: '/',
          method: 'GET',
          headers: { 'Range': 'bytes=0-9' }
        }, (res) => {
          let b = '';
          res.on('data', c => { b += c; });
          res.on('end', () => resolve({ status: res.statusCode, body: b, headers: res.headers }));
        });
        req.end();
      });
      assert.strictEqual(partRes.status, 206);
      assert.strictEqual(partRes.body, '0123456789');
      assert.strictEqual(partRes.headers['content-range'], `bytes 0-9/${testData.length}`);

      // 3. Out of bounds Range 416
      const oobRes = await new Promise((resolve) => {
        const req = http.request({
          hostname: '127.0.0.1',
          port,
          path: '/',
          method: 'GET',
          headers: { 'Range': 'bytes=500-600' }
        }, (res) => {
          resolve({ status: res.statusCode, headers: res.headers });
        });
        req.end();
      });
      assert.strictEqual(oobRes.status, 416);
      assert.strictEqual(oobRes.headers['content-range'], `bytes */${testData.length}`);
    } finally {
      await new Promise(r => server.close(r));
    }
  });

  it('rejects path traversal attempts with 403 forbidden_path', async () => {
    const server = http.createServer((req, res) => {
      artifactsManager.handleDownload(project.id, '../../etc/passwd', req, res);
    });

    await new Promise(r => server.listen(0, '127.0.0.1', r));
    const port = server.address().port;

    try {
      const res = await new Promise((resolve) => {
        http.get(`http://127.0.0.1:${port}/`, (r) => {
          let b = '';
          r.on('data', c => { b += c; });
          r.on('end', () => resolve({ status: r.statusCode, body: JSON.parse(b) }));
        });
      });
      assert.strictEqual(res.status, 403);
      assert.strictEqual(res.body.error, 'forbidden_path');
    } finally {
      await new Promise(r => server.close(r));
    }
  });

  it('never serves files from inside .git', async () => {
    fs.mkdirSync(path.join(projectDir, '.git'), { recursive: true });
    fs.writeFileSync(path.join(projectDir, '.git/HEAD'), 'ref: refs/heads/main');

    const server = http.createServer((req, res) => {
      artifactsManager.handleDownload(project.id, '.git/HEAD', req, res);
    });

    await new Promise(r => server.listen(0, '127.0.0.1', r));
    const port = server.address().port;

    try {
      const res = await new Promise((resolve) => {
        http.get(`http://127.0.0.1:${port}/`, (r) => {
          let b = '';
          r.on('data', c => { b += c; });
          r.on('end', () => resolve({ status: r.statusCode, body: JSON.parse(b) }));
        });
      });
      assert.strictEqual(res.status, 403);
      assert.strictEqual(res.body.error, 'forbidden_path');
    } finally {
      await new Promise(r => server.close(r));
    }
  });
});
