'use strict';

const { test, describe, it, before, after } = require('node:test');
const assert = require('node:assert');
const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');

const { createFakeOpenCode } = require('./fake-opencode');
const StateManager = require('../src/state');
const OpenCodeProxy = require('../src/proxy');

describe('OpenCode Proxy', () => {
  let fakeOc;
  let fakeOcPort;
  let tmpDataDir;
  let tmpWorkspaceDir;
  let stateManager;
  let supervisorMock;
  let proxy;
  let proxyServer;
  let proxyPort;

  before(async () => {
    // 1. Start fake OpenCode
    fakeOc = createFakeOpenCode({ username: 'opencode', password: 'testpassword' });
    fakeOcPort = await fakeOc.listen(0);

    // 2. Setup dirs in os.tmpdir()
    const id = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    tmpDataDir = path.join(os.tmpdir(), `tmp-proxy-data-${id}`);
    tmpWorkspaceDir = path.join(os.tmpdir(), `tmp-proxy-ws-${id}`);
    fs.mkdirSync(tmpDataDir, { recursive: true });
    fs.mkdirSync(tmpWorkspaceDir, { recursive: true });

    // 3. Setup state
    stateManager = new StateManager({ DATA_DIR: tmpDataDir });
    stateManager.init();

    // Create a test project
    const projDir = path.join(tmpWorkspaceDir, 'test-proj-1234');
    fs.mkdirSync(projDir, { recursive: true });
    stateManager.projects.push({
      id: 'p_12345678',
      name: 'test-proj',
      repoFullName: null,
      branch: 'main',
      dirName: 'test-proj-1234',
      archived: false,
      createdAt: new Date().toISOString(),
      lastActivityAt: new Date().toISOString()
    });
    stateManager.flush();

    // 4. Mock supervisor
    supervisorMock = {
      port: fakeOcPort,
      running: true,
      lastError: null,
      getBasicAuthHeader: () => 'Basic ' + Buffer.from('opencode:testpassword').toString('base64')
    };

    // 5. Proxy
    proxy = new OpenCodeProxy(
      { WORKSPACE_DIR: tmpWorkspaceDir },
      stateManager,
      supervisorMock,
      null
    );

    // 6. Test HTTP server for proxy
    proxyServer = http.createServer((req, res) => {
      proxy.handle(req, res);
    });

    await new Promise(r => proxyServer.listen(0, '127.0.0.1', r));
    proxyPort = proxyServer.address().port;
  });

  after(async () => {
    if (proxy) proxy.stop();
    if (proxyServer) await new Promise(r => proxyServer.close(r));
    if (fakeOc) await fakeOc.stop();
    try {
      fs.rmSync(tmpDataDir, { recursive: true, force: true });
      fs.rmSync(tmpWorkspaceDir, { recursive: true, force: true });
    } catch (e) {}
  });

  it('replaces client Authorization header with upstream Basic auth', async () => {
    fakeOc.calls.length = 0;

    const res = await new Promise((resolve, reject) => {
      const req = http.request({
        hostname: '127.0.0.1',
        port: proxyPort,
        path: '/oc/global/health',
        method: 'GET',
        headers: {
          'Authorization': 'Bearer dt_clientToken12345'
        }
      }, resolve);
      req.on('error', reject);
      req.end();
    });

    assert.strictEqual(res.statusCode, 200);

    // Check upstream call
    assert.strictEqual(fakeOc.calls.length, 1);
    const lastCall = fakeOc.calls[0];
    assert.strictEqual(lastCall.headers['authorization'], 'Basic ' + Buffer.from('opencode:testpassword').toString('base64'));
    assert.strictEqual(lastCall.headers['authorization'].includes('dt_clientToken12345'), false);
  });

  it('injects project directory when X-Project-Id is provided', async () => {
    fakeOc.calls.length = 0;

    const res = await new Promise((resolve, reject) => {
      const req = http.request({
        hostname: '127.0.0.1',
        port: proxyPort,
        path: '/oc/session',
        method: 'GET',
        headers: {
          'Authorization': 'Bearer dt_token',
          'X-Project-Id': 'p_12345678'
        }
      }, resolve);
      req.on('error', reject);
      req.end();
    });

    assert.strictEqual(res.statusCode, 200);
    const lastCall = fakeOc.calls[0];
    const expectedDir = path.resolve(tmpWorkspaceDir, 'test-proj-1234');
    assert.strictEqual(lastCall.query.directory, expectedDir);
    assert.strictEqual(decodeURIComponent(lastCall.headers['x-opencode-directory']), expectedDir);
  });

  it('returns 404 project_not_found for unknown project id', async () => {
    const res = await new Promise((resolve, reject) => {
      const req = http.request({
        hostname: '127.0.0.1',
        port: proxyPort,
        path: '/oc/session',
        method: 'GET',
        headers: {
          'Authorization': 'Bearer dt_token',
          'X-Project-Id': 'p_unknown_9999'
        }
      }, resolve);
      req.on('error', reject);
      req.end();
    });

    assert.strictEqual(res.statusCode, 404);
    let body = '';
    for await (const chunk of res) body += chunk;
    const json = JSON.parse(body);
    assert.strictEqual(json.error, 'project_not_found');
  });

  it('streams SSE incrementally without buffering', async () => {
    const events = [];

    await new Promise((resolve, reject) => {
      const req = http.request({
        hostname: '127.0.0.1',
        port: proxyPort,
        path: '/oc/event',
        method: 'GET',
        headers: {
          'Authorization': 'Bearer dt_token'
        }
      }, (res) => {
        assert.strictEqual(res.statusCode, 200);
        assert.strictEqual(res.headers['content-type'], 'text/event-stream');

        res.on('data', (chunk) => {
          events.push(chunk.toString('utf8'));
          if (events.length >= 2) {
            req.destroy();
            resolve();
          }
        });
      });

      req.on('error', (err) => {
        if (events.length >= 2) resolve(); // Expected on destroy
        else reject(err);
      });
      req.end();
    });

    assert.ok(events.length >= 2, 'Should receive SSE chunks incrementally');
    assert.ok(events.some(e => e.includes('server.connected')));
    // Allow SSE connection from test 4 to fully close
    await new Promise(r => setTimeout(r, 80));
  });

  it('destroys upstream request when client disconnects', async () => {
    const initialClients = fakeOc.getSseClientCount();

    const req = http.request({
      hostname: '127.0.0.1',
      port: proxyPort,
      path: '/oc/event',
      method: 'GET',
      headers: {
        'Authorization': 'Bearer dt_token'
      }
    }, () => {});

    req.end();

    // Wait for SSE client to connect
    await new Promise(r => setTimeout(r, 100));
    assert.strictEqual(fakeOc.getSseClientCount(), initialClients + 1);

    // Client aborts
    req.destroy();

    // Wait for cleanup
    await new Promise(r => setTimeout(r, 100));
    assert.strictEqual(fakeOc.getSseClientCount(), initialClients);
  });

  it('returns 503 opencode_unavailable when OpenCode is down', async () => {
    supervisorMock.running = false;
    supervisorMock.lastError = 'Process crashed unexpectedly';

    const res = await new Promise((resolve, reject) => {
      const req = http.request({
        hostname: '127.0.0.1',
        port: proxyPort,
        path: '/oc/global/health',
        method: 'GET',
        headers: {
          'Authorization': 'Bearer dt_token'
        }
      }, resolve);
      req.on('error', reject);
      req.end();
    });

    assert.strictEqual(res.statusCode, 503);
    let body = '';
    for await (const chunk of res) body += chunk;
    const json = JSON.parse(body);
    assert.strictEqual(json.error, 'opencode_unavailable');
    assert.strictEqual(json.message, 'Process crashed unexpectedly');

    supervisorMock.running = true;
  });
});
