'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { loadConfig, parseEnvFile, PINNED_OPENCODE_VERSION } = require('../src/config');

function withRoot(callback) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'oc-config-'));
  try { return callback(root); } finally { fs.rmSync(root, { recursive: true, force: true }); }
}

test('panel PORT takes precedence over a copied .env SERVER_PORT', () => withRoot(root => {
  fs.writeFileSync(path.join(root, '.env'), 'SERVER_PORT=3000\nPORT=3001\n');
  assert.equal(loadConfig(root, { PORT: '25565' }).SERVER_PORT, 25565);
  assert.equal(loadConfig(root, { SERVER_PORT: '25566', PORT: '25565' }).SERVER_PORT, 25566);
  assert.equal(loadConfig(root, {}).SERVER_PORT, 3000);
}));
test('default CLI version is pinned and directories respect configured storage', () => withRoot(root => {
  const config = loadConfig(root, { DATA_DIR: './persistent/data', WORKSPACE_DIR: './persistent/workspace' });
  assert.equal(config.OPENCODE_VERSION, PINNED_OPENCODE_VERSION);
  assert.equal(config.DATA_DIR, path.join(root, 'persistent/data'));
  assert.equal(config.BIND_HOST, '0.0.0.0');
  assert.ok(Object.isFrozen(config));
}));
test('public allocation 4096 chooses a different private OpenCode port', () => withRoot(root => {
  assert.equal(loadConfig(root, { SERVER_PORT: '4096' }).OPENCODE_PORT, 4097);
  assert.throws(() => loadConfig(root, { SERVER_PORT: '4096', OPENCODE_PORT: '4096' }), /must differ/);
}));
test('integer configuration rejects partial numbers, negative values and overflow', () => withRoot(root => {
  for (const port of ['3000oops', '0', '-1', '65536', '1.5']) assert.throws(() => loadConfig(root, { PORT: port }), /integer/);
  assert.throws(() => loadConfig(root, { MAX_DEVICES: '5x' }), /integer/);
  assert.equal(loadConfig(root, { MIN_FREE_DISK_MB: '0' }).MIN_FREE_DISK_MB, 0);
}));
test('package version cannot turn into another package or shell command', () => withRoot(root => {
  for (const version of ['1.18.35; touch bad', 'other-package', '../local', '1.18.35 other']) assert.throws(() => loadConfig(root, { OPENCODE_VERSION: version }), /release/);
  assert.equal(loadConfig(root, { OPENCODE_VERSION: 'latest' }).OPENCODE_VERSION, 'latest');
}));
test('public address is a clean host URL and TLS is all-or-nothing', () => withRoot(root => {
  assert.equal(loadConfig(root, { PUBLIC_BASE_URL: 'https://example.com/' }).PUBLIC_BASE_URL, 'https://example.com');
  for (const url of ['https://user:pass@example.com', 'https://example.com/path', 'ftp://example.com', 'https://example.com/?q=1']) assert.throws(() => loadConfig(root, { PUBLIC_BASE_URL: url }), /PUBLIC_BASE_URL/);
  assert.throws(() => loadConfig(root, { TLS_CERT_FILE: 'cert.pem' }), /both/);
}));
test('env parser handles quoted equals / CRLF and cannot pollute prototypes', () => withRoot(root => {
  const file = path.join(root, '.env');
  fs.writeFileSync(file, '# comment\r\nLOG_LEVEL="info"\r\nVALUE=one=two\r\nBAD KEY=value\r\n__proto__=no\r\n');
  const values = parseEnvFile(file);
  assert.equal(values.VALUE, 'one=two'); assert.equal(values.LOG_LEVEL, 'info');
  assert.equal(Object.getPrototypeOf(values), null);
  assert.equal(values['BAD KEY'], undefined);
}));
