'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const logger = require('../src/logger');

function capture(callback) {
  let output = ''; const previous = process.stdout.write;
  process.stdout.write = function (text) { output += text; return true; };
  try { callback(); } finally { process.stdout.write = previous; }
  return output;
}
test('actual logger redacts secret metadata strings, not just the primary message', () => {
  const secret = 'fixture-private-provider-credential'; logger.registerSecret(secret); logger.setLogLevel('info');
  const output = capture(() => logger.info('Metadata test', 'secret=' + secret));
  assert.ok(output.includes('[REDACTED]')); assert.ok(!output.includes(secret));
});
test('actual logger also redacts secret text in Error metadata / stacks', () => {
  const secret = 'fixture-private-exception-credential'; logger.registerSecret(secret); logger.setLogLevel('info');
  const output = capture(() => logger.info('Exception test', new Error('error with ' + secret)));
  assert.ok(output.includes('[REDACTED]')); assert.ok(!output.includes(secret));
});
