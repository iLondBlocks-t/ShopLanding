'use strict';

const { test, describe, it, before, after } = require('node:test');
const assert = require('node:assert');
const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');

const { main } = require('../src/index');

describe('Gateway HTTP contract integration (simulated OpenCode)', () => {
  let gatewayApp;
  let gatewayPort;
  let tmpDataDir;
  let tmpWorkspaceDir;

  let deviceToken;
  let deviceId;
  let activeProject;

  // HTTP helper for test requests
  function request(method, reqPath, options = {}) {
    return new Promise((resolve, reject) => {
      const headers = { ...(options.headers || {}) };
      let bodyData = null;

      if (options.body) {
        bodyData = typeof options.body === 'string' ? options.body : JSON.stringify(options.body);
        if (!headers['Content-Type']) {
          headers['Content-Type'] = 'application/json';
        }
        headers['Content-Length'] = Buffer.byteLength(bodyData);
      }

      const req = http.request(
        {
          hostname: '127.0.0.1',
          port: gatewayPort,
          path: reqPath,
          method,
          headers
        },
        (res) => {
          let raw = '';
          res.on('data', chunk => { raw += chunk; });
          res.on('end', () => {
            let json = null;
            try {
              if (raw) json = JSON.parse(raw);
            } catch (e) {}
            resolve({
              status: res.statusCode,
              headers: res.headers,
              body: json,
              raw
            });
          });
        }
      );

      req.on('error', reject);
      if (bodyData) req.write(bodyData);
      req.end();
    });
  }

  before(async () => {
    // 1. Setup isolated temp directories in os.tmpdir()
    const uid = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    tmpDataDir = path.join(os.tmpdir(), `tmp-e2e-data-${uid}`);
    tmpWorkspaceDir = path.join(os.tmpdir(), `tmp-e2e-ws-${uid}`);
    fs.mkdirSync(tmpDataDir, { recursive: true });
    fs.mkdirSync(tmpWorkspaceDir, { recursive: true });

    // Store opencode password in data dir so supervisor and fake opencode match
    fs.writeFileSync(path.join(tmpDataDir, 'opencode-password'), 'testpassword', { mode: 0o600 });

    // 2. Boot gateway with supervisor managing fake-opencode
    const config = {
      ROOT_DIR: path.resolve(__dirname, '..'),
      SERVER_PORT: 0,
      BIND_HOST: '127.0.0.1',
      OPENCODE_PORT: 4299,
      OPENCODE_BIN: path.join(__dirname, 'fake-opencode.js'),
      OPENCODE_VERSION: 'latest',
      OPENCODE_SERVER_USERNAME: 'opencode',
      PAIR_CODE_TTL_SEC: 300,
      MAX_DEVICES: 5,
      WORKSPACE_DIR: tmpWorkspaceDir,
      DATA_DIR: tmpDataDir,
      MIN_FREE_DISK_MB: 10,
      TRUST_PROXY: 0,
      LOG_LEVEL: 'error'
    };

    gatewayApp = await main(config);
    gatewayPort = gatewayApp.server.address().port;

    assert.strictEqual(await gatewayApp.ready, true, "Simulated upstream must actually become ready");
  });

  after(async () => {
    if (gatewayApp) await gatewayApp.shutdown();
    try {
      fs.rmSync(tmpDataDir, { recursive: true, force: true });
      fs.rmSync(tmpWorkspaceDir, { recursive: true, force: true });
    } catch (e) {}
  });

  // --- 1. PUBLIC ENDPOINTS ---

  it('GET /health returns 200 with gateway and opencode status', async () => {
    const res = await request('GET', '/health');
    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.body.ok, true);
    assert.strictEqual(res.body.gateway, '1.0.0');
    assert.strictEqual(typeof res.body.uptimeSec, 'number');
    assert.strictEqual(typeof res.body.opencode.running, 'boolean');
  });

  it('POST /pair/redeem exchanges valid link code for deviceToken', async () => {
    const code = gatewayApp.pairingManager.getActiveCode();
    assert.ok(code);

    const res = await request('POST', '/pair/redeem', {
      body: { code, deviceName: 'E2E Tester Phone' }
    });

    assert.strictEqual(res.status, 200);
    assert.ok(res.body.deviceId);
    assert.match(res.body.deviceToken, /^dt_[A-Za-z0-9_-]+$/);

    deviceId = res.body.deviceId;
    deviceToken = res.body.deviceToken;
  });

  it('POST /pair/redeem fails on reused or invalid code with 401', async () => {
    const res = await request('POST', '/pair/redeem', {
      body: { code: 'INVALID-CODE', deviceName: 'Phone' }
    });
    assert.strictEqual(res.status, 401);
    assert.strictEqual(res.body.error, 'invalid_code');
  });

  it('rejects protected routes without auth header with 401 unauthorized', async () => {
    const res = await request('GET', '/gateway/status');
    assert.strictEqual(res.status, 401);
    assert.strictEqual(res.body.error, 'unauthorized');
  });

  // --- 2. GATEWAY STATUS & DEVICES ---

  it('GET /gateway/status returns complete system, tools, opencode, github, and device metadata', async () => {
    const res = await request('GET', '/gateway/status', {
      headers: { 'Authorization': `Bearer ${deviceToken}` }
    });

    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.body.gateway.version, '1.0.0');
    assert.ok(res.body.gateway.startedAt);
    assert.strictEqual(typeof res.body.gateway.uptimeSec, 'number');

    assert.strictEqual(typeof res.body.opencode.running, 'boolean');
    assert.strictEqual(typeof res.body.opencode.restarts, 'number');

    assert.strictEqual(typeof res.body.github.connected, 'boolean');
    assert.ok(Array.isArray(res.body.github.scopes));

    assert.strictEqual(typeof res.body.system.freeDiskMB, 'number');
    assert.strictEqual(typeof res.body.system.memTotalMB, 'number');
    assert.strictEqual(typeof res.body.system.memFreeMB, 'number');

    assert.strictEqual(typeof res.body.tools.git, 'boolean');
    assert.strictEqual(typeof res.body.tools.node, 'string');
    assert.strictEqual(typeof res.body.tools.java, 'boolean');
    assert.strictEqual(typeof res.body.tools.gradle, 'boolean');
    assert.strictEqual(typeof res.body.tools.androidSdk, 'boolean');

    assert.strictEqual(res.body.device.id, deviceId);
    assert.strictEqual(res.body.device.name, 'E2E Tester Phone');
  });

  it('GET /gateway/devices lists registered devices with current flag', async () => {
    const res = await request('GET', '/gateway/devices', {
      headers: { 'Authorization': `Bearer ${deviceToken}` }
    });

    assert.strictEqual(res.status, 200);
    assert.ok(Array.isArray(res.body));
    const me = res.body.find(d => d.id === deviceId);
    assert.ok(me);
    assert.strictEqual(me.current, true);
    assert.strictEqual(me.name, 'E2E Tester Phone');
  });

  it('POST /gateway/devices/rotate generates a fresh token and invalidates the old one', async () => {
    const res = await request('POST', '/gateway/devices/rotate', {
      headers: { 'Authorization': `Bearer ${deviceToken}` }
    });

    assert.strictEqual(res.status, 200);
    assert.match(res.body.deviceToken, /^dt_[A-Za-z0-9_-]+$/);
    assert.notStrictEqual(res.body.deviceToken, deviceToken);

    // Old token fails
    const oldRes = await request('GET', '/gateway/status', {
      headers: { 'Authorization': `Bearer ${deviceToken}` }
    });
    assert.strictEqual(oldRes.status, 401);

    // Adopt new token
    deviceToken = res.body.deviceToken;
    const newRes = await request('GET', '/gateway/status', {
      headers: { 'Authorization': `Bearer ${deviceToken}` }
    });
    assert.strictEqual(newRes.status, 200);
  });

  // --- 3. GITHUB ENDPOINTS ---

  it('GET /gateway/github reports connection status', async () => {
    const res = await request('GET', '/gateway/github', {
      headers: { 'Authorization': `Bearer ${deviceToken}` }
    });
    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.body.connected, false);
    assert.strictEqual(res.body.login, null);
    assert.deepStrictEqual(res.body.scopes, []);
  });

  it('PUT /gateway/github maps a simulated GitHub 401 to 400 invalid_github_token', async () => {
    // Deliberately simulated: no live GitHub-account verification is claimed.
    const original = gatewayApp.githubClient._request;
    gatewayApp.githubClient._request = async () => ({ statusCode: 401, headers: {}, body: { message: 'Bad credentials' } });
    try {
      const res = await request('PUT', '/gateway/github', {
        headers: { Authorization: `Bearer ${deviceToken}` },
        body: { token: 'fixture_invalid_token' }
      });
      assert.strictEqual(res.status, 400);
      assert.strictEqual(res.body.error, 'invalid_github_token');
    } finally { gatewayApp.githubClient._request = original; }
  });

  it('GET /gateway/github/repos returns 409 github_required when not connected', async () => {
    const res = await request('GET', '/gateway/github/repos?page=1', {
      headers: { 'Authorization': `Bearer ${deviceToken}` }
    });
    assert.strictEqual(res.status, 409);
    assert.strictEqual(res.body.error, 'github_required');
  });

  it('POST /gateway/github/repos returns 409 github_required when not connected', async () => {
    const res = await request('POST', '/gateway/github/repos', {
      headers: { 'Authorization': `Bearer ${deviceToken}` },
      body: { name: 'test-repo', private: true, description: 'demo' }
    });
    assert.strictEqual(res.status, 409);
    assert.strictEqual(res.body.error, 'github_required');
  });

  it('DELETE /gateway/github disconnects GitHub account', async () => {
    const res = await request('DELETE', '/gateway/github', {
      headers: { 'Authorization': `Bearer ${deviceToken}` }
    });
    assert.strictEqual(res.status, 204);

    // Wait for supervisor restart to complete and mark healthy
    const start = Date.now();
    while (!gatewayApp.supervisor.running && Date.now() - start < 10000) {
      await new Promise(r => setTimeout(r, 200));
    }
    assert.strictEqual(gatewayApp.supervisor.running, true);
  });

  // --- 4. PROJECTS ENDPOINTS ---

  it('GET /gateway/projects lists projects', async () => {
    const res = await request('GET', '/gateway/projects', {
      headers: { 'Authorization': `Bearer ${deviceToken}` }
    });
    assert.strictEqual(res.status, 200);
    assert.ok(Array.isArray(res.body));
  });

  it('POST /gateway/projects creates a new project directory and record', async () => {
    const res = await request('POST', '/gateway/projects', {
      headers: { 'Authorization': `Bearer ${deviceToken}` },
      body: { name: 'E2E Project' }
    });

    assert.strictEqual(res.status, 201);
    assert.match(res.body.id, /^p_[0-9a-f]{8}$/);
    assert.strictEqual(res.body.name, 'E2E Project');
    assert.strictEqual(res.body.archived, false);
    assert.strictEqual(res.body.repoFullName, null);

    activeProject = res.body;
  });

  it('PATCH /gateway/projects/:id updates project attributes', async () => {
    const res = await request('PATCH', `/gateway/projects/${activeProject.id}`, {
      headers: { 'Authorization': `Bearer ${deviceToken}` },
      body: { name: 'Renamed E2E Project', archived: false }
    });

    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.body.name, 'Renamed E2E Project');
  });

  it('GET /gateway/projects/:id/git retrieves git status', async () => {
    const res = await request('GET', `/gateway/projects/${activeProject.id}/git`, {
      headers: { 'Authorization': `Bearer ${deviceToken}` }
    });

    assert.strictEqual(res.status, 200);
    assert.strictEqual(typeof res.body.dirty, 'boolean');
    assert.strictEqual(typeof res.body.ahead, 'number');
    assert.ok(Array.isArray(res.body.lastCommits));
  });

  it('GET /gateway/projects/:id/artifacts scans and returns project artifacts', async () => {
    // Write an artifact to the project dir
    const projRecord = gatewayApp.stateManager.projects.find(p => p.id === activeProject.id);
    const pDir = path.join(tmpWorkspaceDir, projRecord.dirName);
    fs.mkdirSync(path.join(pDir, 'artifacts'), { recursive: true });
    fs.writeFileSync(path.join(pDir, 'artifacts/sample.apk'), 'fake apk bytes');

    const res = await request('GET', `/gateway/projects/${activeProject.id}/artifacts`, {
      headers: { 'Authorization': `Bearer ${deviceToken}` }
    });

    assert.strictEqual(res.status, 200);
    assert.ok(Array.isArray(res.body));
    const art = res.body.find(a => a.path.includes('sample.apk'));
    assert.ok(art);
    assert.strictEqual(art.kind, 'apk');
    assert.ok(art.sha256);
  });

  it('GET /gateway/projects/:id/download downloads artifact file stream', async () => {
    const res = await request('GET', `/gateway/projects/${activeProject.id}/download?path=artifacts/sample.apk`, {
      headers: { 'Authorization': `Bearer ${deviceToken}` }
    });

    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.headers['content-type'], 'application/vnd.android.package-archive');
    assert.strictEqual(res.raw, 'fake apk bytes');
  });

  // --- 5. OPENCODE PASSTHROUGH (/oc/*) ---

  it('ANY /oc/* forwards requests to OpenCode and injects project directory', async () => {
    const res = await request('GET', '/oc/session', {
      headers: {
        'Authorization': `Bearer ${deviceToken}`,
        'X-Project-Id': activeProject.id
      }
    });

    assert.strictEqual(res.status, 200);
    assert.ok(Array.isArray(res.body));
  });

  it('ANY /oc/* forwards POST requests with request bodies', async () => {
    const res = await request('POST', `/oc/session/ses_1/abort`, {
      headers: {
        'Authorization': `Bearer ${deviceToken}`,
        'X-Project-Id': activeProject.id
      },
      body: {}
    });

    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.body.ok, true);
  });

  it('GET /oc/event streams Server-Sent Events incrementally', async () => {
    const events = [];

    await new Promise((resolve, reject) => {
      const req = http.request(
        {
          hostname: '127.0.0.1',
          port: gatewayPort,
          path: '/oc/event',
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${deviceToken}`
          }
        },
        (res) => {
          assert.strictEqual(res.statusCode, 200);
          assert.strictEqual(res.headers['content-type'], 'text/event-stream');

          res.on('data', chunk => {
            events.push(chunk.toString('utf8'));
            if (events.length >= 2) {
              req.destroy();
              resolve();
            }
          });
        }
      );

      req.on('error', () => {
        if (events.length >= 2) resolve();
        else reject(new Error('SSE request aborted prematurely'));
      });
      req.end();
    });

    assert.ok(events.length >= 2);
    assert.ok(events.some(e => e.includes('server.connected')));
  });

  // --- 6. DELETE CLEANUP ---

  it('DELETE /gateway/projects/:id requires confirm=true parameter', async () => {
    const res = await request('DELETE', `/gateway/projects/${activeProject.id}`, {
      headers: { 'Authorization': `Bearer ${deviceToken}` }
    });
    assert.strictEqual(res.status, 400);
    assert.strictEqual(res.body.error, 'confirmation_required');
  });

  it('DELETE /gateway/projects/:id?confirm=true deletes the project and workspace directory', async () => {
    const res = await request('DELETE', `/gateway/projects/${activeProject.id}?confirm=true`, {
      headers: { 'Authorization': `Bearer ${deviceToken}` }
    });
    assert.strictEqual(res.status, 204);

    const listRes = await request('GET', '/gateway/projects', {
      headers: { 'Authorization': `Bearer ${deviceToken}` }
    });
    assert.strictEqual(listRes.body.length, 0);
  });

  it('DELETE /gateway/devices/:id revokes the device, causing subsequent requests to return 401', async () => {
    const res = await request('DELETE', `/gateway/devices/${deviceId}`, {
      headers: { 'Authorization': `Bearer ${deviceToken}` }
    });
    assert.strictEqual(res.status, 204);

    const checkRes = await request('GET', '/gateway/status', {
      headers: { 'Authorization': `Bearer ${deviceToken}` }
    });
    assert.strictEqual(checkRes.status, 401);
    assert.strictEqual(checkRes.body.error, 'unauthorized');
  });
});
