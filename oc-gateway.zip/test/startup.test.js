'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const net = require('net');
const { main } = require('../src/index');

async function privatePort() {
  const server = net.createServer(); await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const port = server.address().port; await new Promise(resolve => server.close(resolve)); return port;
}
async function fixture(callback) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'oc-startup-'));
  const config = { ROOT_DIR: root, SERVER_PORT: 0, BIND_HOST: '127.0.0.1', OPENCODE_PORT: await privatePort(),
    OPENCODE_BIN: path.join(__dirname, 'fake-opencode.js'), DATA_DIR: path.join(root, 'data'), WORKSPACE_DIR: path.join(root, 'workspace'),
    PAIR_CODE_TTL_SEC: 300, MAX_DEVICES: 5, MIN_FREE_DISK_MB: 0, LOG_LEVEL: 'error', OPENCODE_READY_TIMEOUT_SEC: 5 };
  let app;
  try { await callback(config, service => { app = service; }); }
  finally { if (app) await app.shutdown(); fs.rmSync(root, { recursive: true, force: true }); }
}
test('public health is reachable during installation; automatic code waits for readiness', () => fixture(async (config, save) => {
  let complete;
  const installer = { actualVersion: '1.18.35', ensureInstalled: () => new Promise(resolve => { complete = resolve; }), stop: async () => {} };
  const app = await main(config, { installer }); save(app);
  assert.equal(app.pairingManager.getActiveCode(), null);
  const health = await (await fetch(`http://127.0.0.1:${app.server.address().port}/health`)).json();
  assert.equal(health.ok, true); assert.equal(health.opencode.running, false);
  complete(true); assert.equal(await app.ready, true);
  assert.match(app.pairingManager.getActiveCode(), /^[A-Z0-9]{4}-[A-Z0-9]{4}$/);
  assert.equal(app.supervisor.running, true);
}));
test('failed command install keeps gateway alive without pretending OpenCode is ready', () => fixture(async (config, save) => {
  const installer = { lastError: 'fixture npm failure', ensureInstalled: async () => false, stop: async () => {} };
  const app = await main(config, { installer }); save(app);
  assert.equal(await app.ready, false); assert.equal(app.supervisor.running, false);
  assert.equal(app.pairingManager.getActiveCode(), null);
  const health = await (await fetch(`http://127.0.0.1:${app.server.address().port}/health`)).json();
  assert.equal(health.ok, true); assert.equal(health.opencode.running, false);
  assert.equal(app.supervisor.lastError, 'fixture npm failure');
}));
test('shutdown is idempotent and does not install process-wide exception handlers in tests', () => fixture(async (config, save) => {
  const before = process.listenerCount('uncaughtException');
  const app = await main(config); save(app); assert.equal(await app.ready, true);
  assert.equal(process.listenerCount('uncaughtException'), before);
  const first = app.shutdown(); assert.equal(first, app.shutdown()); await first;
  assert.equal(app.supervisor.child, null); assert.equal(app.supervisor.running, false);
}));
