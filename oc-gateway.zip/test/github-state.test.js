'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const StateManager = require('../src/state');
const GitHubClient = require('../src/github');

async function fixture(callback) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'oc-github-'));
  const config = { DATA_DIR: root };
  const state = new StateManager(config); state.init();
  const client = new GitHubClient(config, state, null, null);
  try { await callback(client, state); } finally { client.stop(); state.flush(); fs.rmSync(root, { recursive: true, force: true }); }
}
test('GitHub tokens are encrypted durably, not stored as raw strings', () => fixture(async (client, state) => {
  client._request = async () => ({ statusCode: 200, headers: { 'x-oauth-scopes': 'repo, workflow' }, body: { login: 'fixture-user' } });
  const token = 'fixture-private-github-credential';
  assert.equal((await client.setToken(token)).connected, true);
  assert.equal(client.getDecryptedToken(), token);
  assert.ok(!fs.readFileSync(state.statePath, 'utf8').includes(token));
}));
test('disconnect cannot be undone by a delayed validation response', () => fixture(async (client, state) => {
  let finish;
  client._request = () => new Promise(resolve => { finish = resolve; });
  const save = client.setToken('fixture-private-github-credential');
  await client.removeToken();
  finish({ statusCode: 200, headers: {}, body: { login: 'fixture-user' } });
  await assert.rejects(save, error => error.code === 'github_operation_changed');
  assert.equal(state.github, null); assert.equal(client.getStatus().connected, false);
}));
test('upstream GitHub 401 is a client error, not phone-token revocation', () => fixture(async (client, state) => {
  const encrypted = state.encrypt('fixture-private-github-credential'); state.github = { ...encrypted, login: 'fixture-user', scopes: [] };
  client._request = async () => ({ statusCode: 401, headers: {}, body: {} });
  await assert.rejects(client.listRepos(1), error => error.status === 400 && error.code === 'github_token_invalid');
}));
test('invalid header characters fail before any GitHub request', () => fixture(async client => {
  let calls = 0; client._request = async () => { ++calls; throw Error('must not run'); };
  await assert.rejects(client.setToken('bad\nheader-token'), error => error.code === 'invalid_github_token');
  assert.equal(calls, 0);
}));
