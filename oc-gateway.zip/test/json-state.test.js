'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { PassThrough } = require('stream');
const fs = require('fs');
const os = require('os');
const path = require('path');
const Router = require('../src/router');
const StateManager = require('../src/state');
const { getMemoryMB } = require('../src/doctor');

function parse(chunks) {
  const stream = new PassThrough(); const result = Router.prototype.parseJsonBody.call({}, stream);
  for (const chunk of chunks) stream.write(chunk); stream.end(); return result;
}
test('JSON body retains Arabic/emoji across every UTF-8 byte split', async () => {
  const body = Buffer.from(JSON.stringify({ name: 'مشروع تجريبي 👋', code: 'ABCD-EFGH' }));
  for (let at = 1; at < body.length; at++) assert.equal((await parse([body.subarray(0, at), body.subarray(at)])).name, 'مشروع تجريبي 👋');
});
test('JSON rejects arrays / null / invalid UTF-8 / malformed input', async () => {
  for (const text of ['[]', 'null', '{', 'true']) await assert.rejects(parse([Buffer.from(text)]), error => error.status === 400 && error.code === 'invalid_json');
  await assert.rejects(parse([Buffer.from([0x7b,0x22,0x61,0x22,0x3a,0x22,0xff,0x22,0x7d])]), error => error.code === 'invalid_json');
});
test('JSON enforces a byte limit without keeping oversized buffers', async () => {
  await assert.rejects(parse([Buffer.alloc(1048577, 'x')]), error => error.status === 413 && error.code === 'payload_too_large');
});
test('corrupted private master key fails closed and is not replaced', () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'oc-key-'));
  try {
    const file = path.join(root, 'master.key'); fs.writeFileSync(file, 'broken-private-key');
    assert.throws(() => new StateManager({ DATA_DIR: root }).init(), /Invalid master.key/);
    assert.equal(fs.readFileSync(file, 'utf8'), 'broken-private-key');
  } finally { fs.rmSync(root, { recursive: true, force: true }); }
});
test('corrupted state fails closed and existing credential database is untouched', () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'oc-state-'));
  try {
    const file = path.join(root, 'state.json'); fs.writeFileSync(file, '{broken');
    fs.writeFileSync(path.join(root, 'master.key'), Buffer.alloc(32, 3));
    assert.throws(() => new StateManager({ DATA_DIR: root }).init(), /Invalid state.json/);
    assert.equal(fs.readFileSync(file, 'utf8'), '{broken');
  } finally { fs.rmSync(root, { recursive: true, force: true }); }
});
test('memory diagnostics respect Pterodactyl cgroup limits', () => {
  const memory = getMemoryMB(file => file.endsWith('memory.max') ? String(512 * 1048576) : file.endsWith('memory.current') ? String(128 * 1048576) : 'max');
  assert.equal(memory.memTotalMB, 512); assert.ok(memory.memFreeMB <= 384);
});
test('unavailable cgroup files fall back to finite OS memory values', () => {
  const memory = getMemoryMB(() => { throw Error('unavailable'); });
  assert.ok(memory.memTotalMB > 0); assert.ok(memory.memFreeMB >= 0 && memory.memFreeMB <= memory.memTotalMB);
});

test('missing master key cannot silently replace the key for an existing device database', () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'oc-missing-key-'));
  try {
    fs.writeFileSync(path.join(root, 'state.json'), JSON.stringify({ version: 1, devices: [], projects: [], github: null }));
    assert.throws(() => new StateManager({ DATA_DIR: root }).init(), /Missing master.key/);
    assert.equal(fs.existsSync(path.join(root, 'master.key')), false);
  } finally { fs.rmSync(root, { recursive: true, force: true }); }
});
