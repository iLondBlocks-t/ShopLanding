'use strict';

const { test, describe, it } = require('node:test');
const assert = require('node:assert');
const PairingManager = require('../src/pairing');

describe('Pairing Manager', () => {
  it('generates valid Crockford base32 codes in XXXX-XXXX format', () => {
    const pm = new PairingManager({ PAIR_CODE_TTL_SEC: 300 });
    const code = pm.generateCode();
    assert.match(code, /^[0-9A-Z]{4}-[0-9A-Z]{4}$/);
    assert.strictEqual(pm.getActiveCode(), code);
  });

  it('normalizes codes (O -> 0, I -> 1, L -> 1, strips spaces and dashes)', () => {
    assert.strictEqual(PairingManager.normalize('ab cd-ef gh'), 'ABCDEFGH');
    assert.strictEqual(PairingManager.normalize('oOilL10'), '0011110');
  });

  it('expires code after TTL using injectable clock', () => {
    let mockTime = 1000000;
    const pm = new PairingManager({ PAIR_CODE_TTL_SEC: 300 });
    pm.setClock(() => mockTime);

    const code = pm.generateCode();
    assert.strictEqual(pm.getActiveCode(), code);

    // Advance clock past 300 seconds
    mockTime += 301 * 1000;
    assert.strictEqual(pm.getActiveCode(), null);

    const res = pm.redeem(code, '1.2.3.4');
    assert.strictEqual(res.success, false);
    assert.strictEqual(res.status, 401);
    assert.strictEqual(res.error, 'invalid_code');
  });

  it('enforces single use (redeem again fails)', () => {
    const pm = new PairingManager({ PAIR_CODE_TTL_SEC: 300 });
    const code = pm.generateCode();

    const res1 = pm.redeem(code, '1.2.3.4');
    assert.strictEqual(res1.success, true);
    assert.strictEqual(pm.getActiveCode(), null);

    const res2 = pm.redeem(code, '1.2.3.4');
    assert.strictEqual(res2.success, false);
    assert.strictEqual(res2.status, 401);
    assert.strictEqual(res2.error, 'invalid_code');
  });

  it('invalidates old code when generating a new one', () => {
    const pm = new PairingManager({ PAIR_CODE_TTL_SEC: 300 });
    const oldCode = pm.generateCode();
    const newCode = pm.generateCode();

    assert.notStrictEqual(oldCode, newCode);
    const oldRes = pm.redeem(oldCode, '1.2.3.4');
    assert.strictEqual(oldRes.success, false);
    assert.strictEqual(oldRes.error, 'invalid_code');

    const newRes = pm.redeem(newCode, '1.2.3.4');
    assert.strictEqual(newRes.success, true);
  });

  it('rate limits per IP after 10 attempts in 1 minute', () => {
    let mockTime = 5000000;
    const pm = new PairingManager({ PAIR_CODE_TTL_SEC: 300 });
    pm.setClock(() => mockTime);
    pm.generateCode();

    // 10 failed attempts
    for (let i = 0; i < 10; i++) {
      const res = pm.redeem('WRONG-CODE', '10.0.0.1');
      assert.strictEqual(res.success, false);
      assert.strictEqual(res.status, 401);
    }

    // 11th attempt from same IP should get 429
    const blockedRes = pm.redeem('WRONG-CODE', '10.0.0.1');
    assert.strictEqual(blockedRes.success, false);
    assert.strictEqual(blockedRes.status, 429);
    assert.strictEqual(blockedRes.error, 'rate_limited');
    assert.ok(blockedRes.retryAfter > 0);

    // Another IP is not blocked
    const otherIpRes = pm.redeem('WRONG-CODE', '10.0.0.2');
    assert.strictEqual(otherIpRes.status, 401);
  });

  it('triggers global lockout after 50 failures in 15 minutes, refusing even correct codes', () => {
    let mockTime = 6000000;
    const pm = new PairingManager({ PAIR_CODE_TTL_SEC: 300 });
    pm.setClock(() => mockTime);
    const correctCode = pm.generateCode();

    // Simulate 50 failures from diverse IPs to avoid per-IP rate limit
    for (let i = 0; i < 50; i++) {
      const ip = `192.168.1.${i}`;
      pm.redeem('FAIL-CODE', ip);
    }

    // Global lockout is now active: even a correct code must be refused with 429
    const lockedRes = pm.redeem(correctCode, '192.168.2.1');
    assert.strictEqual(lockedRes.success, false);
    assert.strictEqual(lockedRes.status, 429);
    assert.strictEqual(lockedRes.error, 'rate_limited');
    assert.ok(lockedRes.retryAfter > 0);
  });
});
