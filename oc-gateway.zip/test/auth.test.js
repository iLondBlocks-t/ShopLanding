'use strict';

const { test, describe, it, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const StateManager = require('../src/state');
const AuthManager = require('../src/auth');

describe('Auth Manager', () => {
  let tmpDataDir;
  let stateManager;
  let authManager;

  beforeEach(() => {
    tmpDataDir = path.join(os.tmpdir(), `tmp-auth-data-${Date.now()}-${Math.random().toString(36).slice(2)}`);
    fs.mkdirSync(tmpDataDir, { recursive: true });
    stateManager = new StateManager({ DATA_DIR: tmpDataDir });
    stateManager.init();
    authManager = new AuthManager({ MAX_DEVICES: 2 }, stateManager);
  });

  afterEach(() => {
    try {
      fs.rmSync(tmpDataDir, { recursive: true, force: true });
    } catch (e) {}
  });

  it('stores only sha256 tokenHash in state, never the raw token', () => {
    const cred = authManager.registerDevice('Test Phone');
    assert.match(cred.deviceToken, /^dt_[A-Za-z0-9_-]+$/);
    stateManager.flush();

    const rawState = fs.readFileSync(path.join(tmpDataDir, 'state.json'), 'utf8');
    assert.strictEqual(rawState.includes(cred.deviceToken), false, 'Raw token must never exist in state.json');

    const expectedHash = AuthManager.hashToken(cred.deviceToken);
    assert.strictEqual(rawState.includes(expectedHash), true, 'Hash must be present in state.json');
  });

  it('authenticates valid tokens and rejects invalid tokens', () => {
    const cred = authManager.registerDevice('Pixel 7');
    const valid = authManager.authenticate(`Bearer ${cred.deviceToken}`);
    assert.ok(valid);
    assert.strictEqual(valid.id, cred.deviceId);
    assert.strictEqual(valid.name, 'Pixel 7');

    const invalid = authManager.authenticate('Bearer dt_invalidtoken12345');
    assert.strictEqual(invalid, null);

    const malformed = authManager.authenticate('Basic xyz');
    assert.strictEqual(malformed, null);

    const empty = authManager.authenticate('');
    assert.strictEqual(empty, null);
  });

  it('revokes a device and emits revoke event', () => {
    const cred = authManager.registerDevice('Pixel 7');
    let revokeEmitted = false;
    authManager.on('revoke', (id) => {
      if (id === cred.deviceId) revokeEmitted = true;
    });

    authManager.revokeDevice(cred.deviceId);
    assert.strictEqual(revokeEmitted, true);

    const check = authManager.authenticate(`Bearer ${cred.deviceToken}`);
    assert.strictEqual(check, null);
  });

  it('rotates a device token, rejecting the old token and accepting the new one', () => {
    const cred = authManager.registerDevice('Pixel 7');
    let rotateEmitted = false;
    authManager.on('rotate', (id) => {
      if (id === cred.deviceId) rotateEmitted = true;
    });

    const rotated = authManager.rotateDevice(cred.deviceId);
    assert.strictEqual(rotateEmitted, true);
    assert.notStrictEqual(rotated.deviceToken, cred.deviceToken);

    // Old token must fail
    const oldCheck = authManager.authenticate(`Bearer ${cred.deviceToken}`);
    assert.strictEqual(oldCheck, null);

    // New token must succeed
    const newCheck = authManager.authenticate(`Bearer ${rotated.deviceToken}`);
    assert.ok(newCheck);
    assert.strictEqual(newCheck.id, cred.deviceId);
  });

  it('enforces MAX_DEVICES limit', () => {
    authManager.registerDevice('Device 1');
    authManager.registerDevice('Device 2');

    assert.throws(
      () => authManager.registerDevice('Device 3'),
      (err) => {
        assert.strictEqual(err.status, 409);
        assert.strictEqual(err.code, 'too_many_devices');
        return true;
      }
    );
  });
});
