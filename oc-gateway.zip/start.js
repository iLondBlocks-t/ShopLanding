#!/usr/bin/env node
'use strict';

const path = require('path');
const { loadConfig } = require('./src/config');
const { OpenCodeInstaller } = require('./src/installer');
const logger = require('./src/logger');

async function bootstrap(rootDir = __dirname) {
  if (Number(process.versions.node.split('.')[0]) < 18) throw new Error('Node.js 18+ is required; choose the Node.js 20 or 22 Pterodactyl image');
  rootDir = path.resolve(rootDir);
  process.chdir(rootDir);
  const config = loadConfig(rootDir);
  const installer = new OpenCodeInstaller(config);
  const { main } = require('./src/index');
  // Listen on the hosting allocation before npm runs: the host can probe
  // /health while the command-based installation is still in progress.
  return main(config, { installer, manageProcess: true });
}

if (require.main === module) bootstrap().catch(error => {
  logger.error('Gateway startup failed', error);
  process.exitCode = 1;
});

module.exports = { bootstrap };
