#!/usr/bin/env node
'use strict';

/**
 * OpenCode Gateway Live Smoke Test Script
 * Usage: node scripts/smoke.js http://host:port PAIRING_CODE
 */

const http = require('http');
const https = require('https');
const { URL } = require('url');

const targetUrl = process.argv[2];
const pairCode = process.argv[3];

if (!targetUrl || !pairCode) {
  process.stderr.write('Usage: node scripts/smoke.js <baseUrl> <pairingCode>\n');
  process.stderr.write('Example: node scripts/smoke.js http://127.0.0.1:3000 ABCD-EFGH\n');
  process.exit(1);
}

const parsedBase = new URL(targetUrl.replace(/\/+$/, ''));
const isHttps = parsedBase.protocol === 'https:';
const client = isHttps ? https : http;

function makeRequest(method, endpoint, options = {}) {
  return new Promise((resolve, reject) => {
    const fullPath = parsedBase.pathname === '/' ? endpoint : parsedBase.pathname + endpoint;
    const headers = { ...(options.headers || {}) };
    let bodyData = null;

    if (options.body) {
      bodyData = typeof options.body === 'string' ? options.body : JSON.stringify(options.body);
      if (!headers['Content-Type']) headers['Content-Type'] = 'application/json';
      headers['Content-Length'] = Buffer.byteLength(bodyData);
    }

    const req = client.request(
      {
        hostname: parsedBase.hostname,
        port: parsedBase.port || (isHttps ? 443 : 80),
        path: fullPath,
        method,
        headers,
        timeout: 10000
      },
      (res) => {
        let raw = '';
        res.on('data', chunk => { raw += chunk; });
        res.on('end', () => {
          let json = null;
          try {
            if (raw) json = JSON.parse(raw);
          } catch (e) {}
          resolve({
            status: res.statusCode,
            headers: res.headers,
            body: json,
            raw
          });
        });
      }
    );

    req.on('timeout', () => {
      req.destroy();
      reject(new Error(`Request to ${endpoint} timed out after 10s`));
    });
    req.on('error', reject);
    if (bodyData) req.write(bodyData);
    req.end();
  });
}

function pass(name, details = '') {
  process.stdout.write(`  [PASS] ${name}${details ? ' (' + details + ')' : ''}\n`);
}

function fail(name, reason) {
  process.stderr.write(`  [FAIL] ${name}: ${reason}\n`);
  process.exit(1);
}

async function runSmoke() {
  process.stdout.write(`\n=== Starting OpenCode Gateway Smoke Test ===\n`);
  process.stdout.write(`Target URL: ${parsedBase.href}\n`);
  process.stdout.write(`Link Code : ${pairCode}\n\n`);

  let deviceToken = null;
  let deviceId = null;
  let projectId = null;

  // 1. GET /health
  try {
    const res = await makeRequest('GET', '/health');
    if (res.status !== 200 || !res.body || !res.body.ok) {
      return fail('GET /health', `Unexpected response: ${res.status} ${res.raw}`);
    }
    pass('GET /health', `gateway: ${res.body.gateway}, opencode: ${res.body.opencode.running ? 'running' : 'stopped'}`);
  } catch (e) {
    return fail('GET /health', e.message);
  }

  // 2. POST /pair/redeem
  try {
    const res = await makeRequest('POST', '/pair/redeem', {
      body: { code: pairCode, deviceName: 'Smoke Test CLI' }
    });
    if (res.status !== 200 || !res.body || !res.body.deviceToken) {
      return fail('POST /pair/redeem', `Failed to redeem code: ${res.status} ${res.raw}`);
    }
    deviceToken = res.body.deviceToken;
    deviceId = res.body.deviceId;
    pass('POST /pair/redeem', `device: ${deviceId}`);
  } catch (e) {
    return fail('POST /pair/redeem', e.message);
  }

  const authHeaders = { 'Authorization': `Bearer ${deviceToken}` };

  // 3. GET /gateway/status
  let opencodeRunning = false;
  try {
    const res = await makeRequest('GET', '/gateway/status', { headers: authHeaders });
    if (res.status !== 200 || !res.body || !res.body.system) {
      return fail('GET /gateway/status', `Status check failed: ${res.status} ${res.raw}`);
    }
    opencodeRunning = res.body.opencode && res.body.opencode.running;
    pass('GET /gateway/status', `disk: ${res.body.system.freeDiskMB}MB free, mem: ${res.body.system.memFreeMB}MB free`);
  } catch (e) {
    return fail('GET /gateway/status', e.message);
  }

  // 4. GET /gateway/devices
  try {
    const res = await makeRequest('GET', '/gateway/devices', { headers: authHeaders });
    if (res.status !== 200 || !Array.isArray(res.body)) {
      return fail('GET /gateway/devices', `Device listing failed: ${res.status}`);
    }
    const current = res.body.find(d => d.id === deviceId);
    if (!current || !current.current) {
      return fail('GET /gateway/devices', 'Current device not flagged in list');
    }
    pass('GET /gateway/devices', `${res.body.length} devices connected`);
  } catch (e) {
    return fail('GET /gateway/devices', e.message);
  }

  // 5. GET /gateway/github
  try {
    const res = await makeRequest('GET', '/gateway/github', { headers: authHeaders });
    if (res.status !== 200 || typeof res.body.connected !== 'boolean') {
      return fail('GET /gateway/github', `GitHub check failed: ${res.status}`);
    }
    pass('GET /gateway/github', `connected: ${res.body.connected}`);
  } catch (e) {
    return fail('GET /gateway/github', e.message);
  }

  // 6. Projects CRUD
  try {
    // List projects
    const listRes = await makeRequest('GET', '/gateway/projects', { headers: authHeaders });
    if (listRes.status !== 200) return fail('GET /gateway/projects', `Status: ${listRes.status}`);
    pass('GET /gateway/projects', `${listRes.body.length} existing projects`);

    // Create project
    const createRes = await makeRequest('POST', '/gateway/projects', {
      headers: authHeaders,
      body: { name: 'smoke-test-project' }
    });
    if (createRes.status !== 201 || !createRes.body || !createRes.body.id) {
      return fail('POST /gateway/projects', `Create failed: ${createRes.status} ${createRes.raw}`);
    }
    projectId = createRes.body.id;
    pass('POST /gateway/projects', `created: ${projectId}`);

    // Update project
    const patchRes = await makeRequest('PATCH', `/gateway/projects/${projectId}`, {
      headers: authHeaders,
      body: { name: 'smoke-test-renamed' }
    });
    if (patchRes.status !== 200 || patchRes.body.name !== 'smoke-test-renamed') {
      return fail('PATCH /gateway/projects/:id', `Update failed: ${patchRes.status}`);
    }
    pass('PATCH /gateway/projects/:id', 'renamed successfully');

    // Git status
    const gitRes = await makeRequest('GET', `/gateway/projects/${projectId}/git`, { headers: authHeaders });
    if (gitRes.status !== 200 && gitRes.status !== 501) {
      return fail('GET /gateway/projects/:id/git', `Unexpected status: ${gitRes.status}`);
    }
    pass('GET /gateway/projects/:id/git', gitRes.status === 200 ? `branch: ${gitRes.body.branch || 'none'}` : 'git unavailable');

    // Artifacts scan
    const artRes = await makeRequest('GET', `/gateway/projects/${projectId}/artifacts`, { headers: authHeaders });
    if (artRes.status !== 200 || !Array.isArray(artRes.body)) {
      return fail('GET /gateway/projects/:id/artifacts', `Status: ${artRes.status}`);
    }
    pass('GET /gateway/projects/:id/artifacts', `${artRes.body.length} artifacts`);
  } catch (e) {
    return fail('Projects operations', e.message);
  }

  // 7. Passthrough check if OpenCode is running
  if (opencodeRunning) {
    try {
      const ocRes = await makeRequest('GET', '/oc/session', {
        headers: { ...authHeaders, 'X-Project-Id': projectId }
      });
      if (ocRes.status !== 200) {
        return fail('GET /oc/session', `Passthrough failed: ${ocRes.status} ${ocRes.raw}`);
      }
      pass('GET /oc/session', 'passthrough and directory injection verified');
    } catch (e) {
      return fail('OpenCode passthrough', e.message);
    }
  } else {
    process.stdout.write('  [SKIP] OpenCode passthrough (/oc/*) skipped (OpenCode is not running)\n');
  }

  // 8. Delete project cleanup
  try {
    const delRes = await makeRequest('DELETE', `/gateway/projects/${projectId}?confirm=true`, {
      headers: authHeaders
    });
    if (delRes.status !== 204) {
      return fail('DELETE /gateway/projects/:id', `Failed: ${delRes.status}`);
    }
    pass('DELETE /gateway/projects/:id', 'cleanup complete');
  } catch (e) {
    return fail('DELETE /gateway/projects/:id', e.message);
  }

  // 9. Rotate device token
  let rotatedToken = null;
  try {
    const rotRes = await makeRequest('POST', '/gateway/devices/rotate', { headers: authHeaders });
    if (rotRes.status !== 200 || !rotRes.body.deviceToken) {
      return fail('POST /gateway/devices/rotate', `Rotation failed: ${rotRes.status}`);
    }
    rotatedToken = rotRes.body.deviceToken;
    pass('POST /gateway/devices/rotate', 'token rotated successfully');
  } catch (e) {
    return fail('POST /gateway/devices/rotate', e.message);
  }

  // 10. Revoke device
  try {
    const revRes = await makeRequest('DELETE', `/gateway/devices/${deviceId}`, {
      headers: { 'Authorization': `Bearer ${rotatedToken}` }
    });
    if (revRes.status !== 204) {
      return fail('DELETE /gateway/devices/:id', `Revoke failed: ${revRes.status}`);
    }
    pass('DELETE /gateway/devices/:id', 'device revoked');

    // Confirm 401
    const postCheck = await makeRequest('GET', '/gateway/status', {
      headers: { 'Authorization': `Bearer ${rotatedToken}` }
    });
    if (postCheck.status !== 401) {
      return fail('Post-revoke check', `Expected 401, got ${postCheck.status}`);
    }
    pass('Post-revoke check', '401 confirmed');
  } catch (e) {
    return fail('Device revocation', e.message);
  }

  process.stdout.write(`\n=== All smoke tests completed successfully! ===\n\n`);
}

runSmoke().catch(err => {
  process.stderr.write(`Fatal smoke test failure: ${err.stack || err.message}\n`);
  process.exit(1);
});
