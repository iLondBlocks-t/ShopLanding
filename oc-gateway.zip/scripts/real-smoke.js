#!/usr/bin/env node
'use strict';

// Opt-in integration against the GENUINE installed opencode-ai CLI. Unlike
// test/fake-opencode.js this starts the actual executable, without AI keys,
// in temporary private data/workspace directories. It never submits a prompt.
const assert = require('assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const net = require('net');
const http = require('http');
const crypto = require('crypto');
const { main } = require('../src/index');
const { loadConfig, PINNED_OPENCODE_VERSION } = require('../src/config');
const { OpenCodeInstaller } = require('../src/installer');

const argv = process.argv.slice(2);
function argument(name, fallback = null) { const at = argv.indexOf(name); return at < 0 ? fallback : argv[at + 1]; }
const runtime = path.resolve(argument('--runtime', process.env.RUNTIME_DIR || path.join(__dirname, '../runtime')));
const recordDir = argument('--record-dir');
const apkArgument = argument('--apk');
const checked = [];
const checkpoint = label => { checked.push(label); process.stdout.write(`PASS ${label}\n`); };

async function freePort() {
  const server = net.createServer(); await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const port = server.address().port; await new Promise(resolve => server.close(resolve)); return port;
}
function request(base, method, route, token, body, extraHeaders = {}) {
  return new Promise((resolve, reject) => {
    const url = new URL(route, base), payload = body === undefined ? null : Buffer.from(JSON.stringify(body));
    const headers = { Accept: 'application/json', 'User-Agent': 'OCPilot/1.0.0', ...extraHeaders };
    if (token) headers.Authorization = `Bearer ${token}`;
    if (payload) Object.assign(headers, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': payload.length });
    const req = http.request(url, { method, headers, timeout: 30000 }, res => {
      const chunks = []; let length = 0;
      res.on('data', chunk => { length += chunk.length; if (length > 8 * 1024 * 1024) req.destroy(new Error('Response exceeds Android 8 MiB JSON/download test budget')); else chunks.push(chunk); });
      res.once('error', reject);
      res.once('end', () => {
        const bytes = Buffer.concat(chunks); let json = null;
        try { if (String(res.headers['content-type']).includes('json') && bytes.length) json = JSON.parse(bytes.toString('utf8')); }
        catch (error) { return reject(error); }
        resolve({ status: res.statusCode, headers: res.headers, bytes, json });
      });
    });
    req.once('timeout', () => req.destroy(new Error('HTTP operation timed out')));
    req.once('error', reject); if (payload) req.write(payload); req.end();
  });
}
function openSse(base, token, project) {
  return new Promise((resolve, reject) => {
    let first = false, res, raw = '', settleClosed;
    const closed = new Promise(done => { settleClosed = done; });
    const req = http.get(new URL('/oc/event', base), { headers: { Authorization: `Bearer ${token}`, 'X-Project-Id': project, Accept: 'text/event-stream' } }, response => {
      res = response;
      if (res.statusCode !== 200) { res.resume(); return reject(new Error(`SSE status ${res.statusCode}`)); }
      res.setEncoding('utf8');
      res.on('data', text => {
        if (first) return;
        raw += text;
        if (raw.length > 65536) { req.destroy(); return reject(new Error('SSE first frame too large')); }
        const frames = raw.split(/\r?\n\r?\n/);
        if (frames.length < 2) return;
        for (const frame of frames.slice(0, -1)) {
          const data = frame.split(/\r?\n/).filter(line => line.startsWith('data:')).map(line => line.slice(5).replace(/^ /, '')).join('\n');
          if (!data) continue;
          let event;
          try { event = JSON.parse(data); } catch (error) { req.destroy(); return reject(error); }
          first = true; clearTimeout(timer);
          resolve({ event, headers: res.headers, closed, close: () => req.destroy() }); break;
        }
      });
      res.once('end', settleClosed); res.once('close', settleClosed);
      res.once('error', error => { settleClosed(); if (!first) reject(error); });
    });
    req.once('error', error => { settleClosed(); if (!first) reject(error); });
    const timer = setTimeout(() => { req.destroy(); reject(new Error('No actual SSE frame within 15s')); }, 15000);
  });
}
async function mustClose(stream) {
  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('Authenticated SSE did not close after rotation / revocation')), 3000);
    stream.closed.then(() => { clearTimeout(timer); resolve(); }, error => { clearTimeout(timer); reject(error); });
  });
}
function record(name, json) {
  if (!recordDir) return;
  const target = path.resolve(recordDir); fs.mkdirSync(target, { recursive: true, mode: 0o700 });
  fs.writeFileSync(path.join(target, name + '.json'), JSON.stringify(json, null, 2) + '\n', { mode: 0o600 });
}

async function run() {
  const packageFile = path.join(runtime, 'node_modules/opencode-ai/package.json');
  if (!fs.existsSync(packageFile)) throw new Error('Install the real CLI first: node start.js, or npm install --prefix runtime opencode-ai@1.18.35. Pass --runtime /path/to/runtime if needed.');
  const pkg = JSON.parse(fs.readFileSync(packageFile, 'utf8'));
  assert.equal(pkg.name, 'opencode-ai'); assert.equal(pkg.version, PINNED_OPENCODE_VERSION);
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'oc-real-'));
  const config = { ...loadConfig(root, { RUNTIME_DIR: runtime, LOG_LEVEL: 'error', MIN_FREE_DISK_MB: '0' }),
    SERVER_PORT: 0, OPENCODE_PORT: await freePort() };
  let app, openStream;
  try {
    app = await main(config, { installer: new OpenCodeInstaller(config) });
    assert.equal(await app.ready, true);
    let base = `http://127.0.0.1:${app.server.address().port}`;
    checkpoint('genuine opencode-ai 1.18.35 CLI verified and private server healthy');
    let health = await request(base, 'GET', '/health');
    assert.equal(health.status, 200); assert.equal(health.json.ok, true); assert.equal(health.json.gateway, '1.0.0');
    assert.equal(health.json.opencode.running, true); assert.equal(health.json.opencode.version, PINNED_OPENCODE_VERSION);
    record('health', health.json); checkpoint('public /health matches the Android gateway-v1 handshake');
    assert.equal((await request(base, 'GET', '/gateway/projects')).status, 401); checkpoint('protected gateway routes reject missing phone authentication');
    const privateResponse = await request(`http://127.0.0.1:${config.OPENCODE_PORT}`, 'GET', '/session');
    assert.equal(privateResponse.status, 401); checkpoint('private OpenCode rejects unauthenticated direct session access');
    const code = app.pairingManager.getActiveCode(); assert.match(code, /^[A-Z0-9]{4}-[A-Z0-9]{4}$/);
    let paired = await request(base, 'POST', '/pair/redeem', null, { code, deviceName: 'Real CLI verifier' });
    assert.equal(paired.status, 200); let token = paired.json.deviceToken; const deviceId = paired.json.deviceId;
    assert.match(token, /^dt_/); checkpoint('actual console LINK CODE redeems into a device credential');
    assert.equal((await request(base, 'POST', '/pair/redeem', null, { code, deviceName: 'Replay' })).status, 401); checkpoint('single-use pairing code cannot be reused');
    const status = await request(base, 'GET', '/gateway/status', token);
    assert.equal(status.status, 200); assert.equal(status.json.device.id, deviceId); assert.equal(status.json.opencode.running, true);
    record('status', status.json); checkpoint('authenticated real status / device / tool metadata');
    const created = await request(base, 'POST', '/gateway/projects', token, { name: 'مشروع تحقق حقيقي' });
    assert.equal(created.status, 201); const project = created.json.id; const scoped = { 'X-Project-Id': project };
    record('project', created.json); checkpoint('Arabic empty-project creation through the mobile contract');
    const renamed = await request(base, 'PATCH', `/gateway/projects/${project}`, token, { name: 'مشروع متوافق', archived: false });
    assert.equal(renamed.status, 200); assert.equal(renamed.json.name, 'مشروع متوافق'); checkpoint('project patch / rename uses the shared contract');
    const providers = await request(base, 'GET', '/oc/config/providers', token);
    assert.equal(providers.status, 200); assert.ok(Array.isArray(providers.json.providers));
    // Record only sanitized metadata. Provider credentials/options NEVER go
    // into the report, source fixtures or application preferences.
    const safeProviders = { ...providers.json, providers: providers.json.providers.map(provider => {
      const safe = { ...provider, options: {} }; delete safe.key; return safe;
    }) };
    record('providers', safeProviders); checkpoint('real global provider/model response (no project directory supplied)');
    const sessionResult = await request(base, 'POST', '/oc/session', token, {}, scoped);
    assert.equal(sessionResult.status, 200); const session = sessionResult.json.id; assert.match(session, /^ses_/);
    assert.equal(sessionResult.json.directory, path.join(config.WORKSPACE_DIR, app.projectsManager.get(project).dirName));
    record('session', sessionResult.json); checkpoint('actual OpenCode session creation injects the selected project directory');
    const sessions = await request(base, 'GET', '/oc/session', token, undefined, scoped);
    assert.equal(sessions.status, 200); assert.ok(sessions.json.some(value => value.id === session));
    record('sessions', sessions.json); checkpoint('session list returns the created real session');
    const meta = await request(base, 'GET', `/oc/session/${session}`, token, undefined, scoped);
    assert.equal(meta.status, 200); assert.equal(meta.json.id, session); checkpoint('session metadata route matches the application');
    const statuses = await request(base, 'GET', '/oc/session/status', token, undefined, scoped);
    assert.equal(statuses.status, 200); assert.equal(statuses.json[session], undefined);
    record('statuses', statuses.json); checkpoint('real busy/retry map: missing session key is idle');
    const messages = await request(base, 'GET', `/oc/session/${session}/message?limit=400`, token, undefined, scoped);
    assert.equal(messages.status, 200); assert.ok(Array.isArray(messages.json)); record('messages', messages.json); checkpoint('real message history / 400-row page endpoint');
    const permissions = await request(base, 'GET', '/oc/permission', token, undefined, scoped);
    assert.equal(permissions.status, 200); assert.ok(Array.isArray(permissions.json)); record('permissions', permissions.json); checkpoint('modern pending-permission endpoint');
    const diff = await request(base, 'GET', `/oc/session/${session}/diff`, token, undefined, scoped);
    assert.equal(diff.status, 200); assert.ok(Array.isArray(diff.json)); record('diff', diff.json); checkpoint('real per-session diff endpoint');
    openStream = await openSse(base, token, project);
    assert.equal(openStream.event.type, 'server.connected'); assert.match(openStream.headers['content-type'], /text\/event-stream/);
    record('event', openStream.event); checkpoint('actual OpenCode SSE frame arrives unbuffered through the gateway');
    openStream.close(); await mustClose(openStream); openStream = null;
    const abort = await request(base, 'POST', `/oc/session/${session}/abort`, token, {}, scoped);
    assert.equal(abort.status, 200); assert.equal(typeof abort.json, 'boolean'); record('abort', abort.json); checkpoint('real abort response is boolean, as the Android client expects');
    const projectDir = path.join(config.WORKSPACE_DIR, app.projectsManager.get(project).dirName);
    const artifact = apkArgument ? fs.readFileSync(path.resolve(apkArgument)) : Buffer.from('Actual gateway artifact download verification\n');
    const artifactName = apkArgument ? 'app-debug.apk' : 'verification.log';
    fs.writeFileSync(path.join(projectDir, artifactName), artifact);
    const artifacts = await request(base, 'GET', `/gateway/projects/${project}/artifacts`, token);
    assert.equal(artifacts.status, 200); const item = artifacts.json.find(value => value.path === artifactName); assert.ok(item);
    assert.equal(item.sha256, crypto.createHash('sha256').update(artifact).digest('hex'));
    record('artifacts', artifacts.json); checkpoint('artifact listing hashes the actual test artifact bytes');
    const downloadPath = `/gateway/projects/${project}/download?path=${encodeURIComponent(artifactName)}`;
    const downloaded = await request(base, 'GET', downloadPath, token);
    assert.equal(downloaded.status, 200); assert.deepEqual(downloaded.bytes, artifact); assert.equal(downloaded.headers['accept-ranges'], 'bytes'); checkpoint('authenticated full artifact download / byte-for-byte integrity');
    const ranged = await request(base, 'GET', downloadPath, token, undefined, { Range: 'bytes=5-19' });
    assert.equal(ranged.status, 206); assert.deepEqual(ranged.bytes, artifact.subarray(5, 20)); assert.equal(ranged.headers['content-range'], `bytes 5-19/${artifact.length}`); checkpoint('authenticated Range download returns correct 206 bytes');
    const traversal = await request(base, 'GET', `/gateway/projects/${project}/download?path=${encodeURIComponent('../../data/state.json')}`, token);
    assert.equal(traversal.status, 403); checkpoint('download traversal cannot escape the selected project');
    assert.ok(!fs.readFileSync(app.stateManager.statePath, 'utf8').includes(token)); checkpoint('device database persists only the credential hash');
    await app.shutdown(); app = await main(config, { installer: new OpenCodeInstaller(config) });
    assert.equal(await app.ready, true); base = `http://127.0.0.1:${app.server.address().port}`;
    assert.equal((await request(base, 'GET', '/gateway/projects', token)).status, 200);
    const restored = await request(base, 'GET', `/oc/session/${session}`, token, undefined, scoped);
    assert.equal(restored.status, 200); assert.equal(restored.json.id, session); checkpoint('full gateway/OpenCode restart preserves device token, project and session');
    openStream = await openSse(base, token, project);
    const rotation = await request(base, 'POST', '/gateway/devices/rotate', token, {});
    assert.equal(rotation.status, 200); await mustClose(openStream); openStream = null;
    assert.equal((await request(base, 'GET', '/gateway/projects', token)).status, 401); token = rotation.json.deviceToken;
    assert.equal((await request(base, 'GET', '/gateway/projects', token)).status, 200); checkpoint('rotation closes old SSE / invalidates old token / accepts new token');
    openStream = await openSse(base, token, project);
    const revoked = await request(base, 'DELETE', `/gateway/devices/${deviceId}`, token);
    assert.equal(revoked.status, 204); await mustClose(openStream); openStream = null;
    assert.equal((await request(base, 'GET', '/gateway/projects', token)).status, 401); checkpoint('revocation closes SSE and rejects further requests');
    record('summary', { realOpenCodeVersion: PINNED_OPENCODE_VERSION, checksPassed: checked.length, checks: checked,
      notVerified: ['AI prompts / model-provider account access / real tool execution', 'Live GitHub-account operations', 'Physical Android installation / UI / lifecycle', 'User Waifly/Pterodactyl instance and its resources / firewall'] });
    process.stdout.write(`\nREAL CLI INTEGRATION PASS: ${checked.length} checks. No AI prompt or GitHub account was used.\n`);
  } finally {
    if (openStream) openStream.close(); if (app) await app.shutdown();
    fs.rmSync(root, { recursive: true, force: true });
  }
}

run().catch(error => { process.stderr.write(`REAL CLI INTEGRATION FAILED: ${error.message}\n`); process.exitCode = 1; });
